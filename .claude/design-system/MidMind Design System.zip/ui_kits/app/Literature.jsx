(() => {
// Klick auf einen Quellen-Chip oder eine hochgestellte Quellennummer öffnet den zugehörigen Textauszug.
// Per Event-Delegation, damit AnswerCard unverändert bleibt.
function sourceFromClick(e) {
  const chip = e.target.closest('.mm-source');
  const ref = e.target.closest('.mm-ref');
  if (!chip && !ref) return null;
  e.preventDefault();
  let el = chip;
  if (ref) {
    const n = parseInt(ref.textContent, 10);
    const answer = ref.closest('.mm-answer');
    el = answer ? answer.querySelectorAll('.mm-source')[n - 1] : null;
  }
  if (!el) return null;
  const label = (el.getAttribute('aria-label') || '').replace(/^Quelle \d+:\s*/, '');
  return LITERATURE[label] ? label : null;
}

function Excerpt({ src }) {
  return (
    <div style={{ background: 'var(--mm-sand)', borderRadius: 'var(--mm-radius-m)', padding: 'var(--mm-space-4) var(--mm-space-5)', fontSize: 'var(--mm-text-body)', lineHeight: 'var(--mm-leading)', textWrap: 'pretty' }}>
      {src.before}{' '}
      <mark style={{ background: 'var(--mm-apricot)', color: 'var(--mm-on-apricot)', borderRadius: 4, padding: '1px 3px', boxDecorationBreak: 'clone', WebkitBoxDecorationBreak: 'clone' }}>{src.highlight}</mark>
      {' '}{src.after}
    </div>
  );
}

function SourceBody({ label, layout }) {
  const { Badge, Button, Icon } = window.MidMindDesignSystem_0ec547;
  const src = LITERATURE[label];
  const [copied, setCopied] = React.useState(false);
  return (
    <div style={{ display: 'grid', gap: 'var(--mm-space-4)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--mm-space-2)', flexWrap: 'wrap', fontSize: 'var(--mm-text-small)', color: 'var(--mm-muted)' }}>
        {src.level && <Badge tone="ok" size="sm">{src.level}</Badge>}
        <span>{src.publisher}</span><span aria-hidden="true">·</span><span>{src.section}</span><span aria-hidden="true">·</span><span>{src.page}</span>
      </div>
      <Excerpt src={src} />
      <span style={{ fontSize: 13, color: 'var(--mm-muted)' }}>Beispielauszug – im Produkt steht hier der Originaltext.</span>
      <div style={{ display: 'flex', gap: 'var(--mm-space-3)', flexWrap: 'wrap', justifyContent: layout === 'desktop' ? 'flex-end' : 'stretch' }}>
        <Button variant="ghost" size="sm" icon={<Icon name={copied ? 'check' : 'copy'} size={18} />} onClick={() => setCopied(true)}>{copied ? 'Kopiert' : 'Zitat kopieren'}</Button>
        {src.pdf && <Button variant="secondary" size="sm" icon={<Icon name="book" size={18} />}>Ganze Leitlinie öffnen</Button>}
      </div>
    </div>
  );
}

function SourceOverlay({ label, layout = 'mobile', onClose }) {
  const { IconButton } = window.MidMindDesignSystem_0ec547;
  if (!label) return null;
  const src = LITERATURE[label];
  if (layout === 'desktop') {
    return <Dialog title={src.title} width={640} onClose={onClose}><SourceBody label={label} layout="desktop" /></Dialog>;
  }
  return (
    <Sheet onClose={onClose}>
      <div style={{ padding: 'var(--mm-space-2) var(--mm-space-4) 0', display: 'grid', gap: 'var(--mm-space-3)', maxHeight: '72vh', overflow: 'auto' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 'var(--mm-space-3)' }}>
          <h2 style={{ margin: 0, flex: 1, fontSize: 'var(--mm-text-h)', lineHeight: 1.3, paddingTop: 8 }}>{src.title}</h2>
          <IconButton icon="close" label="Schließen" onClick={onClose} />
        </div>
        <SourceBody label={label} layout="mobile" />
      </div>
    </Sheet>
  );
}

Object.assign(window, { sourceFromClick, SourceOverlay });
})();
