(() => {
// Canned answers for the click-through. Content taken from the @midmind/ui component stories.
const { AnswerCard, Value, SourceRef, Callout, Button, Icon } = window.MidMindDesignSystem_0ec547;

const answerActions = () => (
  <>
    <Button variant="ghost" size="sm" icon={<Icon name="copy" size={18} />}>Kopieren</Button>
    <Button variant="ghost" size="sm" icon={<Icon name="chat" size={18} />}>Als Kurznachricht kopieren</Button>
  </>
);

const ANSWERS = {
  trinkmenge: {
    title: 'Trinkmenge 9. Lebenstag', phase: 'wochenbett',
    question: 'Wieviel Milch sollte ein 9 Tage alter Säugling trinken?',
    render: () => (
      <AnswerCard
        summary={<>Etwa <Value>1/6 des Körpergewichts</Value> pro Tag, verteilt auf <Value>6–10 Mahlzeiten</Value>.</>}
        facts={[{ label: 'pro Tag', value: '≈ 600 ml' }, { label: 'pro Mahlzeit', value: '60–100 ml' }, { label: 'Mahlzeiten', value: '6–10' }]}
        factsCaption="Beispiel: 3.600 g"
        sources={[{ label: 'AWMF 024-005' }, { label: 'DHV Stillempfehlung' }]}
        actions={answerActions()}>
        <p>Ab dem 8. Lebenstag gilt als Tagestrinkmenge etwa ein Sechstel des Körpergewichts.<SourceRef index={1} /> Gestillte Kinder trinken nach Bedarf, die Menge dient der Orientierung.<SourceRef index={2} /></p>
      </AnswerCard>
    ),
  },
  praeeklampsie: {
    title: 'Blutdruck 160/110 mmHg', phase: 'schwangerschaft',
    question: 'Blutdruck 160/110 mmHg und Kopfschmerzen in der 36. SSW – was tun?',
    render: () => (
      <AnswerCard
        alert={<Callout tone="critical" title="Notfall: sofort ärztlich abklären">Verdacht auf schwere Präeklampsie. Klinik bzw. Kreißsaal informieren.</Callout>}
        summary={<>Ab <Value>160/110 mmHg</Value> mit Symptomen: stationäre Einweisung, Blutdruck alle <Value>15 min</Value>.</>}
        facts={[{ label: 'Hypertonie', value: 'ab 140/90 mmHg' }, { label: 'schwere Hypertonie', value: 'ab 160/110 mmHg' }]}
        factsCaption="Blutdruck in der Schwangerschaft"
        sources={[{ label: 'AWMF 015-018' }]}
        actions={answerActions()}>
        <p>Kopfschmerzen und Sehstörungen gelten als Warnzeichen einer drohenden Eklampsie. Linksseitenlage, ruhige Umgebung.<SourceRef index={1} /></p>
      </AnswerCard>
    ),
  },
  gewicht: {
    title: 'Gewichtsverlust Neugeborenes', phase: 'wochenbett',
    question: 'Ab wann ist der Gewichtsverlust eines Neugeborenen kontrollbedürftig?',
    render: () => (
      <AnswerCard
        summary={<>Ab <Value>7 %</Value> Gewichtsverlust Stillen beobachten, ab <Value>10 %</Value> ärztlich abklären.</>}
        note={<Callout tone="warning" title="Hinweis">Bei Frühgeborenen gelten engere Grenzen.</Callout>}
        sources={[{ label: 'AWMF 024-005' }]}
        actions={answerActions()}>
        <p>Der physiologische Tiefpunkt liegt meist am 3. bis 4. Lebenstag. Das Geburtsgewicht sollte bis zum 10. bis 14. Tag wieder erreicht sein.<SourceRef index={1} /></p>
      </AnswerCard>
    ),
  },
};

const SUGGESTIONS = [
  { text: 'Trinkmenge Neugeborenes nach Lebenstag', key: 'trinkmenge' },
  { text: 'Gewichtsverlust: ab wann kontrollbedürftig?', key: 'gewicht' },
  { text: 'Blutdruck 160/110 mmHg in der Schwangerschaft', key: 'praeeklampsie' },
];

function matchAnswer(q) {
  const s = q.toLowerCase();
  if (/blutdruck|präeklampsie|mmhg|kopfschmerz/.test(s)) return 'praeeklampsie';
  if (/gewicht|abnahme|verlust/.test(s)) return 'gewicht';
  return 'trinkmenge';
}

const HISTORY = [
  { label: 'Trinkmenge 9. Lebenstag', phase: 'wochenbett', key: 'trinkmenge' },
  { label: 'Anti-D-Prophylaxe Zeitpunkt', phase: 'schwangerschaft' },
  { label: 'Dammriss Grad III Nachsorge', phase: 'geburt' },
  { label: 'Gewichtsverlust Neugeborenes', phase: 'wochenbett', key: 'gewicht' },
];

// Beispielliste – durch die tatsächlich enthaltenen S3-Leitlinien (PDF) ersetzen.
const LEITLINIEN = [
  { title: 'Vaginale Geburt am Termin', id: 'AWMF 015-083', level: 'S3' },
  { title: 'Die Sectio caesarea', id: 'AWMF 015-084', level: 'S3' },
  { title: 'Gestationsdiabetes mellitus – Diagnostik, Therapie und Nachsorge', id: 'AWMF 057-008', level: 'S3' },
];

// Gleiche Navigation in Mobil- und Desktop-App: Fragen · Verlauf · Leitlinien.
const APP_TABS = [
  { id: 'fragen', label: 'Fragen', icon: 'chat' },
  { id: 'verlauf', label: 'Verlauf', icon: 'clock' },
  { id: 'leitlinien', label: 'Leitlinien', icon: 'folder' },
];

// Textauszüge hinter den Quellen-Chips. Beispieltexte für das Mockup – echte Auszüge kommen aus der Literaturdatenbank.
const LITERATURE = {
  'AWMF 024-005': {
    level: 'S2k', publisher: 'AWMF-Register 024-005', pdf: true,
    title: 'Betreuung von gesunden reifen Neugeborenen in der Geburtsklinik',
    section: 'Ernährung des Neugeborenen', page: 'S. 14',
    before: 'Die Trinkmenge steigt in den ersten Lebenstagen schrittweise an und orientiert sich am Körpergewicht des Kindes.',
    highlight: 'Ab dem 8. Lebenstag beträgt die Tagestrinkmenge etwa ein Sechstel des Körpergewichts, verteilt auf 6 bis 10 Mahlzeiten.',
    after: 'Abweichungen sind bei gesunden, gut gedeihenden Kindern häufig und für sich allein kein Grund zur Zufütterung.',
  },
  'DHV Stillempfehlung': {
    publisher: 'Deutscher Hebammenverband', pdf: false,
    title: 'Stillempfehlungen für Hebammen',
    section: 'Stillen nach Bedarf', page: 'S. 6',
    before: 'Gesunde, reif geborene Kinder regulieren ihre Nahrungsaufnahme selbst.',
    highlight: 'Gestillte Kinder trinken nach Bedarf; Richtwerte zur Trinkmenge dienen der Orientierung und nicht als Vorgabe.',
    after: 'Entscheidend sind Gewichtsverlauf, Ausscheidungen und das Verhalten des Kindes an der Brust.',
  },
  'AWMF 015-018': {
    level: 'S2k', publisher: 'AWMF-Register 015-018', pdf: true,
    title: 'Hypertensive Erkrankungen in der Schwangerschaft: Diagnostik und Therapie',
    section: 'Schwere Hypertonie und drohende Eklampsie', page: 'S. 32',
    before: 'Eine schwere Hypertonie liegt ab einem Blutdruck von 160/110 mmHg vor.',
    highlight: 'Treten zusätzlich Kopfschmerzen, Sehstörungen oder Oberbauchschmerzen auf, ist eine sofortige stationäre Aufnahme angezeigt.',
    after: 'Bis zur Übergabe sollte der Blutdruck engmaschig kontrolliert und die Schwangere in Linksseitenlage gebracht werden.',
  },
};

Object.assign(window, { ANSWERS, SUGGESTIONS, HISTORY, LEITLINIEN, APP_TABS, LITERATURE, matchAnswer });
})();
