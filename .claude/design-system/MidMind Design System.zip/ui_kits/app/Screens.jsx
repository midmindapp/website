(() => {
const { AppBar, Logo, IconButton, Badge, Button, Icon, NavItem, DisplayHeading, PhaseChipGroup, SuggestionButton, Composer, ChatQuestion, TextSizeSwitch } = window.MidMindDesignSystem_0ec547;

const DISCLAIMER = 'MidMind ist eine KI und macht Fehler.';

function HomeBar({ night, onNight, onText, account }) {
  return (
    <AppBar title="MidMind" leading={<Logo size={30} />}
      trailing={<><IconButton icon="text" label="Textgröße" onClick={onText} /><IconButton icon={night ? 'sun' : 'moon'} label={night ? 'Tagmodus' : 'Nachtmodus'} onClick={onNight} />{account}</>} />
  );
}

function TextSizePanel({ value, onChange }) {
  return (
    <div style={{ padding: 'var(--mm-space-3) var(--mm-space-4)', borderBottom: '1px solid var(--mm-line)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 'var(--mm-space-3)' }}>
      <span style={{ fontWeight: 600, fontSize: 'var(--mm-text-small)' }}>Textgröße</span>
      <TextSizeSwitch value={value} onChange={onChange} />
    </div>
  );
}

function StartScreen({ phase, onPhase, onAsk, name = 'Hanna' }) {
  return (
    <div style={{ padding: 'var(--mm-space-5) var(--mm-space-4)', display: 'grid', gap: 'var(--mm-space-5)', alignContent: 'start', overflow: 'auto' }}>
      <DisplayHeading as="h1" size="md">Guten Abend, {name}.</DisplayHeading>
      <PhaseChipGroup value={phase} onChange={onPhase} />
      <div style={{ display: 'grid', gap: 'var(--mm-space-2)' }}>
        {SUGGESTIONS.map((s) => <SuggestionButton key={s.key} onClick={() => onAsk(ANSWERS[s.key].question, s.key)}>{s.text}</SuggestionButton>)}
      </div>
    </div>
  );
}

function Conversation({ turns, scrollRef, onClick }) {
  return (
    <div ref={scrollRef} onClick={onClick} style={{ padding: 'var(--mm-space-4)', display: 'grid', gap: 'var(--mm-space-4)', alignContent: 'start', overflow: 'auto', minHeight: 0 }}>
      {turns.map((t, i) => (
        <React.Fragment key={i}>
          <ChatQuestion>{t.q}</ChatQuestion>
          {ANSWERS[t.key].render()}
        </React.Fragment>
      ))}
    </div>
  );
}

function LeitlinienList({ compact }) {
  return (
    <div style={{ padding: compact ? 'var(--mm-space-4)' : 'var(--mm-space-5) var(--mm-space-4)', maxWidth: 720, width: '100%', boxSizing: 'border-box', margin: '0 auto', display: 'grid', gap: 'var(--mm-space-3)', alignContent: 'start', overflow: 'auto', minHeight: 0 }}>
      <p style={{ margin: 0, color: 'var(--mm-muted)', fontSize: 'var(--mm-text-small)' }}>Die S3-Leitlinien, auf die sich MidMind stützt, zum Nachlesen als PDF.</p>
      {LEITLINIEN.map((l) => (
        <div key={l.id} style={{ display: 'flex', alignItems: 'center', gap: 'var(--mm-space-3)', padding: 'var(--mm-space-3) var(--mm-space-4)', background: 'var(--mm-card)', border: '1px solid var(--mm-line)', borderRadius: 'var(--mm-radius-m)' }}>
          <span style={{ color: 'var(--mm-muted)', display: 'inline-flex' }}><Icon name="book" size={22} /></span>
          <div style={{ flex: 1, minWidth: 0, display: 'grid', gap: 2 }}>
            <span style={{ fontWeight: 700, fontSize: 16, lineHeight: 1.35 }}>{l.title}</span>
            <span style={{ fontSize: 14, color: 'var(--mm-muted)' }}>{compact ? `${l.id} · ${l.level}` : l.id}</span>
          </div>
          {compact
            ? <IconButton icon="chevronRight" label="PDF öffnen" />
            : <><Badge tone="ok" size="sm">{l.level}</Badge><Button variant="ghost" size="sm">PDF öffnen</Button></>}
        </div>
      ))}
    </div>
  );
}

function HistoryList({ activeKey, onOpen }) {
  return (
    <div style={{ padding: 'var(--mm-space-3)', display: 'grid', gap: 2, alignContent: 'start', overflow: 'auto', minHeight: 0 }}>
      {HISTORY.map((h) => (
        <NavItem key={h.label} label={h.label} phase={h.phase} active={!!h.key && h.key === activeKey}
          onClick={(e) => { e.preventDefault(); if (h.key) onOpen(h.key); }} />
      ))}
    </div>
  );
}

Object.assign(window, { HomeBar, TextSizePanel, StartScreen, Conversation, LeitlinienList, HistoryList, DISCLAIMER });
})();
