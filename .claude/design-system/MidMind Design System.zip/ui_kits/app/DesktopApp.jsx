(() => {
const { MidMindRoot, AppBar, Logo, IconButton, Badge, Button, Icon, NavItem, Composer, SuggestionButton, ChatQuestion } = window.MidMindDesignSystem_0ec547;

function UserRow({ user, open, onToggle, onSelect }) {
  return (
    <div style={{ position: 'relative' }}>
      <button type="button" onClick={onToggle} aria-haspopup="menu" aria-expanded={open}
        style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 'var(--mm-space-3)', minHeight: 56, padding: '6px 10px', border: 0, borderRadius: 12, background: open ? 'var(--mm-card)' : 'transparent', color: 'var(--mm-ink)', font: 'inherit', textAlign: 'left', cursor: 'pointer' }}>
        <Initials name={user.name} size={36} />
        <span style={{ display: 'grid', minWidth: 0, flex: 1 }}>
          <strong style={{ fontSize: 15 }}>{user.name}</strong>
          <span style={{ fontSize: 13, color: 'var(--mm-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user.email}</span>
        </span>
        <span style={{ color: 'var(--mm-muted)', display: 'inline-flex', transform: 'rotate(-90deg)' }}><Icon name="chevronRight" size={18} /></span>
      </button>
      {open && <Popover onClose={onToggle} style={{ left: 0, right: 0, bottom: 'calc(100% + 8px)' }}><UserMenuList user={user} onSelect={onSelect} /></Popover>}
    </div>
  );
}

function Sidebar({ view, activeKey, onNew, onOpen, onLeitlinien, user, menu, onMenu, onSelect }) {
  return (
    <aside style={{ background: 'var(--mm-sand)', padding: 'var(--mm-space-4) var(--mm-space-3)', display: 'grid', gridTemplateRows: 'auto auto 1fr auto', gap: 'var(--mm-space-4)', minHeight: 0 }}>
      <div style={{ padding: '4px 6px' }}><Logo size={36} wordmark /></div>
      <Button block icon={<Icon name="plus" size={18} />} onClick={onNew}>Neue Frage</Button>
      <div style={{ display: 'grid', gap: 2, alignContent: 'start' }}>
        <div style={{ fontSize: 13, color: 'var(--mm-muted)', padding: '8px 10px 4px' }}>Verlauf</div>
        {HISTORY.map((h) => (
          <NavItem key={h.label} label={h.label} phase={h.phase} active={view === 'chat' && !!h.key && h.key === activeKey}
            onClick={(e) => { e.preventDefault(); if (h.key) onOpen(h.key); }} />
        ))}
        <div style={{ fontSize: 13, color: 'var(--mm-muted)', padding: '16px 10px 4px' }}>Wissen</div>
        <NavItem label="Leitlinien" icon={<Icon name="folder" size={18} />} count={LEITLINIEN.length} active={view === 'leitlinien'}
          onClick={(e) => { e.preventDefault(); onLeitlinien(); }} />
      </div>
      <div style={{ borderTop: '1px solid var(--mm-line)', paddingTop: 'var(--mm-space-3)' }}>
        <UserRow user={user} open={menu} onToggle={onMenu} onSelect={onSelect} />
      </div>
    </aside>
  );
}

function DesktopApp({ initialUser = null, initialView = 'chat' }) {
  const [user, setUser] = React.useState(initialUser);
  const [menu, setMenu] = React.useState(false);
  const [account, setAccount] = React.useState(null);
  const [source, setSource] = React.useState(null);
  const [night, setNight] = React.useState(false);
  const [view, setView] = React.useState(initialView);
  const [turns, setTurns] = React.useState([{ q: ANSWERS.trinkmenge.question, key: 'trinkmenge' }]);
  const scrollRef = React.useRef(null);
  const ask = (q, key) => { setView('chat'); setTurns((t) => [...t, { q, key: key || matchAnswer(q) }]); };
  React.useEffect(() => { const el = scrollRef.current; if (el) el.scrollTop = el.scrollHeight; }, [turns]);
  if (!user) return <LoginScreen layout="desktop" onLogin={setUser} />;
  const pick = (id) => { setMenu(false); if (id === 'logout') { setUser(null); setAccount(null); } else if (id === 'admin') setView('admin'); else setAccount(id); };
  const last = turns.length ? ANSWERS[turns[turns.length - 1].key] : null;
  const isChat = view === 'chat';

  return (
    <MidMindRoot theme={night ? 'night' : 'day'} style={{ position: 'relative', display: 'grid', gridTemplateColumns: '280px 1fr', height: '100%', overflow: 'hidden' }}>
      <Sidebar view={view} activeKey={turns[0]?.key}
        onNew={() => { setView('chat'); setTurns([]); }}
        onOpen={(k) => { setView('chat'); setTurns([{ q: ANSWERS[k].question, key: k }]); }}
        onLeitlinien={() => setView('leitlinien')}
        user={user} menu={menu} onMenu={() => setMenu(!menu)} onSelect={pick} />
      {view === 'admin' ? (
      <main style={{ display: 'grid', gridTemplateRows: 'auto 1fr', minHeight: 0 }}>
        <AppBar title="Verwaltung" trailing={<IconButton icon={night ? 'sun' : 'moon'} label={night ? 'Tagmodus' : 'Nachtmodus'} onClick={() => setNight(!night)} />} />
        <div style={{ overflow: 'auto', minHeight: 0 }}><UserAdmin layout="desktop" /></div>
      </main>
      ) : (
      <main style={{ display: 'grid', gridTemplateRows: 'auto 1fr auto', minHeight: 0 }}>
        <AppBar title={isChat ? (last ? last.title : 'Neue Frage') : 'Leitlinien'}
          trailing={<>{isChat && last && <Badge phase={last.phase} size="sm" />}<IconButton icon={night ? 'sun' : 'moon'} label={night ? 'Tagmodus' : 'Nachtmodus'} onClick={() => setNight(!night)} /></>} />
        <div ref={scrollRef} style={{ overflow: 'auto', minHeight: 0 }}>
          {isChat ? (
            <div onClick={(e) => { const l = sourceFromClick(e); if (l) setSource(l); }} style={{ maxWidth: 720, margin: '0 auto', padding: 'var(--mm-space-5) var(--mm-space-4)', display: 'grid', gap: 'var(--mm-space-4)' }}>
              {turns.length === 0 && (
                <div style={{ display: 'grid', gap: 'var(--mm-space-2)' }}>
                  {SUGGESTIONS.map((s) => <SuggestionButton key={s.key} onClick={() => ask(ANSWERS[s.key].question, s.key)}>{s.text}</SuggestionButton>)}
                </div>
              )}
              {turns.map((t, i) => (
                <React.Fragment key={i}><ChatQuestion>{t.q}</ChatQuestion>{ANSWERS[t.key].render()}</React.Fragment>
              ))}
            </div>
          ) : <LeitlinienList />}
        </div>
        <div style={{ maxWidth: 720, width: '100%', margin: '0 auto', padding: 'var(--mm-space-3) var(--mm-space-4) var(--mm-space-4)' }}>
          <Composer placeholder={isChat && turns.length ? 'Nachfragen …' : 'Frage stellen …'} dictation={!(isChat && turns.length)} searchIcon={!(isChat && turns.length)} onSubmit={(q) => ask(q)} disclaimer={DISCLAIMER} />
        </div>
      </main>
      )}
      {source && <SourceOverlay label={source} layout="desktop" onClose={() => setSource(null)} />}
      {account && (
        <Dialog title={account === 'password' && !user.hasPassword ? 'Passwort festlegen' : ACCOUNT_TITLES[account]} onClose={() => setAccount(null)}>
          {account === 'passkeys'
            ? <PasskeyManager user={user} onSave={setUser} layout="desktop" onCancel={() => setAccount(null)} />
            : <AccountForm key={account} kind={account} user={user} onSave={setUser} onCancel={() => setAccount(null)} layout="desktop" />}
        </Dialog>
      )}
    </MidMindRoot>
  );
}

window.DesktopApp = DesktopApp;
})();
