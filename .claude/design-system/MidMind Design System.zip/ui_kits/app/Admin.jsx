(() => {
// Benutzerverwaltung (nur Admins). Kompakte Liste, Aktionen klappen pro Zeile auf, Formular „Benutzer hinzufügen“ am Ende.
const NS = () => window.MidMindDesignSystem_0ec547;
const ROLES = [{ id: 'user', label: 'Benutzer' }, { id: 'admin', label: 'Admin' }];
const roleLabel = (r) => ROLES.find((x) => x.id === r).label;

const SEED_USERS = [
  { id: 1, name: 'Hanna Kröger', email: 'hanna.kroeger@praxis-mondschein.de', role: 'admin', last: 'heute', passkeys: 1, active: true, me: true },
  { id: 2, name: 'Anna-Carolin Heller', email: 'annacarolinheller@gmail.com', role: 'user', last: null, passkeys: 0, active: true },
  { id: 3, name: 'Danielle Kraatz', email: 'danielle.kraatz90@gmail.com', role: 'user', last: null, passkeys: 0, active: true },
  { id: 4, name: 'Merle Albers', email: 'merle.albers@praxis-mondschein.de', role: 'user', last: 'gestern', passkeys: 2, active: true },
  { id: 5, name: 'Sophie Brandt', email: 's.brandt@hebammen-nord.de', role: 'user', last: '03.08.2026', passkeys: 1, active: false },
];

const meta = (u) => `${u.last ? 'Zuletzt angemeldet ' + u.last : 'Noch nie angemeldet'} · ${u.passkeys === 1 ? '1 Passkey' : u.passkeys + ' Passkeys'}`;

function RoleSelect({ value, onChange, compact, disabled, id, 'aria-label': ariaLabel }) {
  return (
    <select id={id} aria-label={ariaLabel} className="mm-field__input" value={value} disabled={disabled} onChange={(e) => onChange(e.target.value)}
      style={compact ? { width: 'auto', minHeight: 44, fontSize: 16, paddingRight: 12, cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.5 : 1 } : { cursor: 'pointer' }}>
      {ROLES.map((r) => <option key={r.id} value={r.id}>{r.label}</option>)}
    </select>
  );
}

function UserRowItem({ u, open, onToggle, onChange, layout }) {
  const { Badge, Button, IconButton, Callout } = NS();
  const [note, setNote] = React.useState(null);
  const desktop = layout === 'desktop';
  const panelId = `user-actions-${u.id}`;
  return (
    <li style={{ listStyle: 'none', borderTop: '1px solid var(--mm-line)' }}>
      <div onClick={onToggle} style={{ display: 'grid', gridTemplateColumns: desktop ? '36px minmax(0,1fr) auto 44px' : '36px minmax(0,1fr) 44px', alignItems: 'center', gap: 'var(--mm-space-3)', padding: '10px var(--mm-space-3) 10px var(--mm-space-4)', cursor: 'pointer', background: open ? 'var(--mm-paper)' : 'transparent' }}>
        <span style={{ opacity: u.active ? 1 : 0.5 }}><Initials name={u.name} size={36} /></span>
        <span style={{ display: 'grid', minWidth: 0, gap: 1 }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: 'var(--mm-space-2)', minWidth: 0, flexWrap: 'wrap' }}>
            <strong style={{ fontSize: 16, color: u.active ? 'var(--mm-ink)' : 'var(--mm-muted)' }}>{u.name}{u.me && <span style={{ fontWeight: 400, color: 'var(--mm-muted)' }}> (du)</span>}</strong>
            {u.role === 'admin' && <Badge tone="sage" size="sm">Admin</Badge>}
            {!u.active && <Badge tone="neutral" size="sm">Deaktiviert</Badge>}
          </span>
          <span style={{ fontSize: 14, color: 'var(--mm-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{u.email}</span>
          {!desktop && <span style={{ fontSize: 14, color: 'var(--mm-muted)' }}>{meta(u)}</span>}
        </span>
        {desktop && <span style={{ fontSize: 14, color: 'var(--mm-muted)', textAlign: 'right', whiteSpace: 'nowrap' }}>{meta(u)}</span>}
        <span onClick={(e) => e.stopPropagation()} style={{ display: 'inline-flex', transform: open ? 'rotate(-90deg)' : 'rotate(90deg)' }}>
          <IconButton icon="chevronRight" label={open ? `Aktionen für ${u.name} schließen` : `Aktionen für ${u.name}`} aria-expanded={open} aria-controls={panelId} onClick={onToggle} />
        </span>
      </div>
      {open && (
        <div id={panelId} style={{ padding: '4px var(--mm-space-4) var(--mm-space-4)', paddingLeft: desktop ? 'calc(var(--mm-space-4) + 36px + var(--mm-space-3))' : 'var(--mm-space-4)', background: 'var(--mm-paper)', display: 'grid', gap: 'var(--mm-space-3)' }}>
          {note && <Callout tone="info" title={note.title}>{note.body}</Callout>}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 'var(--mm-space-2)', flexWrap: 'wrap' }}>
            <span style={{ marginRight: 'auto' }}><RoleSelect id={`role-${u.id}`} compact value={u.role} disabled={u.me} onChange={(r) => { onChange({ ...u, role: r }); setNote({ title: `${u.name} ist jetzt ${roleLabel(r)}` }); }} aria-label={`Rolle von ${u.name}`} /></span>
            {!u.me && <Button variant="ghost" size="sm" onClick={() => { onChange({ ...u, active: !u.active }); setNote(u.active ? { title: 'Deaktiviert', body: `${u.name} kann sich nicht mehr anmelden. Die Daten bleiben erhalten.` } : { title: 'Wieder aktiv', body: `${u.name} kann sich wieder anmelden.` }); }}>{u.active ? 'Deaktivieren' : 'Reaktivieren'}</Button>}
            {!u.me && u.active && <Button variant="ghost" size="sm" onClick={() => setNote({ title: 'Link ist unterwegs', body: <>Wir haben einen Link zum Zurücksetzen an <strong>{u.email}</strong> geschickt.</> })}>Passwort zurücksetzen</Button>}
          </div>
          {u.me && <span style={{ fontSize: 14, color: 'var(--mm-muted)', textAlign: 'right' }}>Deine eigene Rolle und deinen Zugang änderst du hier nicht.</span>}
        </div>
      )}
    </li>
  );
}

function AddUserForm({ onAdd, layout }) {
  const { TextField, Button, Callout } = NS();
  const empty = { email: '', name: '', role: 'user' };
  const [v, setV] = React.useState(empty);
  const [err, setErr] = React.useState({});
  const [done, setDone] = React.useState(null);
  const set = (k) => (e) => { setV({ ...v, [k]: e.target.value }); setErr({ ...err, [k]: undefined }); setDone(null); };
  const submit = (e) => {
    e.preventDefault();
    const n = {};
    if (!/^\S+@\S+\.\S+$/.test(v.email.trim())) n.email = 'Bitte eine gültige E-Mail-Adresse eingeben, z. B. name@praxis.de.';
    if (!v.name.trim()) n.name = 'Bitte den Namen der Person eingeben.';
    setErr(n);
    if (Object.keys(n).length) return;
    onAdd({ id: Date.now(), name: v.name.trim(), email: v.email.trim(), role: v.role, last: null, passkeys: 0, active: true });
    setDone({ name: v.name.trim(), email: v.email.trim() }); setV(empty);
  };
  return (
    <form onSubmit={submit} noValidate style={{ background: 'var(--mm-card)', border: '1px solid var(--mm-line)', borderRadius: 'var(--mm-radius-l)', padding: layout === 'desktop' ? 'var(--mm-space-6)' : 'var(--mm-space-5) var(--mm-space-4)', display: 'grid', gap: 'var(--mm-space-4)' }}>
      <h2 style={{ margin: 0, fontSize: 'var(--mm-text-h)', lineHeight: 1.3 }}>Benutzer hinzufügen</h2>
      {done && <Callout tone="info" title={`${done.name} hinzugefügt`}>Wir haben eine Einladung an <strong>{done.email}</strong> geschickt. Darüber legt die Person ihr Passwort fest.</Callout>}
      <TextField label="E-Mail-Adresse" type="email" autoComplete="off" value={v.email} onChange={set('email')} error={err.email} hint="Damit meldet sich die Person an. Wir schicken ihr eine Einladung." />
      <TextField label="Name" autoComplete="off" value={v.name} onChange={set('name')} error={err.name} hint="So wird die Person in MidMind begrüßt." />
      <div className="mm-field">
        <label className="mm-field__label" htmlFor="new-user-role">Rolle</label>
        <RoleSelect id="new-user-role" value={v.role} onChange={(r) => setV({ ...v, role: r })} />
      </div>
      <Button type="submit" block>Einladung senden</Button>
    </form>
  );
}

function UserAdmin({ layout = 'mobile' }) {
  const { DisplayHeading } = NS();
  const [users, setUsers] = React.useState(SEED_USERS);
  const [open, setOpen] = React.useState(null);
  const desktop = layout === 'desktop';
  const inactive = users.filter((u) => !u.active).length;
  const update = (nu) => setUsers((list) => list.map((u) => (u.id === nu.id ? nu : u)));
  return (
    <div style={{ maxWidth: 720, margin: '0 auto', padding: desktop ? 'var(--mm-space-6) var(--mm-space-4) var(--mm-space-7)' : 'var(--mm-space-5) var(--mm-space-4) var(--mm-space-6)', display: 'grid', gap: 'var(--mm-space-5)' }}>
      {desktop && <DisplayHeading as="h1" size="md">Benutzer verwalten</DisplayHeading>}
      <section aria-label="Benutzer" style={{ background: 'var(--mm-card)', border: '1px solid var(--mm-line)', borderRadius: 'var(--mm-radius-l)', overflow: 'hidden' }}>
        <div style={{ padding: 'var(--mm-space-3) var(--mm-space-4)', fontSize: 14, color: 'var(--mm-muted)' }}>
          {users.length} Benutzer{inactive ? ` · ${inactive} deaktiviert` : ''}
        </div>
        <ul style={{ margin: 0, padding: 0 }}>
          {users.map((u) => <UserRowItem key={u.id} u={u} layout={layout} open={open === u.id} onToggle={() => setOpen(open === u.id ? null : u.id)} onChange={update} />)}
        </ul>
      </section>
      <AddUserForm layout={layout} onAdd={(u) => setUsers((l) => [...l, u])} />
    </div>
  );
}

Object.assign(window, { UserAdmin });
})();
