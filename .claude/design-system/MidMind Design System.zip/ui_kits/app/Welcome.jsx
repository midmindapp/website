(() => {
// Einladungs-Seite: einmaliger Link aus der Einladungs-Mail. Schritt 1 Passwort festlegen, Schritt 2 Passkey (optional), dann in die App.
const NS = () => window.MidMindDesignSystem_0ec547;
const INVITE = { name: 'Anna-Carolin Heller', email: 'annacarolinheller@gmail.com', invitedBy: 'Hanna Kröger' };

function StepLabel({ n }) {
  return <span style={{ fontSize: 'var(--mm-text-small)', fontWeight: 600, color: 'var(--mm-muted)' }}>Schritt {n} von 2</span>;
}

function PasswordStep({ invite, onDone }) {
  const { TextField, Button } = NS();
  const [v, setV] = React.useState({ next: invite.demoPassword || '', repeat: invite.demoPassword || '' });
  const [err, setErr] = React.useState({});
  const set = (k) => (e) => { setV({ ...v, [k]: e.target.value }); setErr({ ...err, [k]: undefined }); };
  const submit = (e) => {
    e.preventDefault();
    const n = {};
    if (v.next.length < 10) n.next = 'Dein Passwort braucht mindestens 10 Zeichen.';
    else if (v.repeat !== v.next) n.repeat = 'Die Passwörter stimmen nicht überein.';
    setErr(n);
    if (!Object.keys(n).length) onDone();
  };
  return (
    <form onSubmit={submit} noValidate style={{ display: 'grid', gap: 'var(--mm-space-4)' }}>
      <div style={{ display: 'grid', gap: 4 }}>
        <StepLabel n={1} />
        <h2 style={{ margin: 0, fontSize: 'var(--mm-text-h)', lineHeight: 1.3 }}>Passwort festlegen</h2>
      </div>
      <div style={{ display: 'grid', gap: 2 }}>
        <span style={{ fontSize: 'var(--mm-text-small)', fontWeight: 600 }}>Du meldest dich an mit</span>
        <span style={{ fontSize: 16, overflowWrap: 'anywhere' }}>{invite.email}</span>
      </div>
      <input type="email" autoComplete="username" value={invite.email} readOnly hidden />
      <TextField label="Passwort" type="password" autoComplete="new-password" value={v.next} onChange={set('next')} error={err.next} hint="Mindestens 10 Zeichen." />
      <TextField label="Passwort wiederholen" type="password" autoComplete="new-password" value={v.repeat} onChange={set('repeat')} error={err.repeat} />
      <Button type="submit" block>Weiter</Button>
    </form>
  );
}

function PasskeyStep({ layout, onDone }) {
  const { Button, Icon } = NS();
  const [waiting, setWaiting] = React.useState(false);
  const add = () => {
    setWaiting(true);
    setTimeout(() => onDone({ id: Date.now(), name: layout === 'desktop' ? 'Dieser Rechner' : 'Dieses Gerät', added: '01.10.2026', last: 'heute' }), 1400);
  };
  return (
    <div style={{ display: 'grid', gap: 'var(--mm-space-4)' }}>
      <div style={{ display: 'grid', gap: 4 }}>
        <StepLabel n={2} />
        <h2 style={{ margin: 0, fontSize: 'var(--mm-text-h)', lineHeight: 1.3 }}>Passkey hinzufügen</h2>
      </div>
      <p style={{ margin: 0, fontSize: 16, lineHeight: 1.5, textWrap: 'pretty' }}>Mit einem Passkey meldest du dich auf diesem Gerät per Face ID, Fingerabdruck oder Geräte-PIN an – ohne Passwort. Dein Passwort bleibt für andere Geräte.</p>
      <Button block icon={<Icon name="key" size={20} />} onClick={add} disabled={waiting}>{waiting ? 'Warte auf dein Gerät …' : 'Passkey hinzufügen'}</Button>
      <Button variant="ghost" block onClick={() => onDone(null)} disabled={waiting}>Später</Button>
      <span style={{ fontSize: 14, color: 'var(--mm-muted)', textAlign: 'center' }}>Du kannst Passkeys jederzeit im Konto-Menü unter „Passkeys“ hinzufügen.</span>
    </div>
  );
}

function DoneStep({ passkey, onEnter }) {
  const { Button, Callout } = NS();
  return (
    <div style={{ display: 'grid', gap: 'var(--mm-space-4)' }}>
      <h2 style={{ margin: 0, fontSize: 'var(--mm-text-h)', lineHeight: 1.3 }}>Alles bereit</h2>
      <Callout tone="info" title={passkey ? 'Passwort und Passkey eingerichtet' : 'Passwort festgelegt'}>
        {passkey ? 'Auf diesem Gerät meldest du dich ab jetzt mit deinem Passkey an.' : 'Du meldest dich ab jetzt mit deiner E-Mail-Adresse und deinem Passwort an.'}
      </Callout>
      <Button block onClick={onEnter}>Zu MidMind</Button>
    </div>
  );
}

function ExpiredCard() {
  const { Callout } = NS();
  return (
    <div style={{ display: 'grid', gap: 'var(--mm-space-4)' }}>
      <Callout tone="warning" title="Dieser Link gilt nicht mehr">Einladungslinks funktionieren nur einmal und nur 7 Tage lang.</Callout>
      <p style={{ margin: 0, fontSize: 16, lineHeight: 1.5, textWrap: 'pretty' }}>Bitte die Person, die dich eingeladen hat, um eine neue Einladung. Hast du dein Passwort schon festgelegt? Dann <a href="desktop.html">melde dich hier an</a>.</p>
    </div>
  );
}

function WelcomeScreen({ invite = INVITE, layout = 'mobile', expired = false, onEnter }) {
  const { MidMindRoot, Logo, DisplayHeading } = NS();
  const [step, setStep] = React.useState('password');
  const [passkey, setPasskey] = React.useState(null);
  const desktop = layout === 'desktop';
  const enter = () => onEnter && onEnter({ name: invite.name, email: invite.email, role: 'user', hasPassword: true, passkeys: passkey ? [passkey] : [] });
  const body = expired ? <ExpiredCard />
    : step === 'password' ? <PasswordStep invite={invite} onDone={() => setStep('passkey')} />
    : step === 'passkey' ? <PasskeyStep layout={layout} onDone={(pk) => { setPasskey(pk); setStep('done'); }} />
    : <DoneStep passkey={passkey} onEnter={enter} />;
  return (
    <MidMindRoot style={{ height: '100%', overflow: 'auto', display: 'grid', placeItems: desktop ? 'center' : 'start stretch', padding: desktop ? 'var(--mm-space-5)' : 'var(--mm-space-7) var(--mm-space-4) var(--mm-space-6)', boxSizing: 'border-box' }}>
      <div style={{ width: '100%', maxWidth: 440, margin: '0 auto', display: 'grid', gap: 'var(--mm-space-5)' }}>
        <div style={{ display: 'grid', justifyItems: 'center', gap: 'var(--mm-space-3)', textAlign: 'center' }}>
          <Logo size={desktop ? 64 : 72} wordmark stacked />
          <DisplayHeading as="h1" size="md">{expired ? 'Link abgelaufen.' : `Willkommen, ${firstName(invite.name)}.`}</DisplayHeading>
          {!expired && step === 'password' && <p style={{ margin: 0, fontSize: 16, lineHeight: 1.5, color: 'var(--mm-muted)', textWrap: 'pretty' }}>{invite.invitedBy} hat dich zu MidMind eingeladen. Richte kurz deinen Zugang ein, dann kann es losgehen.</p>}
        </div>
        <div style={desktop ? { background: 'var(--mm-card)', border: '1px solid var(--mm-line)', borderRadius: 'var(--mm-radius-l)', padding: 'var(--mm-space-6)' } : undefined}>{body}</div>
      </div>
    </MidMindRoot>
  );
}

Object.assign(window, { WelcomeScreen, INVITE });
})();
