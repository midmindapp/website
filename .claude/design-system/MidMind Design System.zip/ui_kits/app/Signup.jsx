(() => {
// Selbst-Registrierung: E-Mail → persönlicher Link per Mail → Über dich → Hinweis bestätigen → Passwort → Passkey (optional) → Basis-Zugang.
const NS = () => window.MidMindDesignSystem_0ec547;
const EMAIL_RE = /^\S+@\S+\.\S+$/;
const DEMO = { email: 'lena.vogt@posteo.de', name: 'Lena Vogt', password: 'hebamme-lena-2026' };
const PROFESSIONS = [
  { id: 'hebamme', label: 'Hebamme', confirm: 'Ich bestätige, dass ich als Hebamme tätig bin.' },
  { id: 'studium', label: 'Hebammenstudierende', confirm: 'Ich bestätige, dass ich Hebammenwissenschaft studiere.' },
];
const TOTAL = 4;
const H2 = ({ children }) => <h2 style={{ margin: 0, fontSize: 'var(--mm-text-h)', lineHeight: 1.3 }}>{children}</h2>;
const P = ({ children, muted, style }) => <p style={{ margin: 0, fontSize: 16, lineHeight: 1.55, textWrap: 'pretty', color: muted ? 'var(--mm-muted)' : 'var(--mm-ink)', ...style }}>{children}</p>;

function Check({ id, checked, onChange, error, children }) {
  const [focus, setFocus] = React.useState(false);
  const ease = 'cubic-bezier(.2,.8,.2,1)';
  return (
    <div className={error ? 'mm-field--error' : undefined} style={{ display: 'grid', gap: 4 }}>
      <label htmlFor={id} style={{ display: 'flex', gap: 12, alignItems: 'flex-start', cursor: 'pointer', fontSize: 16, lineHeight: 1.5, padding: '10px 0', fontFamily: 'var(--mm-font)' }}>
        <span style={{ position: 'relative', flex: 'none', width: 22, height: 22, marginTop: 1 }}>
          <input id={id} type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} onFocus={(e) => setFocus(e.target.matches(':focus-visible'))} onBlur={() => setFocus(false)}
            aria-invalid={!!error} aria-describedby={error ? id + '-err' : undefined}
            style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', margin: 0, opacity: 0, cursor: 'pointer' }} />
          <span aria-hidden="true" style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', pointerEvents: 'none', borderRadius: 6, boxSizing: 'border-box',
            border: `2px solid ${checked ? 'var(--mm-moss)' : error ? 'var(--mm-crit)' : 'var(--mm-muted)'}`, background: checked ? 'var(--mm-moss)' : 'var(--mm-card)',
            transform: checked ? 'scale(1)' : 'scale(.92)', boxShadow: focus ? '0 0 0 3px var(--mm-card), 0 0 0 5px var(--mm-focus)' : 'none',
            transition: `background-color 160ms ${ease}, border-color 160ms ${ease}, transform 260ms cubic-bezier(.34,1.56,.64,1)` }}>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path d="M2.5 7.4 5.6 10.3 11.5 3.9" stroke="var(--mm-on-moss)" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"
                pathLength="1" strokeDasharray="1" strokeDashoffset={checked ? 0 : 1}
                style={{ transition: checked ? `stroke-dashoffset 280ms ${ease} 60ms` : `stroke-dashoffset 120ms ease-in` }}></path>
            </svg>
          </span>
        </span>
        <span style={{ textWrap: 'pretty' }}>{children}</span>
      </label>
      {error && <span id={id + '-err'} className="mm-field__hint">{error}</span>}
    </div>
  );
}

function EmailStep({ email, setEmail, onSent }) {
  const { TextField, Button } = NS();
  const [err, setErr] = React.useState(null);
  const submit = (e) => {
    e.preventDefault();
    if (!EMAIL_RE.test(email.trim())) { setErr('Bitte eine gültige E-Mail-Adresse eingeben, z. B. name@praxis.de.'); return; }
    onSent();
  };
  return (
    <form onSubmit={submit} noValidate style={{ display: 'grid', gap: 'var(--mm-space-4)' }}>
      <TextField label="E-Mail-Adresse" type="email" autoComplete="email" value={email} error={err}
        hint="Wir schicken Dir einen persönlichen magischen Link per E-Mail. Damit kannst Du die Anmeldung abschließen."
        onChange={(e) => { setEmail(e.target.value); setErr(null); }} />
      <Button type="submit" block>Link senden</Button>
    </form>
  );
}

function MailPreview({ email, onOpen }) {
  const { Logo, Button } = NS();
  return (
    <div style={{ display: 'grid', gap: 'var(--mm-space-2)' }}>
      <span style={{ fontSize: 14, color: 'var(--mm-muted)', textAlign: 'center' }}>Demo – so sieht die E-Mail aus:</span>
      <div style={{ border: '1px dashed var(--mm-line)', borderRadius: 'var(--mm-radius-l)', overflow: 'hidden', background: 'var(--mm-card)' }}>
        <div style={{ padding: 'var(--mm-space-3) var(--mm-space-4)', borderBottom: '1px solid var(--mm-line)', display: 'grid', gap: 2, fontSize: 14 }}>
          <span><strong>Von:</strong> MidMind &lt;hallo@midmind.de&gt;</span>
          <span style={{ overflowWrap: 'anywhere' }}><strong>An:</strong> {email}</span>
          <span><strong>Betreff:</strong> Dein Link zur Registrierung</span>
        </div>
        <div style={{ padding: 'var(--mm-space-5) var(--mm-space-4)', display: 'grid', gap: 'var(--mm-space-4)', justifyItems: 'start' }}>
          <Logo size={32} wordmark />
          <P>Hallo,<br></br>schön, dass du MidMind ausprobieren möchtest. Über diesen Link richtest du deinen Zugang ein:</P>
          <Button onClick={onOpen}>Registrierung fortsetzen</Button>
          <P muted style={{ fontSize: 14 }}>Der Link funktioniert nur einmal. Du hast dich nicht registriert? Dann ignoriere diese E-Mail einfach.</P>
        </div>
      </div>
    </div>
  );
}

function SentStep({ email, onChangeEmail }) {
  const { Button, Callout } = NS();
  const [resent, setResent] = React.useState(false);
  return (
    <div style={{ display: 'grid', gap: 'var(--mm-space-4)' }}>
      <P>Wir haben einen persönlichen Magic Link an <strong style={{ overflowWrap: 'anywhere' }}>{email}</strong> geschickt. Öffne ihn, um weiterzumachen.</P>
      {resent && <Callout tone="info" title="Neuer Link ist unterwegs">Der vorherige Link gilt nicht mehr.</Callout>}
      <P muted style={{ fontSize: 14 }}>Nichts angekommen? Schau auch im Spam-Ordner nach.</P>
      <div style={{ display: 'flex', gap: 'var(--mm-space-2)', flexWrap: 'wrap' }}>
        <Button variant="secondary" size="sm" onClick={() => setResent(true)}>Erneut senden</Button>
        <Button variant="ghost" size="sm" onClick={onChangeEmail}>Andere Adresse</Button>
      </div>
    </div>
  );
}

function ProfileStep({ email, v, setV, onDone }) {
  const { TextField, Button, Badge } = NS();
  const [err, setErr] = React.useState({});
  const submit = (e) => {
    e.preventDefault();
    const n = {};
    if (!v.name.trim()) n.name = 'Bitte deinen Vor- und Nachnamen eingeben.';
    if (!v.confirmed) n.confirmed = 'Bitte bestätige deine Angabe.';
    setErr(n);
    if (!Object.keys(n).length) onDone();
  };
  return (
    <form onSubmit={submit} noValidate style={{ display: 'grid', gap: 'var(--mm-space-4)' }}>
      <div style={{ display: 'grid', gap: 4 }}><H2>Über dich</H2></div>
      <div style={{ position: 'relative' }}>
        <TextField label="Deine E-Mail" type="email" autoComplete="username" value={email} readOnly aria-readonly="true"
          style={{ background: 'var(--mm-sand)', color: 'var(--mm-muted)', borderColor: 'var(--mm-line)', cursor: 'default', paddingRight: 120 }} />
        <span style={{ position: 'absolute', right: 12, bottom: 14 }}><Badge tone="ok" size="sm">Bestätigt</Badge></span>
      </div>
      <TextField label="Vor- und Nachname" autoComplete="name" value={v.name} error={err.name}
        onChange={(e) => { setV({ ...v, name: e.target.value }); setErr({ ...err, name: undefined }); }} />
      <Check id="confirm-prof" checked={v.confirmed} error={err.confirmed} onChange={(c) => { setV({ ...v, confirmed: c }); setErr({ ...err, confirmed: undefined }); }}>Ich bin examinierte Hebamme oder studiere aktiv Hebammenwissenschaften.</Check>
      <Button type="submit" block disabled={!v.confirmed}>Weiter</Button>
    </form>
  );
}

const DISCLAIMERS = [
  { id: 'ki', strong: 'MidMind ist eine KI und kann Fehler machen.', rest: 'Ich prüfe Antworten anhand der genannten Quellen.' },
  { id: 'mp', strong: 'MidMind ist kein Medizinprodukt und keine Rechtsauskunft,', rest: 'sondern eine Suchmaschine für Fachliteratur und Leitlinien.' },
  { id: 'verantwortung', strong: 'Antworten ersetzen nicht meine fachliche Einschätzung.', rest: 'Die Verantwortung für Beratung und Behandlung liegt bei mir.' },
];

function DisclaimerStep({ onDone }) {
  const { Button } = NS();
  const [ok, setOk] = React.useState({});
  const all = DISCLAIMERS.every((d) => ok[d.id]);
  return (
    <form noValidate onSubmit={(e) => { e.preventDefault(); if (all) onDone(); }} style={{ display: 'grid', gap: 'var(--mm-space-4)' }}>
      <div style={{ display: 'grid', gap: 4 }}><H2>Was ist MidMind?</H2></div>
      <P muted>MidMind richtet sich an examinierte Hebammen und Hebammenstudierende. Bitte bestätige jeden Punkt.</P>
      <div style={{ display: 'grid', gap: 'var(--mm-space-1, 4px)' }}>
        {DISCLAIMERS.map((d) => (
          <Check key={d.id} id={'confirm-' + d.id} checked={!!ok[d.id]} onChange={(c) => setOk({ ...ok, [d.id]: c })}>
            <strong>{d.strong}</strong> {d.rest}
          </Check>
        ))}
      </div>
      <P muted>MidMind ist ein kostenloser Dienst und wir garantieren keine Verfügbarkeit der Webseite.</P>
      <Button type="submit" block disabled={!all}>Weiter</Button>
    </form>
  );
}

function DoneStep({ passkey, onEnter }) {
  const { Button, Callout, Badge } = NS();
  return (
    <div style={{ display: 'grid', gap: 'var(--mm-space-4)' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 'var(--mm-space-2)', flexWrap: 'wrap' }}>
        <H2>Alles bereit</H2>
      </div>
      <Callout tone="info" title={passkey ? 'Passwort und Passkey eingerichtet' : 'Passwort festgelegt'}>
        {passkey ? 'Auf diesem Gerät meldest du dich ab jetzt mit deinem Passkey an.' : 'Du meldest dich ab jetzt mit deiner E-Mail-Adresse und deinem Passwort an.'}
      </Callout>
      <P muted>Du bist angemeldet und kannst direkt deine erste Frage stellen.</P>
      <Button block onClick={onEnter}>MidMind starten</Button>
    </div>
  );
}

function ExpiredStep({ onRestart }) {
  const { Callout, Button } = NS();
  return (
    <div style={{ display: 'grid', gap: 'var(--mm-space-4)' }}>
      <Callout tone="warning" title="Dieser Link gilt nicht mehr">Registrierungslinks funktionieren nur einmal. Vielleicht hast du schon einen neueren angefordert.</Callout>
      <Button block onClick={onRestart}>Neuen Link anfordern</Button>
      <P muted style={{ textAlign: 'center', fontSize: 14 }}>Schon fertig registriert? <a href="desktop.html">Hier anmelden</a></P>
    </div>
  );
}

const STEP_N = { profile: 1, disclaimer: 2, password: 3, passkey: 4 };
function ProgressBar({ n, total, bleed }) {
  return (
    <div style={{ display: 'grid', gap: 0, margin: bleed ? 'calc(-1 * var(--mm-space-6)) calc(-1 * var(--mm-space-6)) var(--mm-space-5)' : '0 0 var(--mm-space-5)' }}>
      <div role="progressbar" aria-label={`Schritt ${n} von ${total}`} aria-valuemin={0} aria-valuemax={total} aria-valuenow={n}
        style={{ height: 6, background: 'var(--mm-line)', borderRadius: bleed ? 0 : 3, overflow: 'hidden' }}>
        <div style={{ height: '100%', width: `${(n / total) * 100}%`, background: 'var(--mm-moss)', borderRadius: '0 3px 3px 0', transition: 'width 400ms cubic-bezier(.2,.8,.2,1)' }}></div>
      </div>
      <span aria-hidden="true" style={{ fontSize: 'var(--mm-text-small)', fontWeight: 600, color: 'var(--mm-moss)', background: 'var(--mm-paper)', padding: bleed ? '6px var(--mm-space-6)' : '6px 12px', borderRadius: bleed ? 0 : '0 0 8px 8px' }}>Schritt {n} von {total}</span>
    </div>
  );
}

const HEADINGS = { email: 'Schön, dass du da bist.', sent: 'Schau in dein Postfach.', expired: 'Link abgelaufen.' };

function SignupScreen({ layout = 'mobile', initialStep = 'email', onEnter }) {
  const { MidMindRoot, Logo, DisplayHeading } = NS();
  const [step, setStep] = React.useState(initialStep);
  const [email, setEmail] = React.useState(DEMO.email);
  const [profile, setProfile] = React.useState({ name: DEMO.name, profession: null, confirmed: false });
  const [passkey, setPasskey] = React.useState(null);
  const desktop = layout === 'desktop';
  const first = firstName(profile.name || DEMO.name);
  const heading = HEADINGS[step] || (step === 'done' ? `Los geht’s, ${first}.` : 'Willkommen bei MidMind.');
  const enter = () => onEnter && onEnter({ name: profile.name.trim(), email, role: 'user', plan: 'basis', profession: profile.profession, hasPassword: true, passkeys: passkey ? [passkey] : [] });
  const body = {
    email: <EmailStep email={email} setEmail={setEmail} onSent={() => setStep('sent')} />,
    sent: <SentStep email={email} onChangeEmail={() => setStep('email')} />,
    profile: <ProfileStep email={email} v={profile} setV={setProfile} onDone={() => setStep('disclaimer')} />,
    disclaimer: <DisclaimerStep onDone={() => setStep('password')} />,
    password: <PasswordStep invite={{ email, demoPassword: DEMO.password }} n={null} total={TOTAL} onDone={() => setStep('passkey')} />,
    passkey: <PasskeyStep layout={layout} n={null} total={TOTAL} onDone={(pk) => { setPasskey(pk); setStep('done'); }} />,
    done: <DoneStep passkey={passkey} onEnter={enter} />,
    expired: <ExpiredStep onRestart={() => setStep('email')} />,
  }[step];
  return (
    <MidMindRoot style={{ height: '100%', overflow: 'auto', display: 'flex', flexDirection: 'column' }}>
      <div style={{ flex: 1, display: 'grid', placeItems: desktop ? 'center' : 'start stretch', padding: desktop ? 'var(--mm-space-6) var(--mm-space-5)' : 'var(--mm-space-6) var(--mm-space-4)', boxSizing: 'border-box' }}>
      <div style={{ width: '100%', maxWidth: 460, margin: '0 auto', display: 'grid', gap: 'var(--mm-space-5)' }}>
        <div style={{ display: 'grid', justifyItems: 'center', gap: 'var(--mm-space-3)', textAlign: 'center' }}>
          <a href="../website/Marketing Website with signup.html" aria-label="Zur MidMind-Website" style={{ display: 'inline-flex' }}><Logo size={desktop ? 64 : 72} wordmark stacked /></a>
          <DisplayHeading as="h1" size="md">{heading}</DisplayHeading>
          {step === 'email' && <P muted>Kostenlos für alle Hebammen und Hebammenstudierenden.</P>}
        </div>
        <div style={desktop ? { background: 'var(--mm-card)', border: '1px solid var(--mm-line)', borderRadius: 'var(--mm-radius-l)', padding: 'var(--mm-space-6)', overflow: 'hidden' } : undefined}>{STEP_N[step] && <ProgressBar n={STEP_N[step]} total={TOTAL} bleed={desktop} />}{body}</div>
        {step === 'sent' && <MailPreview email={email} onOpen={() => setStep('profile')} />}
        {step === 'email' && <P muted style={{ textAlign: 'center', fontSize: 14 }}>Bereits registriert? <a href="desktop.html">Anmelden</a></P>}
      </div>
      </div>
    </MidMindRoot>
  );
}

Object.assign(window, { SignupScreen });
})();
