(() => {
// Anmeldung und Konto: Login, Nutzer-Menü, Formulare für Name/E-Mail und Passwort.
// Menü, Sheet und Dialog sind UI-Kit-Bausteine (kein Gegenstück in @midmind/ui).
const NS = () => window.MidMindDesignSystem_0ec547;
const EMAIL_RE = /^\S+@\S+\.\S+$/;

const DEMO_USER = { name: 'Hanna Kröger', email: 'hanna.kroeger@praxis-mondschein.de', role: 'admin', hasPassword: true, passkeys: [{ id: 1, name: 'iPhone', added: '12.09.2026', last: 'heute' }] };
const firstName = (n) => n.trim().split(/\s+/)[0];
const initials = (n) => n.trim().split(/\s+/).map((p) => p[0]).slice(0, 2).join('').toUpperCase();

function Initials({ name, size = 36 }) {
  return (
    <span aria-hidden="true" style={{ width: size, height: size, borderRadius: 999, background: 'var(--mm-sage)', color: 'var(--mm-ink)', display: 'grid', placeItems: 'center', fontWeight: 700, fontSize: Math.round(size * 0.4), flex: 'none' }}>
      {initials(name)}
    </span>
  );
}

function AvatarButton({ user, onClick }) {
  return (
    <button type="button" onClick={onClick} aria-label="Konto-Menü" title="Konto-Menü"
      style={{ width: 44, height: 44, borderRadius: 999, border: 0, padding: 0, background: 'transparent', display: 'grid', placeItems: 'center', cursor: 'pointer' }}>
      <Initials name={user.name} size={34} />
    </button>
  );
}

function LoginForm({ onLogin }) {
  const { TextField, Button, Callout, Icon } = NS();
  const [email, setEmail] = React.useState(DEMO_USER.email);
  const [waiting, setWaiting] = React.useState(false);
  const [pw, setPw] = React.useState('');
  const [err, setErr] = React.useState({});
  const [reset, setReset] = React.useState(false);
  const submit = (e) => {
    e.preventDefault();
    const n = {};
    if (!EMAIL_RE.test(email)) n.email = 'Bitte eine gültige E-Mail-Adresse eingeben, z. B. name@praxis.de.';
    if (!pw) n.pw = 'Bitte dein Passwort eingeben.';
    setErr(n);
    if (!n.email && !n.pw) onLogin({ ...DEMO_USER, email });
  };
  const passkey = () => {
    setErr({}); setWaiting(true);
    setTimeout(() => { setWaiting(false); onLogin(DEMO_USER); }, 1400);
  };
  const forgot = () => {
    if (!EMAIL_RE.test(email)) { setErr({ email: 'Trag zuerst deine E-Mail-Adresse ein.' }); return; }
    setErr({}); setReset(true);
  };
  return (
    <form onSubmit={submit} noValidate style={{ display: 'grid', gap: 'var(--mm-space-4)' }}>
      {reset && <Callout tone="info" title="Link ist unterwegs">Wir haben dir einen Link zum Zurücksetzen an <strong>{email}</strong> geschickt.</Callout>}
      <TextField label="E-Mail-Adresse" type="email" autoComplete="email" value={email} error={err.email}
        onChange={(e) => { setEmail(e.target.value); setErr({ ...err, email: undefined }); }} />
      <TextField label="Passwort" type="password" autoComplete="current-password" value={pw} error={err.pw}
        onChange={(e) => { setPw(e.target.value); setErr({ ...err, pw: undefined }); }} />
      <Button type="submit" block disabled={waiting}>Anmelden</Button>
      <Button variant="ghost" size="sm" onClick={forgot} style={{ justifySelf: 'center', border: 0 }}>Passwort vergessen?</Button>
      <div aria-hidden="true" style={{ display: 'flex', alignItems: 'center', gap: 'var(--mm-space-3)', color: 'var(--mm-muted)', fontSize: 'var(--mm-text-small)' }}>
        <span style={{ flex: 1, height: 1, background: 'var(--mm-line)' }}></span>oder<span style={{ flex: 1, height: 1, background: 'var(--mm-line)' }}></span>
      </div>
      <Button variant="secondary" block icon={<Icon name="key" size={20} />} onClick={passkey} disabled={waiting}>{waiting ? 'Warte auf deinen Passkey …' : 'Mit Passkey anmelden'}</Button>
    </form>
  );
}

function BetaNote() {
  return (
    <p style={{ margin: 0, fontSize: 'var(--mm-text-small)', color: 'var(--mm-muted)', lineHeight: 1.5, textAlign: 'center', textWrap: 'pretty' }}>
      Noch kein Zugang? MidMind ist in der geschlossenen Testphase. <a href="../website/index.html#testphase">Einladung anfragen</a>
    </p>
  );
}

function LoginScreen({ layout = 'mobile', onLogin }) {
  const { MidMindRoot, Logo, DisplayHeading } = NS();
  if (layout === 'desktop') {
    return (
      <MidMindRoot style={{ height: '100%', display: 'grid', placeItems: 'center', padding: 'var(--mm-space-5)', boxSizing: 'border-box', overflow: 'auto' }}>
        <div style={{ width: '100%', maxWidth: 440, display: 'grid', gap: 'var(--mm-space-5)' }}>
          <div style={{ display: 'grid', justifyItems: 'center', gap: 'var(--mm-space-4)' }}>
            <Logo size={96} wordmark stacked />
            <DisplayHeading as="h1" size="md">Willkommen zurück.</DisplayHeading>
          </div>
          <div style={{ background: 'var(--mm-card)', border: '1px solid var(--mm-line)', borderRadius: 'var(--mm-radius-l)', padding: 'var(--mm-space-6)' }}>
            <LoginForm onLogin={onLogin} />
          </div>
          <BetaNote />
        </div>
      </MidMindRoot>
    );
  }
  return (
    <MidMindRoot style={{ height: '100%', display: 'grid', gridTemplateRows: '1fr auto', overflow: 'auto' }}>
      <div style={{ padding: 'var(--mm-space-7) var(--mm-space-4) var(--mm-space-5)', display: 'grid', gap: 'var(--mm-space-6)', alignContent: 'start' }}>
        <div style={{ display: 'grid', justifyItems: 'center', gap: 'var(--mm-space-4)' }}>
          <Logo size={88} wordmark stacked />
          <DisplayHeading as="h1" size="md">Willkommen zurück.</DisplayHeading>
        </div>
        <LoginForm onLogin={onLogin} />
      </div>
      <div style={{ padding: 'var(--mm-space-4) var(--mm-space-4) var(--mm-space-6)' }}><BetaNote /></div>
    </MidMindRoot>
  );
}

const MENU_ITEMS = [
  { id: 'profile', label: 'Name und E-Mail ändern', icon: 'user' },
  { id: 'password', label: 'Passwort ändern', icon: 'lock' },
  { id: 'passkeys', label: 'Passkeys', icon: 'key' },
  { id: 'admin', label: 'Benutzer verwalten', icon: 'user', adminOnly: true, divider: true },
  { id: 'logout', label: 'Abmelden', icon: 'logout', divider: true },
];

function UserMenuList({ user, onSelect }) {
  const { Icon } = NS();
  return (
    <div role="menu" aria-label="Konto" style={{ display: 'grid' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--mm-space-3)', padding: 'var(--mm-space-3) var(--mm-space-4)', borderBottom: '1px solid var(--mm-line)' }}>
        <Initials name={user.name} size={40} />
        <div style={{ display: 'grid', minWidth: 0 }}>
          <strong style={{ fontSize: 16 }}>{user.name}</strong>
          <span style={{ fontSize: 14, color: 'var(--mm-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user.email}</span>
        </div>
      </div>
      <div style={{ padding: 'var(--mm-space-2)', display: 'grid', gap: 2 }}>
        {MENU_ITEMS.filter((m) => !m.adminOnly || user.role === 'admin').map((m) => (m.id === 'password' && !user.hasPassword ? { ...m, label: 'Passwort festlegen' } : m)).map((it) => (
          <React.Fragment key={it.id}>
            {it.divider && <div style={{ height: 1, background: 'var(--mm-line)', margin: '4px 8px' }}></div>}
            <button type="button" role="menuitem" onClick={() => onSelect(it.id)}
              style={{ display: 'flex', alignItems: 'center', gap: 'var(--mm-space-3)', minHeight: 48, padding: '0 12px', border: 0, borderRadius: 12, background: 'transparent', color: 'var(--mm-ink)', font: '600 16px/1.3 var(--mm-font)', textAlign: 'left', cursor: 'pointer' }}
              onMouseEnter={(e) => { e.currentTarget.style.background = 'var(--mm-sand)'; }}
              onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent'; }}>
              <span style={{ color: 'var(--mm-muted)', display: 'inline-flex' }}><Icon name={it.icon} size={20} /></span>
              {it.label}
            </button>
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}

const SCRIM = { position: 'absolute', inset: 0, background: 'rgba(43, 34, 32, .36)', zIndex: 20 };

function Sheet({ onClose, children }) {
  return (
    <div style={SCRIM} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} style={{ position: 'absolute', left: 0, right: 0, bottom: 0, background: 'var(--mm-card)', borderRadius: 'var(--mm-radius-l) var(--mm-radius-l) 0 0', paddingBottom: 'var(--mm-space-5)', boxShadow: 'var(--mm-shadow)' }}>
        <div style={{ width: 40, height: 5, borderRadius: 999, background: 'var(--mm-line)', margin: '10px auto 4px' }}></div>
        {children}
      </div>
    </div>
  );
}

function Popover({ onClose, style, children }) {
  return (
    <>
      <div style={{ position: 'fixed', inset: 0, zIndex: 20 }} onClick={onClose}></div>
      <div style={{ position: 'absolute', zIndex: 21, background: 'var(--mm-card)', border: '1px solid var(--mm-line)', borderRadius: 'var(--mm-radius-m)', boxShadow: 'var(--mm-shadow)', ...style }}>{children}</div>
    </>
  );
}

function Dialog({ title, onClose, width = 480, children }) {
  const { IconButton } = NS();
  return (
    <div style={{ ...SCRIM, display: 'grid', placeItems: 'center', padding: 'var(--mm-space-5)' }} onClick={onClose}>
      <div role="dialog" aria-modal="true" aria-label={title} onClick={(e) => e.stopPropagation()}
        style={{ width: '100%', maxWidth: width, maxHeight: '100%', overflow: 'auto', boxSizing: 'border-box', background: 'var(--mm-card)', borderRadius: 'var(--mm-radius-l)', boxShadow: 'var(--mm-shadow)', padding: 'var(--mm-space-5) var(--mm-space-5) var(--mm-space-5) var(--mm-space-6)', display: 'grid', gap: 'var(--mm-space-4)' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 'var(--mm-space-3)' }}>
          <h2 style={{ margin: 0, fontSize: 'var(--mm-text-h)', lineHeight: 1.3, paddingTop: 8, textWrap: 'balance' }}>{title}</h2>
          <IconButton icon="close" label="Schließen" onClick={onClose} />
        </div>
        {children}
      </div>
    </div>
  );
}

// kind: "profile" | "password"
function AccountForm({ kind, user, onSave, onCancel, layout = 'mobile' }) {
  const { TextField, Button, Callout } = NS();
  const setting = kind === 'password' && !user.hasPassword;
  const canRemove = kind === 'password' && user.hasPassword && user.passkeys.length > 0;
  const [v, setV] = React.useState(kind === 'profile' ? { name: user.name, email: user.email } : { current: '', next: '', repeat: '' });
  const [err, setErr] = React.useState({});
  const [done, setDone] = React.useState(null);
  const set = (k) => (e) => { setV({ ...v, [k]: e.target.value }); setErr({ ...err, [k]: undefined }); setDone(null); };
  const submit = (e) => {
    e.preventDefault();
    const n = {};
    if (kind === 'profile') {
      if (!v.name.trim()) n.name = 'Bitte deinen Namen eingeben.';
      if (!EMAIL_RE.test(v.email)) n.email = 'Bitte eine gültige E-Mail-Adresse eingeben, z. B. name@praxis.de.';
    } else {
      if (!setting && !v.current) n.current = 'Bitte dein aktuelles Passwort eingeben.';
      if (v.next.length < 10) n.next = 'Das neue Passwort braucht mindestens 10 Zeichen.';
      else if (v.repeat !== v.next) n.repeat = 'Die Passwörter stimmen nicht überein.';
    }
    setErr(n);
    if (Object.keys(n).length) return;
    if (kind === 'profile') {
      const mailChanged = v.email !== user.email;
      onSave({ ...user, name: v.name.trim() });
      setDone(mailChanged
        ? { title: 'Name gespeichert', body: <>Bitte bestätige deine neue Adresse über den Link, den wir an <strong>{v.email}</strong> geschickt haben. Bis dahin gilt die alte.</> }
        : { title: 'Gespeichert' });
    } else {
      setV({ current: '', next: '', repeat: '' });
      onSave({ ...user, hasPassword: true });
      setDone(setting
        ? { title: 'Passwort festgelegt', body: 'Du kannst dich jetzt zusätzlich mit E-Mail und Passwort anmelden.' }
        : { title: 'Passwort geändert', body: 'Du bleibst auf diesem Gerät angemeldet.' });
    }
  };
  const removePassword = () => {
    onSave({ ...user, hasPassword: false });
    setV({ current: '', next: '', repeat: '' }); setErr({});
    setDone({ title: 'Passwort entfernt', body: 'Du meldest dich ab jetzt nur noch mit deinem Passkey an.' });
  };
  return (
    <form onSubmit={submit} noValidate style={{ display: 'grid', gap: 'var(--mm-space-4)' }}>
      {done && <Callout tone="info" title={done.title}>{done.body}</Callout>}
      {setting && !done && <p style={{ margin: 0, fontSize: 'var(--mm-text-small)', color: 'var(--mm-muted)', lineHeight: 1.5 }}>Du meldest dich ohne Passwort an, nur mit Passkey. Ein Passwort brauchst du nur für Geräte ohne Passkey.</p>}
      {kind === 'profile' ? (
        <>
          <TextField label="Name" autoComplete="name" value={v.name} onChange={set('name')} error={err.name} hint="So begrüßt dich MidMind." />
          <TextField label="E-Mail-Adresse" type="email" autoComplete="email" value={v.email} onChange={set('email')} error={err.email} hint="Mit dieser Adresse meldest du dich an." />
        </>
      ) : (
        <>
          {!setting && <TextField label="Aktuelles Passwort" type="password" autoComplete="current-password" value={v.current} onChange={set('current')} error={err.current} />}
          <TextField label="Neues Passwort" type="password" autoComplete="new-password" value={v.next} onChange={set('next')} error={err.next} hint="Mindestens 10 Zeichen." />
          <TextField label="Neues Passwort wiederholen" type="password" autoComplete="new-password" value={v.repeat} onChange={set('repeat')} error={err.repeat} />
        </>
      )}
      {layout === 'desktop'
        ? <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 'var(--mm-space-3)', marginTop: 'var(--mm-space-2)' }}>
            <Button variant="ghost" onClick={onCancel}>{done ? 'Schließen' : 'Abbrechen'}</Button>
            <Button type="submit">{setting ? 'Passwort festlegen' : 'Speichern'}</Button>
          </div>
        : <Button type="submit" block>{setting ? 'Passwort festlegen' : 'Speichern'}</Button>}
      {canRemove && (
        <div style={{ borderTop: '1px solid var(--mm-line)', paddingTop: 'var(--mm-space-4)', display: 'grid', gap: 'var(--mm-space-3)' }}>
          <div style={{ display: 'grid', gap: 4 }}>
            <strong style={{ fontSize: 16 }}>Ohne Passwort anmelden</strong>
            <span style={{ fontSize: 'var(--mm-text-small)', color: 'var(--mm-muted)', lineHeight: 1.5 }}>Du hast {user.passkeys.length === 1 ? 'einen Passkey' : user.passkeys.length + ' Passkeys'}. Entferne dein Passwort, dann meldest du dich nur noch per Passkey an.</span>
          </div>
          <Button variant="ghost" onClick={removePassword} style={layout === 'desktop' ? { justifySelf: 'start' } : undefined} block={layout !== 'desktop'}>Passwort entfernen</Button>
        </div>
      )}
    </form>
  );
}

const ACCOUNT_TITLES = { profile: 'Name und E-Mail', password: 'Passwort ändern', passkeys: 'Passkeys', admin: 'Benutzer verwalten' };

function PasskeyManager({ user, onSave, onCancel, layout = 'mobile' }) {
  const { Button, Callout, Icon } = NS();
  const keys = user.passkeys;
  const setKeys = (fn) => onSave({ ...user, passkeys: fn(user.passkeys) });
  const [adding, setAdding] = React.useState(false);
  const [msg, setMsg] = React.useState(null);
  const add = () => {
    setAdding(true); setMsg(null);
    setTimeout(() => {
      setAdding(false);
      setKeys((k) => [...k, { id: Date.now(), name: layout === 'desktop' ? 'Dieser Rechner' : 'Dieses Gerät', added: '27.09.2026', last: 'noch nie' }]);
      setMsg({ title: 'Passkey hinzugefügt', body: 'Ab jetzt kannst du dich auf diesem Gerät ohne Passwort anmelden.' });
    }, 1400);
  };
  const remove = (id) => {
    if (!user.hasPassword && keys.length === 1) { setMsg({ tone: 'warning', title: 'Das ist dein einziger Anmeldeweg', body: 'Füge zuerst einen weiteren Passkey hinzu oder lege ein Passwort fest.' }); return; }
    setKeys((k) => k.filter((x) => x.id !== id)); setMsg({ title: 'Passkey entfernt' });
  };
  return (
    <div style={{ display: 'grid', gap: 'var(--mm-space-4)' }}>
      <p style={{ margin: 0, fontSize: 'var(--mm-text-small)', color: 'var(--mm-muted)', lineHeight: 1.5 }}>Mit einem Passkey meldest du dich per Face ID, Fingerabdruck oder Geräte-PIN an – ohne Passwort. {user.hasPassword ? 'Wenn du möchtest, kannst du dein Passwort danach unter „Passwort ändern“ entfernen.' : 'Du meldest dich derzeit nur mit Passkey an.'}</p>
      {msg && <Callout tone={msg.tone || 'info'} title={msg.title}>{msg.body}</Callout>}
      <div style={{ display: 'grid', gap: 'var(--mm-space-2)' }}>
        {keys.length === 0 && <div style={{ padding: 'var(--mm-space-4)', border: '2px dashed var(--mm-line)', borderRadius: 'var(--mm-radius-m)', color: 'var(--mm-muted)', fontSize: 'var(--mm-text-small)', textAlign: 'center' }}>Noch kein Passkey eingerichtet.</div>}
        {keys.map((k) => (
          <div key={k.id} style={{ display: 'flex', alignItems: 'center', gap: 'var(--mm-space-3)', padding: 'var(--mm-space-3) var(--mm-space-4)', background: 'var(--mm-paper)', border: '1px solid var(--mm-line)', borderRadius: 'var(--mm-radius-m)' }}>
            <span style={{ color: 'var(--mm-muted)', display: 'inline-flex' }}><Icon name="key" size={22} /></span>
            <span style={{ display: 'grid', flex: 1, minWidth: 0 }}>
              <strong style={{ fontSize: 16 }}>{k.name}</strong>
              <span style={{ fontSize: 14, color: 'var(--mm-muted)' }}>Hinzugefügt {k.added} · zuletzt genutzt {k.last}</span>
            </span>
            <Button variant="ghost" size="sm" onClick={() => remove(k.id)}>Entfernen</Button>
          </div>
        ))}
      </div>
      {layout === 'desktop'
        ? <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 'var(--mm-space-3)', marginTop: 'var(--mm-space-2)' }}>
            <Button variant="ghost" onClick={onCancel}>Schließen</Button>
            <Button icon={<Icon name="plus" size={18} />} onClick={add} disabled={adding}>{adding ? 'Warte auf dein Gerät …' : 'Passkey hinzufügen'}</Button>
          </div>
        : <Button block icon={<Icon name="plus" size={18} />} onClick={add} disabled={adding}>{adding ? 'Warte auf dein Gerät …' : 'Passkey hinzufügen'}</Button>}
    </div>
  );
}

Object.assign(window, { DEMO_USER, firstName, Initials, AvatarButton, LoginScreen, UserMenuList, Sheet, Popover, Dialog, AccountForm, PasskeyManager, ACCOUNT_TITLES });
})();
