(() => {
function MobileApp() {
  const { MidMindRoot, AppBar, IconButton, Badge, Composer, TabBar } = window.MidMindDesignSystem_0ec547;
  const [user, setUser] = React.useState(null);
  const [night, setNight] = React.useState(false);
  const [textSize, setTextSize] = React.useState('normal');
  const [showText, setShowText] = React.useState(false);
  const [tab, setTab] = React.useState('fragen');
  const [phase, setPhase] = React.useState(null);
  const [turns, setTurns] = React.useState([]);
  const [menu, setMenu] = React.useState(false);
  const [account, setAccount] = React.useState(null); // 'profile' | 'password' | 'passkeys'
  const [source, setSource] = React.useState(null);
  const scrollRef = React.useRef(null);

  React.useEffect(() => { const el = scrollRef.current; if (el) el.scrollTop = el.scrollHeight; }, [turns]);
  if (!user) return <LoginScreen layout="mobile" onLogin={(u) => { setUser(u); setTab('fragen'); setTurns([]); }} />;

  const ask = (q, key) => { setTab('fragen'); setTurns((t) => [...t, { q, key: key || matchAnswer(q) }]); };
  const open = (k) => { setTab('fragen'); setTurns([{ q: ANSWERS[k].question, key: k }]); };
  const onTab = (id) => { if (id === 'fragen' && tab === 'fragen') setTurns([]); setTab(id); };
  const pick = (id) => { setMenu(false); if (id === 'logout') { setUser(null); setAccount(null); } else setAccount(id); };

  const inChat = tab === 'fragen' && turns.length > 0;
  const current = inChat ? ANSWERS[turns[turns.length - 1].key] : null;
  const home = tab === 'fragen' && !inChat;
  const avatar = <AvatarButton user={user} onClick={() => setMenu(true)} />;
  const nightBtn = <IconButton icon={night ? 'sun' : 'moon'} label={night ? 'Tagmodus' : 'Nachtmodus'} onClick={() => setNight(!night)} />;

  let bar, body, composer = true;
  if (account) {
    bar = <AppBar title={account === 'password' && !user.hasPassword ? 'Passwort festlegen' : ACCOUNT_TITLES[account]} leading={<IconButton icon="chevronLeft" label="Zurück" onClick={() => setAccount(null)} />} />;
    body = account === 'admin' ? <div style={{ overflow: 'auto', minHeight: 0 }}><UserAdmin /></div> : <div style={{ padding: 'var(--mm-space-5) var(--mm-space-4)', overflow: 'auto', minHeight: 0 }}>{account === 'passkeys' ? <PasskeyManager user={user} onSave={setUser} /> : <AccountForm key={account} kind={account} user={user} onSave={setUser} />}</div>;
    composer = false;
  } else if (inChat) {
    bar = <AppBar title={current.title} leading={<IconButton icon="chevronLeft" label="Neue Frage" onClick={() => setTurns([])} />} trailing={<Badge phase={current.phase} size="sm" />} />;
    body = <Conversation turns={turns} scrollRef={scrollRef} onClick={(e) => { const l = sourceFromClick(e); if (l) setSource(l); }} />;
  } else if (home) {
    bar = <HomeBar night={night} onNight={() => setNight(!night)} onText={() => setShowText(!showText)} account={avatar} />;
    body = <StartScreen phase={phase} onPhase={setPhase} onAsk={ask} name={firstName(user.name)} />;
  } else if (tab === 'verlauf') {
    bar = <AppBar title="Verlauf" trailing={<>{nightBtn}{avatar}</>} />;
    body = <HistoryList activeKey={turns[0]?.key} onOpen={open} />;
  } else {
    bar = <AppBar title="Leitlinien" trailing={<>{nightBtn}{avatar}</>} />;
    body = <LeitlinienList compact />;
  }

  return (
    <MidMindRoot theme={night ? 'night' : 'day'} textSize={textSize}
      style={{ position: 'relative', display: 'grid', gridTemplateRows: 'auto auto 1fr auto auto', height: '100%', overflow: 'hidden' }}>
      {bar}
      {showText && home && !account ? <TextSizePanel value={textSize} onChange={setTextSize} /> : <div></div>}
      {body}
      {composer
        ? <div style={{ padding: 'var(--mm-space-3) var(--mm-space-4)' }}>
            {inChat
              ? <Composer placeholder="Nachfragen …" onSubmit={(q) => ask(q)} disclaimer={DISCLAIMER} />
              : <Composer placeholder="Frage stellen …" searchIcon dictation onSubmit={(q) => { setTurns([]); ask(q); }} disclaimer={home ? undefined : DISCLAIMER} />}
          </div>
        : <div></div>}
      {account ? <div></div> : <TabBar items={APP_TABS} activeId={tab} onChange={onTab} />}
      {source && <SourceOverlay label={source} onClose={() => setSource(null)} />}
      {menu && <Sheet onClose={() => setMenu(false)}><UserMenuList user={user} onSelect={pick} /></Sheet>}
    </MidMindRoot>
  );
}

window.MobileApp = MobileApp;
})();
