import React from "react";
function cx(...p) { return p.filter(Boolean).join(" "); }

/** Wurzel jeder MidMind-Oberfläche: Hintergrund, Schrift, Fokusrahmen, Nachtmodus, Textgröße. */
export function MidMindRoot({ theme = "day", textSize = "normal", className, children, ...rest }) {
  return (
    <div className={cx("mm-root", className)} data-mm-theme={theme} data-mm-text={textSize === "normal" ? undefined : textSize} {...rest}>
      {children}
    </div>
  );
}
