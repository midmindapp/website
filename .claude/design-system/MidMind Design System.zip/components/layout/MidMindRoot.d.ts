import * as React from 'react';

/**
 * MidMindRoot — MidMind UI (ported from @midmind/ui@0.1.0).
 */
export interface MidMindRootProps {
  /** "day" (Standard), "night" (warmes Dunkel für Kreißsaal und Nachtbesuche) oder "system" (folgt dem Gerät). */
  theme?: "day" | "night" | "system";
  /** Grundschriftgröße der Antworten: normal 18 px, large 20 px, xlarge 22 px. */
  textSize?: "normal" | "large" | "xlarge";
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const MidMindRoot: React.ComponentType<MidMindRootProps>;
