Wurzel jeder MidMind-Oberfläche. Setzt Hintergrund (Leinen), Schrift (Atkinson Hyperlegible), Fokusrahmen, Nachtmodus und Textgröße. **Einmal um den ganzen Bildschirm legen** – ohne sie fehlen Hintergrund und Schrift, und der Nachtmodus greift nicht.

```tsx
<MidMindRoot theme="night" textSize="large">
  <AppBar title="MidMind" leading={<Logo size={30} />} />
  …
</MidMindRoot>
```

- `theme="night"` im Kreißsaal und bei Nachtbesuchen; `"system"` folgt dem Gerät.
- `textSize` mit `TextSizeSwitch` verbinden.

## Props

```ts
interface MidMindRootProps {
  /** "day" (Standard), "night" (warmes Dunkel für Kreißsaal und Nachtbesuche) oder "system" (folgt dem Gerät). */
  theme?: "day" | "night" | "system";
  /** Grundschriftgröße der Antworten: normal 18 px, large 20 px, xlarge 22 px. */
  textSize?: "normal" | "large" | "xlarge";
  className?: string;
  id?: string;
  style?: react.CSSProperties;
  children?: React.ReactNode;
}
```

Load via `window.MidMindDesignSystem_0ec547.MidMindRoot` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
