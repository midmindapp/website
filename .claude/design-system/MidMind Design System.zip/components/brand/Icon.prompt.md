Linien-Icons (2 px, runde Enden), übernehmen die Textfarbe. Namen: alert, info, send, copy, book, moon, sun, folder, text, search, mic, chevronRight, chevronLeft, chat, note, clock, plus, check, menu, close.

```tsx
<Icon name="book" size={22} />
<Icon name="alert" label="Warnung" />   // mit label nicht mehr dekorativ
```

Keine Emoji als Icons verwenden.

## Props

```ts
interface IconProps {
  /** Welches Icon. */
  name: "info" | "alert" | "send" | "copy" | "book" | "moon" | "sun" | "folder" | "text" | "search" | "mic" | "chevronRight" | "chevronLeft" | "chat" | "note" | "clock" | "plus" | "check" | "menu" | "close" | "user" | "lock" | "mail" | "key" | "logout";
  /** Kantenlänge in px. Standard 22. */
  size?: number;
  /** Zugänglicher Name. Ohne label ist das Icon dekorativ (aria-hidden). */
  label?: string;
  className?: string;
  id?: string;
  style?: react.CSSProperties;
  children?: React.ReactNode;
  /** Allows getting a ref to the component instance. Once the component unmounts, React will set `ref.current` to `null` (or  */
  ref?: string | ((instance: SVGSVGElement) => void | react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof react.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | react.RefObject<SVGSVGElement>;
}
```

Load via `window.MidMindDesignSystem_0ec547.Icon` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
