Das MidMind-Zeichen (Gehirn aus vernetztem Wissen + Schwangere im Profil), optional mit Original-Schriftzug. Übernimmt die Textfarbe; im Nachtmodus automatisch hell.

```tsx
<Logo size={30} />                          // App-Bar
<Logo size={64} wordmark tone="moss" />     // Kopfzeile, Schriftzug daneben
<Logo size={160} wordmark stacked />        // Original-Lockup, Schriftzug darunter
```

- Ein Zeichen für alle Größen (vektorisiert aus der Originaldatei). Unter 32 px nicht verwenden.
- Schutzraum: halbe Zeichenhöhe rundum.
- Dateien für außerhalb von React: `assets/logo/midmind-mark*.svg`, `midmind-lockup.svg`, `midmind-wordmark.svg`.

## Props

```ts
interface LogoProps {
  /** Breite des Zeichens in px. Standard 44. */
  size?: number;
  /** Original-Schriftzug „MidMind“ neben dem Zeichen zeigen. */
  wordmark?: boolean;
  /** Mit wordmark: Schriftzug unter dem Zeichen (Original-Lockup) statt daneben. */
  stacked?: boolean;
  /** "ink" (Walnuss, Standard) oder "moss" (Markengrün). Im Nachtmodus automatisch hell. */
  tone?: "ink" | "moss";
  className?: string;
  style?: React.CSSProperties;
}
```

Load via `window.MidMindDesignSystem_0ec547.Logo` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
