import React from "react";
function cx(...p) { return p.filter(Boolean).join(" "); }

/** Warme Serifen-Überschrift (Young Serif). Nur für Website und Begrüßungen, nicht für Antworten. */
export function DisplayHeading({ as: Tag = "h1", size = "xl", className, ...rest }) {
  return <Tag className={cx("mm-display", `mm-display--${size}`, className)} {...rest} />;
}
