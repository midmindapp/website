import * as React from 'react';

/**
 * DisplayHeading — MidMind UI (ported from @midmind/ui@0.1.0).
 */
export interface DisplayHeadingProps {
  /** Überschriftenebene. Standard h1. */
  as?: "h1" | "h2" | "h3";
  /** "xl" 40–72 px (Hero), "lg" 30–48 px (Abschnitt), "md" 28 px. */
  size?: "md" | "xl" | "lg";
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const DisplayHeading: React.ComponentType<DisplayHeadingProps>;
