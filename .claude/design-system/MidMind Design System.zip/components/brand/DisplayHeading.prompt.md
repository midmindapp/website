Warme Serifen-Überschrift (Young Serif) für Website-Hero, Abschnitte und die Begrüßung in der App. Nie in Antworten.

```tsx
<DisplayHeading>Der intelligente Begleiter für Hebammen.</DisplayHeading>
<DisplayHeading as="h2" size="md">Guten Abend, Hanna.</DisplayHeading>
```

## Props

```ts
interface DisplayHeadingProps {
  /** Überschriftenebene. Standard h1. */
  as?: "h1" | "h2" | "h3";
  /** "xl" 40–72 px (Hero), "lg" 30–48 px (Abschnitt), "md" 28 px. */
  size?: "md" | "xl" | "lg";
  className?: string;
  id?: string;
  style?: react.CSSProperties;
  children?: React.ReactNode;
}
```

Load via `window.MidMindDesignSystem_0ec547.DisplayHeading` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
