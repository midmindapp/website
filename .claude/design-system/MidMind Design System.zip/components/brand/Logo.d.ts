import * as React from 'react';

/**
 * Logo — MidMind UI (ported from @midmind/ui@0.1.0).
 */
export interface LogoProps {
  /** Breite des Zeichens in px. Standard 44. */
  size?: number;
  /** Veraltet – es gibt nur noch ein Zeichen für alle Größen. */
  variant?: "full" | "small";
  /** Original-Schriftzug „MidMind“ neben dem Zeichen zeigen. */
  wordmark?: boolean;
  /** Mit wordmark: Schriftzug unter dem Zeichen (Original-Lockup) statt daneben. */
  stacked?: boolean;
  /** "ink" (Walnuss, Standard) oder "moss" (Markengrün). Im Nachtmodus automatisch hell. */
  tone?: "ink" | "moss";
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Logo: React.ComponentType<LogoProps>;
