import * as React from 'react';

export type IconName = "info" | "alert" | "send" | "copy" | "book" | "moon" | "sun" | "folder" | "text" | "search" | "mic" | "chevronRight" | "chevronLeft" | "chat" | "note" | "clock" | "plus" | "check" | "menu" | "close" | "user" | "lock" | "mail" | "key" | "logout";

/**
 * Icon — MidMind UI (ported from @midmind/ui@0.1.0).
 */
export interface IconProps {
  /** Welches Icon. */
  name: IconName;
  /** Kantenlänge in px. Standard 22. */
  size?: number;
  /** Zugänglicher Name. Ohne label ist das Icon dekorativ (aria-hidden). */
  label?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Icon: React.ComponentType<IconProps>;

export declare const ICON_NAMES: IconName[];
