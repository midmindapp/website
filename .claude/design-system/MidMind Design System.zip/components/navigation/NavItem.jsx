import React from "react";
import { PHASES } from "../feedback/Badge.jsx";
function cx(...p) { return p.filter(Boolean).join(" "); }

/** Eintrag in der Desktop-Seitenleiste: frühere Fragen oder Wissenssammlungen. */
export function NavItem({ label, phase, icon, count, active, className, href = "#", ...rest }) {
  return (
    <a href={href} className={cx("mm-navitem", className)} aria-current={active ? "page" : undefined} {...rest}>
      {phase ? <span className="mm-navitem__dot" style={{ background: PHASES[phase].color }} aria-hidden="true" /> : icon}
      <span className="mm-navitem__label">{label}</span>
      {count !== undefined && <span className="mm-navitem__count">{count}</span>}
    </a>
  );
}
