Untere Navigation der mobilen App. `DEFAULT_TABS` enthält Fragen, Wissen, Notizen, Verlauf.

```tsx
<TabBar items={DEFAULT_TABS} activeId="fragen" onChange={setTab} />
```

## Props

```ts
interface TabBarProps {
  /** Tabs von links nach rechts, 3–5 Stück. */
  items: TabBarItem[];
  /** id des aktiven Tabs. */
  activeId: string;
  /** Wird mit der id des angetippten Tabs aufgerufen. */
  onChange?: (id: string) => void;
  className?: string;
}
```

Load via `window.MidMindDesignSystem_0ec547.TabBar` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
