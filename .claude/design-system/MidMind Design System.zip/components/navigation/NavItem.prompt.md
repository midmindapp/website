Eintrag der Desktop-Seitenleiste (Hintergrund `var(--mm-sand)`). Farbpunkt nach Lebensphase oder ein Icon; optional eine Zahl.

```tsx
<NavItem label="Trinkmenge 9. Lebenstag" phase="wochenbett" active />
<NavItem label="Leitlinien" icon={<Icon name="folder" size={18} />} count={24} />
```

## Props

```ts
interface NavItemProps {
  /** Beschriftung, wird gekürzt. */
  label: string;
  /** Farbpunkt der Lebensphase (für Einträge im Verlauf). */
  phase?: "schwangerschaft" | "geburt" | "wochenbett";
  /** Icon statt Farbpunkt, z. B. <Icon name="folder" size={18} />. */
  icon?: React.ReactNode;
  /** Zahl rechts, z. B. Anzahl Dokumente. */
  count?: number;
  /** Aktueller Eintrag. */
  active?: boolean;
  className?: string;
  id?: string;
  style?: react.CSSProperties;
  children?: React.ReactNode;
}
```

Load via `window.MidMindDesignSystem_0ec547.NavItem` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
