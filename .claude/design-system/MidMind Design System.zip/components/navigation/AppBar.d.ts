import * as React from 'react';

/**
 * AppBar — MidMind UI (ported from @midmind/ui@0.1.0).
 */
export interface AppBarProps {
  /** Titel; wird mit Auslassungspunkten gekürzt. */
  title: React.ReactNode;
  /** Links vom Titel: Logo oder Zurück-Button. */
  leading?: React.ReactNode;
  /** Rechts: IconButtons (Textgröße, Nachtmodus) oder ein Badge. */
  trailing?: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const AppBar: React.ComponentType<AppBarProps>;
