import React from "react";
function cx(...p) { return p.filter(Boolean).join(" "); }

/** Kopfzeile eines App-Bildschirms. 64 px hoch, Titel links, Aktionen rechts. */
export function AppBar({ title, leading, trailing, className, ...rest }) {
  return (
    <header className={cx("mm-appbar", className)} {...rest}>
      {leading && <div className="mm-appbar__slot">{leading}</div>}
      <div className="mm-appbar__title">{title}</div>
      {trailing && <div className="mm-appbar__slot">{trailing}</div>}
    </header>
  );
}
