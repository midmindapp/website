Kopfzeile eines Bildschirms, 64 px.

```tsx
<AppBar title="MidMind" leading={<Logo size={30} />}
  trailing={<><IconButton icon="text" label="Textgröße" /><IconButton icon="moon" label="Nachtmodus" /></>} />
<AppBar title="Trinkmenge 9. Lebenstag" leading={<IconButton icon="chevronLeft" label="Zurück" />}
  trailing={<Badge phase="wochenbett" size="sm" />} />
```

## Props

```ts
interface AppBarProps {
  /** Titel; wird mit Auslassungspunkten gekürzt. */
  title: React.ReactNode;
  /** Links vom Titel: Logo oder Zurück-Button. */
  leading?: React.ReactNode;
  /** Rechts: IconButtons (Textgröße, Nachtmodus) oder ein Badge. */
  trailing?: React.ReactNode;
  className?: string;
  id?: string;
  style?: react.CSSProperties;
  children?: React.ReactNode;
}
```

Load via `window.MidMindDesignSystem_0ec547.AppBar` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
