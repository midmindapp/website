import React from "react";
import { Icon } from "../brand/Icon.jsx";
function cx(...p) { return p.filter(Boolean).join(" "); }

export const DEFAULT_TABS = [
  { id: "fragen", label: "Fragen", icon: "chat" },
  { id: "wissen", label: "Wissen", icon: "book" },
  { id: "notizen", label: "Notizen", icon: "note" },
  { id: "verlauf", label: "Verlauf", icon: "clock" },
];

/** Untere Navigationsleiste der mobilen App. Aktiver Tab mit Salbei-Pille. */
export function TabBar({ items, activeId, onChange, className }) {
  return (
    <nav className={cx("mm-tabbar", className)} aria-label="Hauptnavigation">
      {items.map((it) => (
        <button key={it.id} type="button" className="mm-tabbar__item" aria-current={it.id === activeId ? "page" : undefined} onClick={() => onChange?.(it.id)}>
          <span className="mm-tabbar__pill"><Icon name={it.icon} size={24} /></span>
          {it.label}
        </button>
      ))}
    </nav>
  );
}
