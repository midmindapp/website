import * as React from 'react';

export interface TabBarItem { id: string; label: string; icon: IconName; }
export type IconName = "info" | "alert" | "send" | "copy" | "book" | "moon" | "sun" | "folder" | "text" | "search" | "mic" | "chevronRight" | "chevronLeft" | "chat" | "note" | "clock" | "plus" | "check" | "menu" | "close" | "user" | "lock" | "mail" | "key" | "logout";

/**
 * TabBar — MidMind UI (ported from @midmind/ui@0.1.0).
 */
export interface TabBarProps {
  /** Tabs von links nach rechts, 3–5 Stück. */
  items: TabBarItem[];
  /** id des aktiven Tabs. */
  activeId: string;
  /** Wird mit der id des angetippten Tabs aufgerufen. */
  onChange?: (id: string) => void;
  className?: string;
}

export declare const TabBar: React.ComponentType<TabBarProps>;

export declare const DEFAULT_TABS: TabBarItem[];
