import * as React from 'react';

/**
 * NavItem — MidMind UI (ported from @midmind/ui@0.1.0).
 */
export interface NavItemProps {
  /** Beschriftung, wird gekürzt. */
  label: string;
  /** Farbpunkt der Lebensphase (für Einträge im Verlauf). */
  phase?: "schwangerschaft" | "geburt" | "wochenbett";
  /** Icon statt Farbpunkt, z. B. <Icon name="folder" size={18} />. */
  icon?: React.ReactNode;
  /** Zahl rechts, z. B. Anzahl Dokumente. */
  count?: number;
  /** Aktueller Eintrag. */
  active?: boolean;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const NavItem: React.ComponentType<NavItemProps>;
