import * as React from 'react';

/**
 * IconButton — MidMind UI (ported from @midmind/ui@0.1.0).
 */
export interface IconButtonProps {
  /** Icon aus dem MidMind-Iconset. */
  icon: "info" | "alert" | "send" | "copy" | "book" | "moon" | "sun" | "folder" | "text" | "search" | "mic" | "chevronRight" | "chevronLeft" | "chat" | "note" | "clock" | "plus" | "check" | "menu" | "close";
  /** Zugänglicher Name, Pflicht – der Button hat keinen sichtbaren Text. */
  label: string;
  /** "plain" (Standard), "outline" (mit Rahmen) oder "primary" (Moos, z. B. Senden). */
  variant?: "primary" | "plain" | "outline";
  /** "md" 44 px (Standard) oder "lg" 48 px. */
  size?: "md" | "lg";
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}

export declare const IconButton: React.ComponentType<IconButtonProps>;
