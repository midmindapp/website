Pillenförmig, 48 px hoch (`size="sm"`: 44 px).

```tsx
<Button>Frage stellen</Button>
<Button variant="secondary">Testphase anfragen</Button>
<Button variant="ghost" size="sm" icon={<Icon name="copy" size={18} />}>Kopieren</Button>
```

- Höchstens **ein** `primary` pro Ansicht.
- Beschriftung sagt, was passiert („In Notizen speichern“, nicht „OK“).

## Props

```ts
interface ButtonProps {
  /** "primary" (Moos, höchstens einer pro Ansicht), "secondary" (Salbei), "ghost" (nur Rahmen). */
  variant?: "primary" | "secondary" | "ghost";
  /** "md" 48 px hoch (Standard), "sm" 44 px für Aktionen in Antworten. */
  size?: "md" | "sm";
  /** Icon vor dem Text, z. B. <Icon name="copy" size={18} />. */
  icon?: React.ReactNode;
  /** Volle Breite. */
  block?: boolean;
  className?: string;
  id?: string;
  style?: react.CSSProperties;
  children?: React.ReactNode;
}
```

Load via `window.MidMindDesignSystem_0ec547.Button` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
