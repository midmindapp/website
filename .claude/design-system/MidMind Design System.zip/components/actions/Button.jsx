import React from "react";
function cx(...p) { return p.filter(Boolean).join(" "); }

/** Pillenförmiger Button, mindestens 44 px hoch. Höchstens ein primary pro Ansicht. */
export function Button({ variant = "primary", size = "md", icon, block, className, type = "button", children, ...rest }) {
  return (
    <button
      type={type}
      className={cx("mm-button", `mm-button--${variant}`, size === "sm" && "mm-button--sm", block && "mm-button--block", className)}
      {...rest}
    >
      {icon}
      {children}
    </button>
  );
}
