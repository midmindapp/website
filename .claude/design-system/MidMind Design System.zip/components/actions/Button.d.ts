import * as React from 'react';

/**
 * Button — MidMind UI (ported from @midmind/ui@0.1.0).
 * @replaces button
 */
export interface ButtonProps {
  /** "primary" (Moos, höchstens einer pro Ansicht), "secondary" (Salbei), "ghost" (nur Rahmen). */
  variant?: "primary" | "secondary" | "ghost";
  /** "md" 48 px hoch (Standard), "sm" 44 px für Aktionen in Antworten. */
  size?: "md" | "sm";
  /** Icon vor dem Text, z. B. <Icon name="copy" size={18} />. */
  icon?: React.ReactNode;
  /** Volle Breite. */
  block?: boolean;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Button: React.ComponentType<ButtonProps>;
