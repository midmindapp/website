Große Vorschlagsfrage auf der Startseite, volle Breite, Pfeil rechts. Mehrere in einer Spalte mit 8 px Abstand.

```tsx
<SuggestionButton onClick={() => ask('Trinkmenge Neugeborenes nach Lebenstag')}>
  Trinkmenge Neugeborenes nach Lebenstag
</SuggestionButton>
```

## Props

```ts
interface SuggestionButtonProps {
  className?: string;
  id?: string;
  style?: react.CSSProperties;
  children?: React.ReactNode;
}
```

Load via `window.MidMindDesignSystem_0ec547.SuggestionButton` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
