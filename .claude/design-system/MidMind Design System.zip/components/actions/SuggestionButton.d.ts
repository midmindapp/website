import * as React from 'react';

/**
 * SuggestionButton — MidMind UI (ported from @midmind/ui@0.1.0).
 */
export interface SuggestionButtonProps {
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const SuggestionButton: React.ComponentType<SuggestionButtonProps>;
