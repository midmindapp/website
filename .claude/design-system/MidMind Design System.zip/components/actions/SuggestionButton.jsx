import React from "react";
import { Icon } from "../brand/Icon.jsx";
function cx(...p) { return p.filter(Boolean).join(" "); }

/** Große tippbare Vorschlagsfrage auf der Startseite, mit Pfeil rechts. */
export function SuggestionButton({ className, children, type = "button", ...rest }) {
  return (
    <button type={type} className={cx("mm-suggestion", className)} {...rest}>
      <span>{children}</span>
      <Icon name="chevronRight" size={18} />
    </button>
  );
}
