import React from "react";
import { Icon } from "../brand/Icon.jsx";
function cx(...p) { return p.filter(Boolean).join(" "); }

/** Runder Button nur mit Icon, z. B. Zurück, Nachtmodus, Kopieren, Senden. */
export function IconButton({ icon, label, variant = "plain", size = "md", className, type = "button", ...rest }) {
  return (
    <button
      type={type} aria-label={label} title={label}
      className={cx("mm-icon-button", variant !== "plain" && `mm-icon-button--${variant}`, size === "lg" && "mm-icon-button--lg", className)}
      {...rest}
    >
      <Icon name={icon} size={variant === "primary" ? 20 : 22} />
    </button>
  );
}
