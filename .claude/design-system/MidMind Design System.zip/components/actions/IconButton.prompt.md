Runder Button nur mit Icon. `label` ist Pflicht (Screenreader, Tooltip).

```tsx
<IconButton icon="chevronLeft" label="Zurück" />
<IconButton icon="moon" label="Nachtmodus" />
<IconButton icon="send" label="Senden" variant="primary" />
```

## Props

```ts
interface IconButtonProps {
  /** Icon aus dem MidMind-Iconset. */
  icon: "info" | "alert" | "send" | "copy" | "book" | "moon" | "sun" | "folder" | "text" | "search" | "mic" | "chevronRight" | "chevronLeft" | "chat" | "note" | "clock" | "plus" | "check" | "menu" | "close";
  /** Zugänglicher Name, Pflicht – der Button hat keinen sichtbaren Text. */
  label: string;
  /** "plain" (Standard), "outline" (mit Rahmen) oder "primary" (Moos, z. B. Senden). */
  variant?: "primary" | "plain" | "outline";
  /** "md" 44 px (Standard) oder "lg" 48 px. */
  size?: "md" | "lg";
  className?: string;
  id?: string;
  style?: react.CSSProperties;
}
```

Load via `window.MidMindDesignSystem_0ec547.IconButton` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
