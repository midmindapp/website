import React, { useState } from "react";
import { Icon } from "../brand/Icon.jsx";
import { IconButton } from "../actions/IconButton.jsx";
function cx(...p) { return p.filter(Boolean).join(" "); }

/** Eingabezeile für Fragen, mit Senden- und optionalem Diktat-Button. Mindestens 58 px hoch. */
export function Composer({ placeholder = "Frage stellen …", value, onChange, onSubmit, searchIcon, dictation, onDictate, disclaimer, className }) {
  const [own, setOwn] = useState("");
  const text = value ?? own;
  const set = (v) => { if (value === undefined) setOwn(v); onChange?.(v); };
  const submit = (e) => {
    e.preventDefault();
    const t = text.trim();
    if (!t) return;
    onSubmit?.(t);
    if (value === undefined) setOwn("");
  };
  const showMic = dictation && text.trim() === "";
  return (
    <form className={cx("mm-composer", className)} onSubmit={submit} role="search">
      <div className="mm-composer__box">
        {searchIcon && <span className="mm-composer__lead"><Icon name="search" /></span>}
        <input className="mm-composer__input" value={text} placeholder={placeholder} aria-label={placeholder.replace(/\s*…$/, "")} onChange={(e) => set(e.target.value)} />
        {showMic
          ? <IconButton icon="mic" label="Frage diktieren" variant="primary" onClick={onDictate} />
          : <IconButton icon="send" label="Senden" variant="primary" type="submit" />}
      </div>
      {disclaimer && <div className="mm-composer__disclaimer">{disclaimer}</div>}
    </form>
  );
}
