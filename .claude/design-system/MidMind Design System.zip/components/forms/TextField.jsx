import React, { useId } from "react";
function cx(...p) { return p.filter(Boolean).join(" "); }

/** Einzeiliges Eingabefeld mit Beschriftung, 52 px hoch, 18 px Schrift. */
export function TextField({ label, hint, error, id, className, ...rest }) {
  const auto = useId();
  const fieldId = id ?? auto;
  const hintId = `${fieldId}-hint`;
  const message = error ?? hint;
  return (
    <div className={cx("mm-field", error && "mm-field--error", className)}>
      <label className="mm-field__label" htmlFor={fieldId}>{label}</label>
      <input id={fieldId} className="mm-field__input" aria-invalid={error ? true : undefined} aria-describedby={message ? hintId : undefined} {...rest} />
      {message && <span id={hintId} className="mm-field__hint">{message}</span>}
    </div>
  );
}
