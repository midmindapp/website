import * as React from 'react';

export type TextSize = "normal" | "large" | "xlarge";

/**
 * TextSizeSwitch — MidMind UI (ported from @midmind/ui@0.1.0).
 */
export interface TextSizeSwitchProps {
  /** Gewählte Größe. */
  value: TextSize;
  /** Neue Größe; an <MidMindRoot textSize> weitergeben. */
  onChange?: (size: TextSize) => void;
  className?: string;
}

export declare const TextSizeSwitch: React.ComponentType<TextSizeSwitchProps>;
