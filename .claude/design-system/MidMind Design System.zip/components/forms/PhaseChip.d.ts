import * as React from 'react';

/**
 * PhaseChip — MidMind UI (ported from @midmind/ui@0.1.0).
 */
export interface PhaseChipProps {
  /** Lebensphase; bestimmt Farbpunkt und Beschriftung. */
  phase: "schwangerschaft" | "geburt" | "wochenbett";
  /** Ausgewählt (aria-pressed). */
  selected?: boolean;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}

export declare const PhaseChip: React.ComponentType<PhaseChipProps>;
