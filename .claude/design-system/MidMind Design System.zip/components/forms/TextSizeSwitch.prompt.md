Schalter A A A für die Textgröße; Wert an `MidMindRoot textSize` weitergeben.

```tsx
const [size, setSize] = useState<TextSize>('normal');
<TextSizeSwitch value={size} onChange={setSize} />
```

## Props

```ts
interface TextSizeSwitchProps {
  /** Gewählte Größe. */
  value: "normal" | "large" | "xlarge";
  /** Neue Größe; an <MidMindRoot textSize> weitergeben. */
  onChange?: (size: TextSize) => void;
  className?: string;
}
```

Load via `window.MidMindDesignSystem_0ec547.TextSizeSwitch` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
