import * as React from 'react';

/**
 * TextField — MidMind UI (ported from @midmind/ui@0.1.0).
 * @replaces input
 */
export interface TextFieldProps {
  /** Sichtbare Beschriftung über dem Feld (Pflicht – nie nur Platzhalter). */
  label: string;
  /** Hilfetext unter dem Feld. */
  hint?: string;
  /** Fehlermeldung; färbt das Feld rot und ersetzt den Hinweis. Sagt, was falsch ist und wie es richtig geht. */
  error?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const TextField: React.ComponentType<TextFieldProps>;
