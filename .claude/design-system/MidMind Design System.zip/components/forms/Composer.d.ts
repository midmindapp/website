import * as React from 'react';

/**
 * Composer — MidMind UI (ported from @midmind/ui@0.1.0).
 * @startingPoint section="Eingabe" subtitle="Fragen-Eingabe mit Senden und Diktat" viewport="700x420"
 */
export interface ComposerProps {
  /** Platzhalter, z. B. „Frage stellen …“ oder „Nachfragen …“. */
  placeholder?: string;
  /** Kontrollierter Wert. Ohne value verwaltet der Composer den Text selbst. */
  value?: string;
  /** Änderung des Texts. */
  onChange?: (value: string) => void;
  /** Absenden per Enter oder Senden-Button; bekommt den getrimmten Text. */
  onSubmit?: (value: string) => void;
  /** Lupe links anzeigen (Startseite). */
  searchIcon?: boolean;
  /** Diktat-Button statt Senden, solange das Feld leer ist. */
  dictation?: boolean;
  /** Wird beim Tippen auf den Diktat-Button aufgerufen. */
  onDictate?: () => void;
  /** Kleiner Hinweis darunter, z. B. „MidMind ist eine KI und macht Fehler.“ */
  disclaimer?: React.ReactNode;
  className?: string;
}

export declare const Composer: React.ComponentType<ComposerProps>;
