Eingabefeld mit sichtbarer Beschriftung (nie nur Platzhalter), 52 px hoch.

```tsx
<TextField label="E-Mail-Adresse" type="email" hint="Wir schicken dir den Zugang zur Testphase." />
<TextField label="Gewicht" inputMode="numeric" error="Bitte das Gewicht in Gramm eingeben, z. B. 3600." />
```

## Props

```ts
interface TextFieldProps {
  /** Sichtbare Beschriftung über dem Feld (Pflicht – nie nur Platzhalter). */
  label: string;
  /** Hilfetext unter dem Feld. */
  hint?: string;
  /** Fehlermeldung; färbt das Feld rot und ersetzt den Hinweis. Sagt, was falsch ist und wie es richtig geht. */
  error?: string;
  className?: string;
  id?: string;
  style?: react.CSSProperties;
  children?: React.ReactNode;
}
```

Load via `window.MidMindDesignSystem_0ec547.TextField` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
