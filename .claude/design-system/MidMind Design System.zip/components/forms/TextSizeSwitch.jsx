import React from "react";
function cx(...p) { return p.filter(Boolean).join(" "); }

const OPTIONS = [
  { size: "normal", px: 15, label: "Normale Schrift" },
  { size: "large", px: 18, label: "Große Schrift" },
  { size: "xlarge", px: 22, label: "Sehr große Schrift" },
];

/** Dreistufiger Schalter für die Textgröße der Antworten (A A A). */
export function TextSizeSwitch({ value, onChange, className }) {
  return (
    <div role="group" aria-label="Textgröße" className={cx("mm-textsize", className)}>
      {OPTIONS.map((o) => (
        <button key={o.size} type="button" className="mm-textsize__opt" style={{ fontSize: o.px }} aria-pressed={value === o.size} aria-label={o.label} onClick={() => onChange?.(o.size)}>A</button>
      ))}
    </div>
  );
}
