import * as React from 'react';

export type Phase = "schwangerschaft" | "geburt" | "wochenbett";

/**
 * PhaseChipGroup — MidMind UI (ported from @midmind/ui@0.1.0).
 */
export interface PhaseChipGroupProps {
  /** Aktuell gewählte Phase, oder null für keine. */
  value: Phase | null;
  /** Wird mit der angetippten Phase aufgerufen (oder null, wenn die gewählte erneut angetippt wird). */
  onChange?: (phase: Phase | null) => void;
  /** Zugänglicher Name der Gruppe. Standard „Lebensphase“. */
  label?: string;
  className?: string;
}

export declare const PhaseChipGroup: React.ComponentType<PhaseChipGroupProps>;
