Die drei PhaseChips (Schwangerschaft, Geburt, Wochenbett) als Einzelauswahl. Erneutes Tippen auf die gewählte Phase hebt die Auswahl auf.

```tsx
const [phase, setPhase] = useState<Phase | null>('wochenbett');
<PhaseChipGroup value={phase} onChange={setPhase} />
```

## Props

```ts
interface PhaseChipGroupProps {
  /** Aktuell gewählte Phase, oder null für keine. */
  value: "schwangerschaft" | "geburt" | "wochenbett";
  /** Wird mit der angetippten Phase aufgerufen (oder null, wenn die gewählte erneut angetippt wird). */
  onChange?: (phase: Phase | null) => void;
  /** Zugänglicher Name der Gruppe. Standard „Lebensphase“. */
  label?: string;
  className?: string;
}
```

Load via `window.MidMindDesignSystem_0ec547.PhaseChipGroup` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
