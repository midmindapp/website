Eingabezeile für Fragen. Senden per Enter oder Button; mit `dictation` erscheint bei leerem Feld ein Mikrofon.

```tsx
<Composer placeholder="Frage stellen …" searchIcon dictation onSubmit={ask} />
<Composer placeholder="Nachfragen …" disclaimer="MidMind ist eine KI und macht Fehler." onSubmit={ask} />
```

## Props

```ts
interface ComposerProps {
  /** Platzhalter, z. B. „Frage stellen …“ oder „Nachfragen …“. */
  placeholder?: string;
  /** Kontrollierter Wert. Ohne value verwaltet der Composer den Text selbst. */
  value?: string;
  /** Änderung des Texts. */
  onChange?: (value: string) => void;
  /** Absenden per Enter oder Senden-Button; bekommt den getrimmten Text. */
  onSubmit?: (value: string) => void;
  /** Lupe links anzeigen (Startseite). */
  searchIcon?: boolean;
  /** Diktat-Button statt Senden, solange das Feld leer ist. */
  dictation?: boolean;
  /** Wird beim Tippen auf den Diktat-Button aufgerufen. */
  onDictate?: () => void;
  /** Kleiner Hinweis darunter, z. B. „MidMind ist eine KI und macht Fehler.“ */
  disclaimer?: React.ReactNode;
  className?: string;
}
```

Load via `window.MidMindDesignSystem_0ec547.Composer` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
