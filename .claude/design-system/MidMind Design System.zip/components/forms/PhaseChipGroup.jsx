import React from "react";
import { PHASES } from "../feedback/Badge.jsx";
import { PhaseChip } from "./PhaseChip.jsx";
function cx(...p) { return p.filter(Boolean).join(" "); }

/** Die drei PhaseChips (Schwangerschaft, Geburt, Wochenbett) als Einzelauswahl. */
export function PhaseChipGroup({ value, onChange, label = "Lebensphase", className }) {
  return (
    <div role="group" aria-label={label} className={cx("mm-phase-chips", className)}>
      {Object.keys(PHASES).map((p) => (
        <PhaseChip key={p} phase={p} selected={value === p} onClick={() => onChange?.(value === p ? null : p)} />
      ))}
    </div>
  );
}
