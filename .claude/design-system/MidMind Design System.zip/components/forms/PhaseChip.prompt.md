Umschaltbarer Filter für eine Lebensphase. Meist als `PhaseChipGroup` (Einzelauswahl der drei Phasen).

```tsx
const [phase, setPhase] = useState<Phase | null>('wochenbett');
<PhaseChipGroup value={phase} onChange={setPhase} />
```

Einzeln: `<PhaseChip phase="geburt" selected />`.

## Props

```ts
interface PhaseChipProps {
  /** Lebensphase; bestimmt Farbpunkt und Beschriftung. */
  phase: "schwangerschaft" | "geburt" | "wochenbett";
  /** Ausgewählt (aria-pressed). */
  selected?: boolean;
  className?: string;
  id?: string;
  style?: react.CSSProperties;
}
```

Load via `window.MidMindDesignSystem_0ec547.PhaseChip` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
