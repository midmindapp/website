import React from "react";
import { PHASES } from "../feedback/Badge.jsx";
function cx(...p) { return p.filter(Boolean).join(" "); }

/** Umschaltbarer Filter-Chip für eine Lebensphase. */
export function PhaseChip({ phase, selected = false, className, type = "button", ...rest }) {
  const p = PHASES[phase];
  return (
    <button type={type} aria-pressed={selected} className={cx("mm-phase-chip", className)} {...rest}>
      <span className="mm-phase-chip__dot" style={{ background: p.color }} aria-hidden="true" />
      {p.label}
    </button>
  );
}
