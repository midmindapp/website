import React from "react";
function cx(...p) { return p.filter(Boolean).join(" "); }

/** Kompakte zweispaltige Werte-Tabelle für Mengen und Grenzwerte in einer Antwort. */
export function FactsTable({ rows, caption, className }) {
  return (
    <table className={cx("mm-facts", className)}>
      {caption && <caption>{caption}</caption>}
      <tbody>
        {rows.map((r, i) => (
          <tr key={i}><th scope="row">{r.label}</th><td>{r.value}</td></tr>
        ))}
      </tbody>
    </table>
  );
}
