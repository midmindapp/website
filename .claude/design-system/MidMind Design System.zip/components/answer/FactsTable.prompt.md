Zweispaltige Werte-Tabelle, Werte fett und tabellarisch.

```tsx
<FactsTable caption="Beispiel: 3.600 g" rows={[
  { label: 'pro Tag', value: '≈ 600 ml' },
  { label: 'pro Mahlzeit', value: '60–100 ml' },
]} />
```

## Props

```ts
interface FactsTableProps {
  /** Zeilen der Tabelle. */
  rows: Fact[];
  /** Kleine Überschrift, z. B. „Beispiel: 3.600 g“. */
  caption?: React.ReactNode;
  className?: string;
}
```

Load via `window.MidMindDesignSystem_0ec547.FactsTable` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
