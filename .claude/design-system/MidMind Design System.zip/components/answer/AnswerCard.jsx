import React from "react";
import { FactsTable } from "./FactsTable.jsx";
import { SourceChip } from "./SourceChip.jsx";
function cx(...p) { return p.filter(Boolean).join(" "); }

/** Eine MidMind-Antwort in fester Reihenfolge: Notfall → Kurzantwort → Werte → Erklärung → Hinweis → Quellen → Aktionen. */
export function AnswerCard({ summary, alert, facts, factsCaption, factsTitle = "Gut zu wissen", explanationTitle = "Erklärung", children, sources, actions, note, className }) {
  return (
    <article className={cx("mm-answer", className)}>
      {alert}
      <div className="mm-answer__summary">
        <p className="mm-answer__summary-text">{summary}</p>
      </div>
      {facts && facts.length > 0 && (
        <>
          {factsTitle && <h4 className="mm-answer__heading">{factsTitle}</h4>}
          <FactsTable rows={facts} caption={factsCaption} />
        </>
      )}
      {children && (
        <>
          <h4 className="mm-answer__heading">{explanationTitle}</h4>
          <div className="mm-answer__body">{children}</div>
        </>
      )}
      {note}
      {sources && sources.length > 0 && (
        <div className="mm-sources">
          {sources.map((s, i) => <SourceChip key={i} index={i + 1} label={s.label} book={s.book} chapter={s.chapter} href={s.href} />)}
        </div>
      )}
      {actions && <div className="mm-answer__actions">{actions}</div>}
    </article>
  );
}
