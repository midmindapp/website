import React from "react";
function cx(...p) { return p.filter(Boolean).join(" "); }

/** Hochgestellte Quellennummer im Antworttext. */
export function SourceRef({ index, className, ...rest }) {
  return <sup className={cx("mm-ref", className)} aria-label={`Quelle ${index}`} {...rest}>{index}</sup>;
}
