import * as React from 'react';

/**
 * SourceChip — MidMind UI (ported from @midmind/ui@0.1.0).
 */
export interface SourceChipProps {
  /** Laufende Nummer der Quelle, passend zu SourceRef im Text. */
  index: number;
  /** Titel des Buchs, z. B. „Hebammenkunde“. Bevorzugt vor label. */
  book?: string;
  /** Kapitel mit Nummer, falls vorhanden, z. B. „53.1.7 Lochien (Wochenfluss)“. Wird als „Buch › Kapitel“ gezeigt. */
  chapter?: string;
  /** Kurzname für Quellen ohne Buch/Kapitel, z. B. „AWMF 024-005“. */
  label?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const SourceChip: React.ComponentType<SourceChipProps>;
