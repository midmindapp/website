import * as React from 'react';

export interface Fact { label: React.ReactNode; value: React.ReactNode; }

/**
 * FactsTable — MidMind UI (ported from @midmind/ui@0.1.0).
 */
export interface FactsTableProps {
  /** Zeilen der Tabelle. */
  rows: Fact[];
  /** Kleine Überschrift, z. B. „Beispiel: 3.600 g“. */
  caption?: React.ReactNode;
  className?: string;
}

export declare const FactsTable: React.ComponentType<FactsTableProps>;
