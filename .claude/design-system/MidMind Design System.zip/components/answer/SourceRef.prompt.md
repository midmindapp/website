Hochgestellte Quellennummer im Antworttext. Die Nummer entspricht dem `SourceChip` bzw. der Position in `AnswerCard sources`.

```tsx
<p>Ab dem 8. Lebenstag gilt etwa ein Sechstel des Körpergewichts.<SourceRef index={1} /></p>
```

## Props

```ts
interface SourceRefProps {
  /** Nummer der Quelle. */
  index: number;
  className?: string;
  id?: string;
  style?: react.CSSProperties;
  children?: React.ReactNode;
}
```

Load via `window.MidMindDesignSystem_0ec547.SourceRef` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
