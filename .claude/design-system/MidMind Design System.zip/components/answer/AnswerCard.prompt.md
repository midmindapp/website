Das Herzstück: eine Antwort in fester Reihenfolge – Notfall → Kurzantwort → Werte → Erklärung → Hinweis → Quellen → Aktionen. Wer nur Sekunden hat, liest nur die grüne Kurzantwort.

```tsx
<AnswerCard
  summary={<>Etwa <Value>1/6 des Körpergewichts</Value> pro Tag, verteilt auf <Value>6–10 Mahlzeiten</Value>.</>}
  facts={[{ label: 'pro Tag', value: '≈ 600 ml' }, { label: 'pro Mahlzeit', value: '60–100 ml' }]}
  factsCaption="Beispiel: 3.600 g"
  sources={[{ book: 'Hebammenkunde', chapter: '45.2.3 Trinkmengen' }, { book: 'Stillen', chapter: 'Die ersten Lebenstage' }]}
  actions={<Button variant="ghost" size="sm" icon={<Icon name="copy" size={18} />}>Kopieren</Button>}
>
  <p>Ab dem 8. Lebenstag gilt etwa ein Sechstel des Körpergewichts.<SourceRef index={1} /></p>
</AnswerCard>
```

Notfall: `alert={<Callout tone="critical" title="…">…</Callout>}`.

## Props

```ts
interface AnswerCardProps {
  /** Kurzantwort, ein bis zwei Sätze. Werte mit <Value> hervorheben. Steht immer oben. */
  summary: React.ReactNode;
  /** Notfall- oder Hinweisbox (meist <Callout tone="critical">), erscheint noch vor der Kurzantwort. */
  alert?: React.ReactNode;
  /** Optionale Werte-Tabelle unter der Kurzantwort. */
  facts?: Fact[];
  /** Überschrift der Werte-Tabelle. */
  factsCaption?: React.ReactNode;
  /** Überschrift über der Werte-Tabelle. Standard „Gut zu wissen“; leer lassen ("") blendet sie aus. */
  factsTitle?: string;
  /** Überschrift der Erklärung. Standard „Erklärung“. */
  explanationTitle?: React.ReactNode;
  /** Erklärung als Fließtext; Quellen im Text mit <SourceRef index={n} /> markieren. */
  children?: React.ReactNode;
  /** Quellen, nummeriert in dieser Reihenfolge. */
  sources?: AnswerSource[];
  /** Aktionen unter der Antwort, z. B. Kopieren. */
  actions?: React.ReactNode;
  /** Eine Info-/Hinweisbox, die nach der Erklärung steht. */
  note?: React.ReactNode;
  className?: string;
}
```

Load via `window.MidMindDesignSystem_0ec547.AnswerCard` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
