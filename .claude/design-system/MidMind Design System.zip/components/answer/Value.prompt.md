Hebt eine Menge, Dosis, Zeit oder einen Grenzwert im Text hervor: fett auf Aprikose.

```tsx
<p>Ab <Value>160/110 mmHg</Value> mit Symptomen: Blutdruck alle <Value>15 min</Value>.</p>
```

Nur für Zahlen mit Einheit, nicht für ganze Sätze. Bei reinem Text hält `Value` Zahl und Einheit sowie Bereiche („60–100 ml“) automatisch zusammen.

## Props

```ts
interface ValueProps {
  className?: string;
  id?: string;
  style?: react.CSSProperties;
  children?: React.ReactNode;
}
```

Load via `window.MidMindDesignSystem_0ec547.Value` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
