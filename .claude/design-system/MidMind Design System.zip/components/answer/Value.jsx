import React from "react";
function cx(...p) { return p.filter(Boolean).join(" "); }

// Zahl und Einheit bzw. Spannen nie umbrechen.
function keepTogether(text) {
  return text.replace(/(\d)\s+(?=\S)/g, "$1\u00A0").replace(/(\d)\s*([–-])\s*(?=\d)/g, "$1\u2060$2\u2060");
}

/** Hebt einen Wert im Fließtext hervor: Menge, Dosis, Zeit, Grenzwert. Fett auf Aprikose, tabellarische Ziffern. */
export function Value({ className, children, ...rest }) {
  return <strong className={cx("mm-value", className)} {...rest}>{typeof children === "string" ? keepTogether(children) : children}</strong>;
}
