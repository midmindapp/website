import * as React from 'react';

export interface Fact { label: React.ReactNode; value: React.ReactNode; }
export interface AnswerSource { label: string; href?: string; }

/**
 * AnswerCard — MidMind UI (ported from @midmind/ui@0.1.0).
 * @startingPoint section="Antwort" subtitle="MidMind-Antwort: Kurzantwort, Werte, Erklärung, Quellen" viewport="700x560"
 */
export interface AnswerCardProps {
  /** Kurzantwort, ein bis zwei Sätze. Werte mit <Value> hervorheben. Steht immer oben. */
  summary: React.ReactNode;
  /** Notfall- oder Hinweisbox (meist <Callout tone="critical">), erscheint noch vor der Kurzantwort. */
  alert?: React.ReactNode;
  /** Optionale Werte-Tabelle unter der Kurzantwort. */
  facts?: Fact[];
  /** Überschrift der Werte-Tabelle. */
  factsCaption?: React.ReactNode;
  /** Überschrift über der Werte-Tabelle. Standard „Gut zu wissen“; leer lassen ("") blendet sie aus. */
  factsTitle?: string;
  /** Überschrift der Erklärung. Standard „Erklärung“. */
  explanationTitle?: React.ReactNode;
  /** Erklärung als Fließtext; Quellen im Text mit <SourceRef index={n} /> markieren. */
  children?: React.ReactNode;
  /** Quellen, nummeriert in dieser Reihenfolge. */
  sources?: AnswerSource[];
  /** Aktionen unter der Antwort, z. B. Kopieren, In Notizen. */
  actions?: React.ReactNode;
  /** Eine Info-/Hinweisbox, die nach der Erklärung steht. */
  note?: React.ReactNode;
  className?: string;
}

export declare const AnswerCard: React.ComponentType<AnswerCardProps>;
