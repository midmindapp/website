import React from "react";
function cx(...p) { return p.filter(Boolean).join(" "); }

/** Sprechblase mit der Frage der Hebamme, rechtsbündig auf Sand. */
export function ChatQuestion({ className, ...rest }) {
  return <div className={cx("mm-question", className)} {...rest} />;
}
