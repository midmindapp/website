import * as React from 'react';

/**
 * Value — MidMind UI (ported from @midmind/ui@0.1.0).
 */
export interface ValueProps {
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Value: React.ComponentType<ValueProps>;
