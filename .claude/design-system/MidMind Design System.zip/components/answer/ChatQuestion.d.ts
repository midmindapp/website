import * as React from 'react';

/**
 * ChatQuestion — MidMind UI (ported from @midmind/ui@0.1.0).
 */
export interface ChatQuestionProps {
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const ChatQuestion: React.ComponentType<ChatQuestionProps>;
