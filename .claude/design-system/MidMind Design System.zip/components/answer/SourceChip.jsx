import React from "react";
function cx(...p) { return p.filter(Boolean).join(" "); }

/** Tippbarer Chip für eine Literaturquelle unter einer Antwort. */
export function SourceChip({ index, label, book, chapter, className, href = "#", ...rest }) {
  const text = book ? (chapter ? `${book}, ${chapter}` : book) : label;
  return (
    <a href={href} aria-label={`Quelle ${index}: ${text}`} className={cx("mm-source", className)} {...rest}>
      <span className="mm-source__n" aria-hidden="true">{index}</span>
      {book ? <span className="mm-source__t"><span>{book}</span>{chapter && <><span className="mm-source__sep" aria-hidden="true">›</span><span>{chapter}</span></>}</span> : label}
    </a>
  );
}
