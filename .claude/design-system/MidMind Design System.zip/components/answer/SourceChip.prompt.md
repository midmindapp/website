Tippbarer Chip für eine Literaturquelle; `SourceRef` ist die passende hochgestellte Nummer im Text.

```tsx
<p>… etwa ein Sechstel des Körpergewichts.<SourceRef index={1} /></p>
<SourceChip index={1} book="Hebammenkunde" chapter="53.1.7 Lochien (Wochenfluss)" href="/quellen/1" />
```

In einer `AnswerCard` über `sources` statt einzeln setzen.

## Props

```ts
interface SourceChipProps {
  /** Laufende Nummer der Quelle, passend zu SourceRef im Text. */
  index: number;
  /** Titel des Buchs, z. B. „Hebammenkunde“. */
  book?: string;
  /** Kapitel, z. B. „53.1.7 Lochien (Wochenfluss)“. Anzeige: „Buch › Kapitel“. */
  chapter?: string;
  /** Kurzname für Quellen ohne Buch/Kapitel. */
  label?: string;
  className?: string;
  id?: string;
  style?: react.CSSProperties;
  children?: React.ReactNode;
}
```

Load via `window.MidMindDesignSystem_0ec547.SourceChip` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
