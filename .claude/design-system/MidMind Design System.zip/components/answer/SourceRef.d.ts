import * as React from 'react';

/**
 * SourceRef — MidMind UI (ported from @midmind/ui@0.1.0).
 */
export interface SourceRefProps {
  /** Nummer der Quelle. */
  index: number;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const SourceRef: React.ComponentType<SourceRefProps>;
