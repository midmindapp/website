Die Frage der Hebamme als Sprechblase, rechtsbündig.

```tsx
<ChatQuestion>Wieviel Milch sollte ein 9 Tage alter Säugling pro Mahlzeit trinken?</ChatQuestion>
```

## Props

```ts
interface ChatQuestionProps {
  className?: string;
  id?: string;
  style?: react.CSSProperties;
  children?: React.ReactNode;
}
```

Load via `window.MidMindDesignSystem_0ec547.ChatQuestion` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
