import * as React from 'react';

/**
 * Callout — MidMind UI (ported from @midmind/ui@0.1.0).
 */
export interface CalloutProps {
  /** "critical" (Notfall, Ziegelrot, role=alert), "warning" (Hinweis, Ocker) oder "info" (neutral). */
  tone?: "critical" | "warning" | "info";
  /** Fette Überschrift, z. B. „Sofort ärztlich abklären“. Pflicht: Farbe allein trägt nie die Bedeutung. */
  title: React.ReactNode;
  /** Erklärender Text. */
  children?: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}

export declare const Callout: React.ComponentType<CalloutProps>;
