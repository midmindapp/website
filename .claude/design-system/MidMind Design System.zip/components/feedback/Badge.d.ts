import * as React from 'react';

export type Phase = "schwangerschaft" | "geburt" | "wochenbett";

/**
 * Badge — MidMind UI (ported from @midmind/ui@0.1.0).
 */
export interface BadgeProps {
  /** Farbfläche. Ignoriert, wenn phase gesetzt ist. */
  tone?: "sage" | "apricot" | "malve" | "ok" | "neutral";
  /** Lebensphase: setzt Farbe und Text automatisch (Schwangerschaft = Aprikose, Geburt = Malve, Wochenbett = Salbei). */
  phase?: "schwangerschaft" | "geburt" | "wochenbett";
  /** "md" (Standard) oder "sm" für App-Bar und Listen. */
  size?: "md" | "sm";
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Badge: React.ComponentType<BadgeProps>;

export declare const PHASES: Record<Phase, { label: string; color: string; tone: "apricot" | "malve" | "sage" }>;
