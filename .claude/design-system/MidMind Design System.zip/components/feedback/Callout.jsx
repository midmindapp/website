import React from "react";
import { Icon } from "../brand/Icon.jsx";
function cx(...p) { return p.filter(Boolean).join(" "); }

/** Hinweis- oder Notfallbox mit Symbol, Titel und Text. Notfälle stehen in einer Antwort ganz oben. */
export function Callout({ tone = "info", title, children, className, ...rest }) {
  return (
    <div role={tone === "critical" ? "alert" : "note"} className={cx("mm-callout", `mm-callout--${tone}`, className)} {...rest}>
      <Icon name={tone === "critical" ? "alert" : "info"} size={24} className="mm-callout__icon" />
      <div>
        <strong className="mm-callout__title">{title}</strong>
        {children && <div className="mm-callout__body">{children}</div>}
      </div>
    </div>
  );
}
