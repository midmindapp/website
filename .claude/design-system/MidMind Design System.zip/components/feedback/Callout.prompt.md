Hinweis- oder Notfallbox. Immer mit Titel – Farbe allein trägt nie die Bedeutung.

```tsx
<Callout tone="critical" title="Notfall: sofort ärztlich abklären">
  Verdacht auf schwere Präeklampsie. Klinik bzw. Kreißsaal informieren.
</Callout>
<Callout tone="warning" title="Hinweis">Gilt für reife, gesunde Neugeborene.</Callout>
```

- `critical` steht in einer Antwort **vor** der Kurzantwort (`AnswerCard alert`).
- `critical` nur für echte Notfälle, sonst stumpft es ab.

## Props

```ts
interface CalloutProps {
  /** "critical" (Notfall, Ziegelrot, role=alert), "warning" (Hinweis, Ocker) oder "info" (neutral). */
  tone?: "critical" | "warning" | "info";
  /** Fette Überschrift, z. B. „Sofort ärztlich abklären“. Pflicht: Farbe allein trägt nie die Bedeutung. */
  title: React.ReactNode;
  /** Erklärender Text. */
  children?: React.ReactNode;
  className?: string;
  id?: string;
  style?: react.CSSProperties;
}
```

Load via `window.MidMindDesignSystem_0ec547.Callout` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
