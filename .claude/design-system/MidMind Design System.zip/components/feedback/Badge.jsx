import React from "react";
function cx(...p) { return p.filter(Boolean).join(" "); }

/** Lebensphasen – überall gleich farbcodiert. */
export const PHASES = {
  schwangerschaft: { label: "Schwangerschaft", color: "var(--mm-apricot)", tone: "apricot" },
  geburt: { label: "Geburt", color: "var(--mm-malve)", tone: "malve" },
  wochenbett: { label: "Wochenbett", color: "var(--mm-sage)", tone: "sage" },
};

/** Kleines Etikett für Lebensphase, Status oder Kategorie. Nicht klickbar – dafür PhaseChip. */
export function Badge({ tone = "neutral", phase, size = "md", className, children, ...rest }) {
  const t = phase ? PHASES[phase].tone : tone;
  return (
    <span className={cx("mm-badge", `mm-badge--${t}`, size === "sm" && "mm-badge--sm", className)} {...rest}>
      {children ?? (phase ? PHASES[phase].label : null)}
    </span>
  );
}
