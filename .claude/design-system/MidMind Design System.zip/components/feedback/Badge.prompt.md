Nicht klickbares Etikett. Mit `phase` stimmen Farbe und Text automatisch: Schwangerschaft = Aprikose, Geburt = Malve, Wochenbett = Salbei, Abrechnung = Taubenblau.

```tsx
<Badge phase="wochenbett" />
<Badge phase="geburt" size="sm" />
<Badge tone="ok">Leitlinie aktuell</Badge>
```

## Props

```ts
interface BadgeProps {
  /** Farbfläche. Ignoriert, wenn phase gesetzt ist. */
  tone?: "sage" | "apricot" | "malve" | "taube" | "ok" | "neutral";
  /** Lebensphase: setzt Farbe und Text automatisch (Schwangerschaft = Aprikose, Geburt = Malve, Wochenbett = Salbei, Abrechnung = Taubenblau). */
  phase?: "schwangerschaft" | "geburt" | "wochenbett" | "abrechnung";
  /** "md" (Standard) oder "sm" für App-Bar und Listen. */
  size?: "md" | "sm";
  className?: string;
  id?: string;
  style?: react.CSSProperties;
  children?: React.ReactNode;
}
```

Load via `window.MidMindDesignSystem_0ec547.Badge` (root `_ds_bundle.js`); always inside `<MidMindRoot>`.
