# Grundsätze: Ruhig unter Druck

MidMind wird im Stress gelesen: nachts beim Hausbesuch, im Kreißsaal, mit einer Hand, müde. Jede Oberfläche folgt diesen Regeln.

1. **Antwort zuerst.** Kurzantwort oben (grüne Box), dann Werte, Erklärung, Quellen. Notfälle stehen noch davor, rot, mit Symbol und Titel.
2. **Werte hervorheben.** Mengen, Dosen, Zeiten und Grenzwerte immer mit `<Value>`.
3. **Pastell nur als Fläche.** Salbei, Aprikose, Malve tragen nie Text. Text ist `var(--mm-ink)` (14:1) oder `var(--mm-muted)` (7:1).
4. **Groß genug.** Antworttext mindestens 18 px, alles Antippbare mindestens 44–48 px hoch.
5. **Nachtmodus mitdenken.** Farben nur über Tokens, nie feste Hex-Werte, sonst bricht der Nachtmodus.
6. **Lebensphasen farbig ordnen.** Schwangerschaft = Aprikose, Geburt = Malve, Wochenbett = Salbei – überall gleich.
7. **Deutsch, Du-Form, klar.** Buttons sagen, was passiert. Fehlermeldungen sagen, was falsch ist und wie es richtig geht.
8. **Jede Antwort endet mit** „MidMind ist eine KI und macht Fehler.“ im Composer-Hinweis.
