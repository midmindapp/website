/* @ds-bundle: {"format":4,"namespace":"MidMindDesignSystem_0ec547","components":[{"name":"Button","sourcePath":"components/actions/Button.jsx"},{"name":"IconButton","sourcePath":"components/actions/IconButton.jsx"},{"name":"SuggestionButton","sourcePath":"components/actions/SuggestionButton.jsx"},{"name":"AnswerCard","sourcePath":"components/answer/AnswerCard.jsx"},{"name":"ChatQuestion","sourcePath":"components/answer/ChatQuestion.jsx"},{"name":"FactsTable","sourcePath":"components/answer/FactsTable.jsx"},{"name":"SourceChip","sourcePath":"components/answer/SourceChip.jsx"},{"name":"SourceRef","sourcePath":"components/answer/SourceRef.jsx"},{"name":"Value","sourcePath":"components/answer/Value.jsx"},{"name":"DisplayHeading","sourcePath":"components/brand/DisplayHeading.jsx"},{"name":"ICON_NAMES","sourcePath":"components/brand/Icon.jsx"},{"name":"Icon","sourcePath":"components/brand/Icon.jsx"},{"name":"Logo","sourcePath":"components/brand/Logo.jsx"},{"name":"PHASES","sourcePath":"components/feedback/Badge.jsx"},{"name":"Badge","sourcePath":"components/feedback/Badge.jsx"},{"name":"Callout","sourcePath":"components/feedback/Callout.jsx"},{"name":"Composer","sourcePath":"components/forms/Composer.jsx"},{"name":"PhaseChip","sourcePath":"components/forms/PhaseChip.jsx"},{"name":"PhaseChipGroup","sourcePath":"components/forms/PhaseChipGroup.jsx"},{"name":"TextField","sourcePath":"components/forms/TextField.jsx"},{"name":"TextSizeSwitch","sourcePath":"components/forms/TextSizeSwitch.jsx"},{"name":"MidMindRoot","sourcePath":"components/layout/MidMindRoot.jsx"},{"name":"AppBar","sourcePath":"components/navigation/AppBar.jsx"},{"name":"NavItem","sourcePath":"components/navigation/NavItem.jsx"},{"name":"DEFAULT_TABS","sourcePath":"components/navigation/TabBar.jsx"},{"name":"TabBar","sourcePath":"components/navigation/TabBar.jsx"}],"sourceHashes":{"components/actions/Button.jsx":"a0815c3729d0","components/actions/IconButton.jsx":"7fb99f5d71f0","components/actions/SuggestionButton.jsx":"d9cdb6db965c","components/answer/AnswerCard.jsx":"88e678ddcde8","components/answer/ChatQuestion.jsx":"d69ed6e830c9","components/answer/FactsTable.jsx":"3195d2cad155","components/answer/SourceChip.jsx":"350135ba328a","components/answer/SourceRef.jsx":"c72409ed25fd","components/answer/Value.jsx":"b64ac53ca247","components/brand/DisplayHeading.jsx":"04763efdfc52","components/brand/Icon.jsx":"5e3ea0b1da55","components/brand/Logo.jsx":"d0066417acae","components/feedback/Badge.jsx":"75c6f322fa4d","components/feedback/Callout.jsx":"72f41847ca6b","components/forms/Composer.jsx":"8763976c497f","components/forms/PhaseChip.jsx":"2fd0b3bab9d9","components/forms/PhaseChipGroup.jsx":"725ad30b30d2","components/forms/TextField.jsx":"d227b9061aa1","components/forms/TextSizeSwitch.jsx":"7e68b8fe064d","components/layout/MidMindRoot.jsx":"e96bb80d9edf","components/navigation/AppBar.jsx":"d0a09e306211","components/navigation/NavItem.jsx":"dd45bc4b8e58","components/navigation/TabBar.jsx":"91eef2ddd00e","ui_kits/app/Account.jsx":"f28a887862e4","ui_kits/app/Admin.jsx":"08e65a17a0a2","ui_kits/app/DesktopApp.jsx":"8d99cdd0902c","ui_kits/app/Literature.jsx":"51c3fb8fc5ba","ui_kits/app/MobileApp.jsx":"b7f450c8fde1","ui_kits/app/Screens.jsx":"ca665323c011","ui_kits/app/Welcome.jsx":"c92e60494e47","ui_kits/app/data.jsx":"bb46c870e116"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.MidMindDesignSystem_0ec547 = window.MidMindDesignSystem_0ec547 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/actions/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function cx(...p) {
  return p.filter(Boolean).join(" ");
}

/** Pillenförmiger Button, mindestens 44 px hoch. Höchstens ein primary pro Ansicht. */
function Button({
  variant = "primary",
  size = "md",
  icon,
  block,
  className,
  type = "button",
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    className: cx("mm-button", `mm-button--${variant}`, size === "sm" && "mm-button--sm", block && "mm-button--block", className)
  }, rest), icon, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Button.jsx", error: String((e && e.message) || e) }); }

// components/answer/ChatQuestion.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function cx(...p) {
  return p.filter(Boolean).join(" ");
}

/** Sprechblase mit der Frage der Hebamme, rechtsbündig auf Sand. */
function ChatQuestion({
  className,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cx("mm-question", className)
  }, rest));
}
Object.assign(__ds_scope, { ChatQuestion });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/answer/ChatQuestion.jsx", error: String((e && e.message) || e) }); }

// components/answer/FactsTable.jsx
try { (() => {
function cx(...p) {
  return p.filter(Boolean).join(" ");
}

/** Kompakte zweispaltige Werte-Tabelle für Mengen und Grenzwerte in einer Antwort. */
function FactsTable({
  rows,
  caption,
  className
}) {
  return /*#__PURE__*/React.createElement("table", {
    className: cx("mm-facts", className)
  }, caption && /*#__PURE__*/React.createElement("caption", null, caption), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: i
  }, /*#__PURE__*/React.createElement("th", {
    scope: "row"
  }, r.label), /*#__PURE__*/React.createElement("td", null, r.value)))));
}
Object.assign(__ds_scope, { FactsTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/answer/FactsTable.jsx", error: String((e && e.message) || e) }); }

// components/answer/SourceChip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function cx(...p) {
  return p.filter(Boolean).join(" ");
}

/** Tippbarer Chip für eine Literaturquelle unter einer Antwort. */
function SourceChip({
  index,
  label,
  book,
  chapter,
  className,
  href = "#",
  ...rest
}) {
  const text = book ? chapter ? `${book}, ${chapter}` : book : label;
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    "aria-label": `Quelle ${index}: ${text}`,
    className: cx("mm-source", className)
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "mm-source__n",
    "aria-hidden": "true"
  }, index), book ? /*#__PURE__*/React.createElement("span", {
    className: "mm-source__t"
  }, /*#__PURE__*/React.createElement("span", null, book), chapter && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "mm-source__sep",
    "aria-hidden": "true"
  }, "\u203A"), /*#__PURE__*/React.createElement("span", null, chapter))) : label);
}
Object.assign(__ds_scope, { SourceChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/answer/SourceChip.jsx", error: String((e && e.message) || e) }); }

// components/answer/AnswerCard.jsx
try { (() => {
function cx(...p) {
  return p.filter(Boolean).join(" ");
}

/** Eine MidMind-Antwort in fester Reihenfolge: Notfall → Kurzantwort → Werte → Erklärung → Hinweis → Quellen → Aktionen. */
function AnswerCard({
  summary,
  alert,
  facts,
  factsCaption,
  factsTitle = "Gut zu wissen",
  explanationTitle = "Erklärung",
  children,
  sources,
  actions,
  note,
  className
}) {
  return /*#__PURE__*/React.createElement("article", {
    className: cx("mm-answer", className)
  }, alert, /*#__PURE__*/React.createElement("div", {
    className: "mm-answer__summary"
  }, /*#__PURE__*/React.createElement("p", {
    className: "mm-answer__summary-text"
  }, summary)), facts && facts.length > 0 && /*#__PURE__*/React.createElement(React.Fragment, null, factsTitle && /*#__PURE__*/React.createElement("h4", {
    className: "mm-answer__heading"
  }, factsTitle), /*#__PURE__*/React.createElement(__ds_scope.FactsTable, {
    rows: facts,
    caption: factsCaption
  })), children && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("h4", {
    className: "mm-answer__heading"
  }, explanationTitle), /*#__PURE__*/React.createElement("div", {
    className: "mm-answer__body"
  }, children)), note, sources && sources.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "mm-sources"
  }, sources.map((s, i) => /*#__PURE__*/React.createElement(__ds_scope.SourceChip, {
    key: i,
    index: i + 1,
    label: s.label,
    book: s.book,
    chapter: s.chapter,
    href: s.href
  }))), actions && /*#__PURE__*/React.createElement("div", {
    className: "mm-answer__actions"
  }, actions));
}
Object.assign(__ds_scope, { AnswerCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/answer/AnswerCard.jsx", error: String((e && e.message) || e) }); }

// components/answer/SourceRef.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function cx(...p) {
  return p.filter(Boolean).join(" ");
}

/** Hochgestellte Quellennummer im Antworttext. */
function SourceRef({
  index,
  className,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("sup", _extends({
    className: cx("mm-ref", className),
    "aria-label": `Quelle ${index}`
  }, rest), index);
}
Object.assign(__ds_scope, { SourceRef });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/answer/SourceRef.jsx", error: String((e && e.message) || e) }); }

// components/answer/Value.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function cx(...p) {
  return p.filter(Boolean).join(" ");
}

// Zahl und Einheit bzw. Spannen nie umbrechen.
function keepTogether(text) {
  return text.replace(/(\d)\s+(?=\S)/g, "$1\u00A0").replace(/(\d)\s*([–-])\s*(?=\d)/g, "$1\u2060$2\u2060");
}

/** Hebt einen Wert im Fließtext hervor: Menge, Dosis, Zeit, Grenzwert. Fett auf Aprikose, tabellarische Ziffern. */
function Value({
  className,
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("strong", _extends({
    className: cx("mm-value", className)
  }, rest), typeof children === "string" ? keepTogether(children) : children);
}
Object.assign(__ds_scope, { Value });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/answer/Value.jsx", error: String((e && e.message) || e) }); }

// components/brand/DisplayHeading.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function cx(...p) {
  return p.filter(Boolean).join(" ");
}

/** Warme Serifen-Überschrift (Young Serif). Nur für Website und Begrüßungen, nicht für Antworten. */
function DisplayHeading({
  as: Tag = "h1",
  size = "xl",
  className,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: cx("mm-display", `mm-display--${size}`, className)
  }, rest));
}
Object.assign(__ds_scope, { DisplayHeading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/DisplayHeading.jsx", error: String((e && e.message) || e) }); }

// components/brand/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function cx(...p) {
  return p.filter(Boolean).join(" ");
}
const PATHS = {
  alert: /*#__PURE__*/React.createElement("path", {
    d: "M12 3 2 20h20L12 3zM12 10v4M12 17.5v.01"
  }),
  info: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "9.5"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 11v6M12 7.5v.01"
  })),
  send: /*#__PURE__*/React.createElement("path", {
    d: "M12 19V5M5 12l7-7 7 7"
  }),
  copy: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
    x: "8",
    y: "8",
    width: "12",
    height: "12",
    rx: "3"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"
  })),
  book: /*#__PURE__*/React.createElement("path", {
    d: "M4 5.5A2.5 2.5 0 0 1 6.5 3H20v15H6.5A2.5 2.5 0 0 0 4 20.5v-15zM4 20.5A2.5 2.5 0 0 0 6.5 23H20v-5"
  }),
  moon: /*#__PURE__*/React.createElement("path", {
    d: "M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"
  }),
  sun: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "4"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"
  })),
  folder: /*#__PURE__*/React.createElement("path", {
    d: "M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z"
  }),
  text: /*#__PURE__*/React.createElement("path", {
    d: "M3 19 8.5 5 14 19M5 14h7M15 19l3.5-8 3.5 8M16 16.5h5"
  }),
  search: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
    cx: "11",
    cy: "11",
    r: "7"
  }), /*#__PURE__*/React.createElement("path", {
    d: "m20 20-4-4"
  })),
  mic: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
    x: "9",
    y: "3",
    width: "6",
    height: "11",
    rx: "3"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M5 11a7 7 0 0 0 14 0M12 18v3"
  })),
  chevronRight: /*#__PURE__*/React.createElement("path", {
    d: "m9 5 7 7-7 7"
  }),
  chevronLeft: /*#__PURE__*/React.createElement("path", {
    d: "m15 5-7 7 7 7"
  }),
  chat: /*#__PURE__*/React.createElement("path", {
    d: "M4 5h16v11H9l-5 4V5z"
  }),
  note: /*#__PURE__*/React.createElement("path", {
    d: "M5 3h10l4 4v14H5V3zM9 11h6M9 15h6"
  }),
  clock: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "9"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 7v5l3 2"
  })),
  plus: /*#__PURE__*/React.createElement("path", {
    d: "M12 5v14M5 12h14"
  }),
  check: /*#__PURE__*/React.createElement("path", {
    d: "m5 12 5 5 9-10"
  }),
  menu: /*#__PURE__*/React.createElement("path", {
    d: "M4 7h16M4 12h16M4 17h16"
  }),
  close: /*#__PURE__*/React.createElement("path", {
    d: "M6 6l12 12M18 6 6 18"
  }),
  user: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "8",
    r: "4"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M4 21a8 8 0 0 1 16 0"
  })),
  lock: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
    x: "5",
    y: "11",
    width: "14",
    height: "10",
    rx: "2"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M8 11V7a4 4 0 0 1 8 0v4"
  })),
  mail: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
    x: "3",
    y: "5",
    width: "18",
    height: "14",
    rx: "2"
  }), /*#__PURE__*/React.createElement("path", {
    d: "m3 7 9 6 9-6"
  })),
  key: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
    cx: "8",
    cy: "15",
    r: "4"
  }), /*#__PURE__*/React.createElement("path", {
    d: "m11 12 9-9M17 6l3 3M14 9l2 2"
  })),
  logout: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 17l5-5-5-5M15 12H3"
  }))
};
const ICON_NAMES = Object.keys(PATHS);

/** Linien-Icon im MidMind-Stil (2,1 px Strich, runde Enden). Übernimmt die Textfarbe. */
function Icon({
  name,
  size = 22,
  label,
  className,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("svg", _extends({
    viewBox: "0 0 24 24",
    width: size,
    height: size,
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2.1,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    className: cx("mm-icon", className),
    role: label ? "img" : undefined,
    "aria-label": label,
    "aria-hidden": label ? undefined : true
  }, rest), PATHS[name]);
}
Object.assign(__ds_scope, { ICON_NAMES, Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Icon.jsx", error: String((e && e.message) || e) }); }

// components/actions/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function cx(...p) {
  return p.filter(Boolean).join(" ");
}

/** Runder Button nur mit Icon, z. B. Zurück, Nachtmodus, Kopieren, Senden. */
function IconButton({
  icon,
  label,
  variant = "plain",
  size = "md",
  className,
  type = "button",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    "aria-label": label,
    title: label,
    className: cx("mm-icon-button", variant !== "plain" && `mm-icon-button--${variant}`, size === "lg" && "mm-icon-button--lg", className)
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: variant === "primary" ? 20 : 22
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/actions/SuggestionButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function cx(...p) {
  return p.filter(Boolean).join(" ");
}

/** Große tippbare Vorschlagsfrage auf der Startseite, mit Pfeil rechts. */
function SuggestionButton({
  className,
  children,
  type = "button",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    className: cx("mm-suggestion", className)
  }, rest), /*#__PURE__*/React.createElement("span", null, children), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevronRight",
    size: 18
  }));
}
Object.assign(__ds_scope, { SuggestionButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/SuggestionButton.jsx", error: String((e && e.message) || e) }); }

// components/brand/Logo.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function cx(...p) {
  return p.filter(Boolean).join(" ");
}

// Vektorisiert aus der Original-Bilddatei (uploads/favicon.png), 552 × 479.
const MARK_PATH = "M251 0L240 1.5L227 5.5L216 10.5L206 16.8L189 16.6L176 17.7L164 20.6L149 26.6L141 31.6L133 37.6L125.1 45L118.6 52L111.6 62L107.5 70L105.5 76L103.8 78L101 79.4L94 81.6L83 86.7L72 93.6L61 102.8L52.6 112L47.7 119L43.8 127L38.8 140L35.5 151L33.7 164L33.7 169L35.5 181L28 188L23.6 193L16.7 203L8.5 219L3.7 232L0.7 244L-0.1 254L0.5 272L1.5 279L4.6 289L10.6 302L14.7 309L20.4 316L17.8 337L18.5 348L20.6 360L23.6 369L25.5 373L32.6 384L38 390.2L47 398.3L60 406.4L78.6 414L83.6 424L86.7 429L94.7 439L105 448.2L117 455.1L126 459.3L135 462.5L140 463.5L150 464.5L156 464.4L170 462.5L180 459.5L189 455.6L191 455.5L199 462.3L208 468.2L214 471.3L225 475.4L233 477.4L240 478.5L262 478.5L269 477.5L285 473.3L295 469.4L308 462.2L317 455.1L325.4 446L329.4 440L334.4 430L339.5 416L341.5 406L341.5 301L340.7 217L340.5 102L339.5 56L338.5 45L336.4 38L330.4 30L326 25.2L319 18.6L315 15.6L305 9.6L296 5.8L285 2.5L270 0.5ZM249 16L260 15.6L274 16.7L284 18.6L295 22.6L306 28.7L313.7 35L319.3 41L325.3 51L325.3 408L320.4 423L317.4 430L313.4 437L308 443.3L300 449.4L293 453.2L281 458.3L271 461.3L257 463.4L244 463.4L236 462.3L228 460.3L220 457.3L213 453.4L206.3 448L201.6 442L200.6 440L199.9 436L200.6 432L202.8 426L213.4 405L213.6 404L213 403.5L201 411.7L195 416.7L189.6 423L186.5 429L185 439.2L171 445.3L165 447.3L160.8 448L157 448.5L144 448.4L137 447.3L127 443.4L116 437.4L109.4 432L101.6 423L95.7 414L90.5 403L89 401.1L79 398.3L64 391.4L53 383.3L48.7 379L43.9 373L40.7 368L37.8 362L35.8 356L34.8 350L34.6 327L36.2 312L35.5 310L27.6 299L21.8 289L18.8 282L16.7 275L15.8 266L15.7 256L15.8 249L16.7 241L21.7 225L25.6 217L35.6 203L53.4 184L50.6 168L50.5 157L51.6 151L54.7 142L60.8 129L66.7 120L73.2 113L80 106.8L90 100.6L100 96.6L117 91.3L119.6 83L122.8 76L130.7 62L134.6 57L141 50.6L146 46.7L154 41.6L160 38.7L168 35.7L182 32.6L196 31.5L211 32.7L223 24.7L231 20.7L240 17.6ZM466 45L459 45.5L450 47.6L441 51.5L434 55.8L428 61L422.6 67L418.7 73L415.3 80L413 82.8L411 84.4L405 87.6L398.9 93L394.7 98L392.7 102L391.5 111L391.8 117L393.5 126L395.9 131L399 134.9L408.4 142L392 158L386.6 164L378.5 175L369.6 192L365.5 203L361.6 216L357.6 234L354.5 257L353.5 270L353 292L353.5 315L355.5 329L357.8 336L359.5 339L362.9 343L373 350.7L375.2 353L375.4 354L369.6 370L366.7 380L363.5 393L360.5 409L358.6 422L356.5 442L355.5 475L356 475.5L497 475.5L509 475.5L509.5 475L507.7 451L507.3 432L509 430.8L515 428.2L521 424.4L530 416.5L533.3 413L539.4 405L546.4 392L549.5 383L551.5 373L551.4 351L550.5 344L547.3 333L543.5 324L537.5 314L530.1 305L526 300.9L516 292.6L502.1 283L502.7 280L507.3 270L508.5 266L508.5 254L507.3 250L505.1 246L501.4 241L494 233.7L470 215.2L460 205.6L453.9 198L449.7 188L448.6 183L448.5 177L449 175.7L456 179.4L460 180.5L477 180.5L481 179.5L485 177.4L487.4 175L493 165.7L495 164.5L500 163.5L502 162.5L507 158.8L508.5 157L509.3 154L507.7 147L507.6 143L512.7 134L525.4 118L528.5 111L529.3 106L529.3 101L528.3 94L524.3 83L516.4 70L509 61.6L499 53.6L489 48.6L477 45.5ZM259 57.9L253 59.6L247 64.1L244.5 67L242.5 71L241.7 76L241.8 80L242.6 85L243.5 87L246 90L250 93.5L254.3 96L255.1 103L255.3 142L250.3 150L248 152.4L246.1 151L237 141.2L224 128.5L207 112.7L206.5 112L206.4 103L205.5 97L203.4 93L200 89.6L195 86.6L192 85.5L187 84.8L182 85.5L178 87.5L175 90L171.7 94L169.7 99L169.6 107L170.6 111L172.6 115L176 119.2L181 122.3L187 123.4L196 122.3L201 120.5L230.8 149L234.4 153L236.3 156L239.3 164L235.5 171L234.6 174L233.4 184L232 185.4L222 182.5L216 181.7L201 181.6L192 182.6L184 184.6L170 190.5L162.4 181L141.7 159L142.3 152L141.4 145L138 139.1L134 135.6L129 133.5L121 133.5L112 137.6L107.6 142L105.6 146L105.5 156L107.7 162L111 166.1L114 168.4L118 170.3L123 171.3L127 171.3L131 170.5L133 169.5L136 169.8L144 176.8L162.8 195L162.6 196L158.5 201L156.5 205L153 217.5L151.4 222L149.1 226L147 228.3L145 229.5L142 230.5L131 230.5L111 229.3L105 228.3L102.8 227L98 220.6L93 216.7L90 215.5L85 214.8L80 215.5L77 216.7L72.4 220L68.9 224L66.7 230L66.6 233L67.6 238L69.7 243L71.6 246L75 249.4L80 252.4L86 253.3L93 251.5L99 247.1L103 241.5L112 240.7L142 240.5L148 239.4L150 238.5L156 234.3L160.2 229L163.4 223L164.5 219L164.6 215L165.6 212L167.6 208L173 201.8L179 197.6L186 194.6L194 192.7L205 191.5L214 191.7L224 193.8L230 196.6L235 201.2L237.2 204L243.7 215L253 227.1L253.4 229L251.5 236L251.7 241L252.7 245L254.7 249L260 254.3L267 257.4L276 257.5L279 256.5L283 254L285.3 252L287.5 249L289.3 245L290.5 239L290.5 236L289.5 232L287.5 228L284 223.9L279 220.6L276 219.5L271 218.7L263 219.1L262 218.6L252.7 209L248.8 203L245.7 196L243.7 187L243.7 181L245.6 174L249.7 168L259.3 157L262.5 151L263.4 148L264.5 141L265.5 97L271 94.5L275 91L279.4 85L280.2 81L280.3 78L279.3 73L276.4 67L274 64.2L270 60.6L266 58.5L262 57.7ZM513.5 104L514 103.6L514.4 104L514.4 106L512.4 116L510.3 120L504.6 128L502.5 133L501.5 138L500.4 153L498 154.3L484 156.7L482.7 158L486.2 161L478 171.1L476 172.4L474 172.5L467 172.3L463 171.2L457 167.5L447 156.4L446 157L440.6 173L439.6 178L439.5 187L441.5 194L443.5 198L454.1 216L453 216.4L451 215.1L444 209.3L418 182.7L410 176.5L406 174.5L401 173.5L400.5 173L400.8 172L412.2 158L421 144.9L432 144.5L438 142.5L442.3 139L447.4 133L453 123.5L473 121.5L489 117.4L497 114.4L504 111.1L507 109.4ZM406.9 241L407.4 242L407.3 249L403.4 286L399.5 315L399.7 317L413.8 335L431.6 356L450 375.6L457 382.4L462 386.4L465 388.4L468 389.1L478 388.5L488 386.7L491 386.6L495 387.6L504 391.4L509 391.7L518 390.8L518.4 392L515 394.4L501 398.6L500 400L500.9 402L506 405.5L510 406.4L514 406.4L519 405.4L525 402.6L527 402.1L527.5 403L527.2 404L521.3 411L514 417.3L507 421.3L502 423.3L497 424.4L488 424.4L481 422.3L475 419.3L468 414.1L463.6 409L461.8 406L459.5 399L456.4 394L392.6 324L392.6 311L393.6 304ZM200 241.9L193 243.5L187 246.8L184.7 249L181.8 253L178.7 259L176.7 267L176.5 272L176 273L173 274.4L141 277.6L128 280.6L122 283.5L120.2 285L107 299.3L105 300.5L102 300.9L93 298.6L86 299.5L82 301.5L78 304.7L75.5 308L73.6 312L72.5 317L72.7 322L74.5 328L77.4 332L80 334.4L85 336.5L91 337.1L97 336.4L102 334.4L105 332L106.5 330L108.4 326L109.5 322L109.7 311L111.7 308L119 300.7L126 294.7L135 289.5L142 287.7L164 285.5L177 282.6L180 282.4L188 290.3L193 293.4L197 294.9L197.5 296L197.5 315L196.3 321L193.3 327L184.2 338L160 363L157 362.4L153 360.7L148 359.7L142 360.6L137 362.6L134 364.7L131.7 367L128.7 372L127.6 378L128.5 384L131.6 391L137 396.3L141 398.5L146 399.3L154 398.5L157 397.4L159 396L161.2 394L164.4 389L164.8 370L180.3 356L189.4 346L198 335.3L201 332.6L202 332.6L210 338.3L215 340.5L219 341.5L231 342.3L248 342.8L253 343.9L255.4 346L257.4 352L258.2 367L258.2 381L257.5 391L256.1 393L246.5 402L244.5 406L243.6 410L243.8 413L245.6 419L250 425L253 427.1L256 428.5L264 429.3L271 428.4L275 426.5L279.2 423L281.4 420L283.4 416L284.4 409L283.4 404L282.5 402L280.1 399L277 396.5L269 392.2L266 390L265.5 389L265.6 386L267.5 379L268.3 370L268.3 362L267.4 348L265.5 343L263.2 340L260 336.7L257 334.5L252 332.7L240 331.6L228 331.3L221 330.4L217 329.2L213.5 327L210.6 323L208.6 314L208.3 296L218 291.4L223.3 287L226.3 283L228.5 278L229.5 274L229.4 265L227.3 258L225.2 254L222.5 250L218 245.6L211 242.5L205 241.6Z";
// Original-Schriftzug „MidMind“, vektorisiert, 656 × 124.
const WORD_PATH = "M153 -0.2L147 1.5L143 4.4L140.5 8L139.5 14L140.5 19L144 24.3L147 26.3L150 27.3L154 27.5L156 27.3L161 25.4L165.4 21L167.3 16L167.5 11L166.4 7L162.8 3L159 0.7ZM442 -0.1L438 0.6L436 1.5L432 5.1L430.6 7L429.5 10L429.5 16L431.5 21L434 24.1L437 26.3L440 27.5L445 27.5L449 26.4L453.3 23L456.3 18L457 12L456.3 8L455.3 6L452 2.6L448 0.5ZM248 1.5L247.2 2L246.5 44L246 45.3L237 39.5L230 36.5L225 35.6L220 35.5L216 35.5L210 36.6L204 38.6L200 40.7L193.1 46L187.7 52L182.8 61L180.5 68L179.6 75L180.5 93L181.7 97L185.6 105L191 112L197 117.3L202.2 120L209 122.5L225 123.4L229 122.5L235 119.5L239 117.2L245 112.7L246 112.5L247.3 115L247.4 121L248 121.7L265 122.5L267 122.5L267.5 122L267.5 2L267 1.5ZM634 1.8L632.5 44L632 45.4L625 40.6L616 36.7L611 35.6L607 35.5L601 35.5L596 36.5L590 38.6L586 40.6L579 45.8L573.6 52L570.6 57L568.6 62L566.5 70L565.9 78L566.5 88L568.5 96L572.7 105L577.9 112L584 117.3L590 120.5L597 122.5L604 123.3L609 123.4L615 122.5L622 119.5L633 112.5L633.5 113L633.5 122L634 122.5L655 122.5L655.5 122L655.5 2L655 1.5ZM0 3.5L-0.5 5L0.4 121L1 121.7L20 122.5L22 122.5L22.5 122L22.6 45L22.7 43L24 41.6L55 98.3L65 97.7L66.4 97L99 39.5L99.5 41L99.5 67L99.5 122L100 122.5L122 122.5L122.5 122L122.5 4L122 3.5L97 3.5L95.5 4L86.4 21L74.6 41L67.3 55L61 65.1L59.7 64L44.3 35L27 4.1L26 3.6ZM289 3.5L288.5 4L288.5 122L289 122.5L310 122.5L311.5 122L311.6 43L312 41.6L313.4 43L322.6 61L343 98.4L355 98.5L355.5 98L375.4 63L386.6 42L388 40.6L388.4 42L388.5 70L388.5 122L390 122.5L411 122.5L411.5 122L411.6 24L412.5 4L412 3.5L386 3.5L385 4L352.3 64L350 66.5L348.5 65L344.7 58L317.5 5L317 4.5L312 3.6ZM514 35.8L510 36.7L505 38.8L502 40.6L495 46.6L494.5 46L494.5 38L494 37.5L474 37.5L473.5 38L473.5 122L474 122.5L493 121.7L493.7 121L494.6 73L495.6 65L496.6 63L499 60.5L503.7 57L510 54.9L515 54.8L521 56.6L524 58.6L527.3 62L529.4 66L530.3 74L530.5 121L531 121.6L543 122.3L550 122.5L550.5 122L550.3 69L549.4 58L547.2 51L543 44.4L539 40.6L536 38.7L530 36.5L525 35.5ZM143 37.5L142.5 38L142.5 122L143 122.5L145 122.5L162 121.7L163 121.7L163.5 121L163.6 38L163 37.5ZM432 37.5L431.5 38L431.5 122L432 122.5L435 122.5L452 121.5L453.5 121L453.5 38L453 37.5ZM217.9 56L221 55.5L229 55.7L236 58.6L240.3 62L243.4 66L246.3 73L246.3 83L244.3 90L242.4 94L237 99.3L230 102.5L226 103.2L222 103.2L217 102.2L211 99.4L206.8 96L203.8 92L201.7 86L201.7 73L203.6 67L207 62.3L211 58.7L215 56.8ZM604.3 56L610 55.3L615 55.5L621 57.6L626 60.8L628.3 63L632.4 70L633.4 75L633.3 81L632.4 87L630.3 93L628.3 96L626 98.3L621 101.4L617 102.5L614 103.4L609 103.4L601 101.2L598 99.5L593.9 96L591.6 93L589.7 89L588.6 84L588.5 75L590.6 67L594 62.2L598 58.7Z";

/** MidMind-Logo: Gehirn aus vernetztem Wissen (links) und die Schwangere im Profil (rechts). Übernimmt die Textfarbe. */
function Logo({
  size = 44,
  variant,
  wordmark = false,
  stacked = false,
  tone = "ink",
  className,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cx("mm-logo", stacked && wordmark && "mm-logo--stacked", tone === "moss" && "mm-logo--moss", className),
    style: {
      fontSize: Math.max(16, size * 0.42),
      ...style
    },
    role: wordmark ? undefined : "img",
    "aria-label": wordmark ? undefined : "MidMind"
  }, rest), /*#__PURE__*/React.createElement("svg", {
    className: "mm-logo__mark",
    viewBox: "0 0 552 479",
    width: size,
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    fillRule: "evenodd",
    d: MARK_PATH
  })), wordmark && /*#__PURE__*/React.createElement("svg", {
    className: "mm-logo__word",
    viewBox: "0 0 656 124",
    height: stacked ? size * 0.225 : size * 0.3,
    role: "img",
    "aria-label": "MidMind"
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    fillRule: "evenodd",
    d: WORD_PATH
  })));
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Logo.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function cx(...p) {
  return p.filter(Boolean).join(" ");
}

/** Lebensphasen – überall gleich farbcodiert. */
const PHASES = {
  schwangerschaft: {
    label: "Schwangerschaft",
    color: "var(--mm-apricot)",
    tone: "apricot"
  },
  geburt: {
    label: "Geburt",
    color: "var(--mm-malve)",
    tone: "malve"
  },
  wochenbett: {
    label: "Wochenbett",
    color: "var(--mm-sage)",
    tone: "sage"
  }
};

/** Kleines Etikett für Lebensphase, Status oder Kategorie. Nicht klickbar – dafür PhaseChip. */
function Badge({
  tone = "neutral",
  phase,
  size = "md",
  className,
  children,
  ...rest
}) {
  const t = phase ? PHASES[phase].tone : tone;
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cx("mm-badge", `mm-badge--${t}`, size === "sm" && "mm-badge--sm", className)
  }, rest), children ?? (phase ? PHASES[phase].label : null));
}
Object.assign(__ds_scope, { PHASES, Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Badge.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Callout.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function cx(...p) {
  return p.filter(Boolean).join(" ");
}

/** Hinweis- oder Notfallbox mit Symbol, Titel und Text. Notfälle stehen in einer Antwort ganz oben. */
function Callout({
  tone = "info",
  title,
  children,
  className,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: tone === "critical" ? "alert" : "note",
    className: cx("mm-callout", `mm-callout--${tone}`, className)
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: tone === "critical" ? "alert" : "info",
    size: 24,
    className: "mm-callout__icon"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("strong", {
    className: "mm-callout__title"
  }, title), children && /*#__PURE__*/React.createElement("div", {
    className: "mm-callout__body"
  }, children)));
}
Object.assign(__ds_scope, { Callout });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Callout.jsx", error: String((e && e.message) || e) }); }

// components/forms/Composer.jsx
try { (() => {
const {
  useState
} = React;
function cx(...p) {
  return p.filter(Boolean).join(" ");
}

/** Eingabezeile für Fragen, mit Senden- und optionalem Diktat-Button. Mindestens 58 px hoch. */
function Composer({
  placeholder = "Frage stellen …",
  value,
  onChange,
  onSubmit,
  searchIcon,
  dictation,
  onDictate,
  disclaimer,
  className
}) {
  const [own, setOwn] = useState("");
  const text = value ?? own;
  const set = v => {
    if (value === undefined) setOwn(v);
    onChange?.(v);
  };
  const submit = e => {
    e.preventDefault();
    const t = text.trim();
    if (!t) return;
    onSubmit?.(t);
    if (value === undefined) setOwn("");
  };
  const showMic = dictation && text.trim() === "";
  return /*#__PURE__*/React.createElement("form", {
    className: cx("mm-composer", className),
    onSubmit: submit,
    role: "search"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mm-composer__box"
  }, searchIcon && /*#__PURE__*/React.createElement("span", {
    className: "mm-composer__lead"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "search"
  })), /*#__PURE__*/React.createElement("input", {
    className: "mm-composer__input",
    value: text,
    placeholder: placeholder,
    "aria-label": placeholder.replace(/\s*…$/, ""),
    onChange: e => set(e.target.value)
  }), showMic ? /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "mic",
    label: "Frage diktieren",
    variant: "primary",
    onClick: onDictate
  }) : /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "send",
    label: "Senden",
    variant: "primary",
    type: "submit"
  })), disclaimer && /*#__PURE__*/React.createElement("div", {
    className: "mm-composer__disclaimer"
  }, disclaimer));
}
Object.assign(__ds_scope, { Composer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Composer.jsx", error: String((e && e.message) || e) }); }

// components/forms/PhaseChip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function cx(...p) {
  return p.filter(Boolean).join(" ");
}

/** Umschaltbarer Filter-Chip für eine Lebensphase. */
function PhaseChip({
  phase,
  selected = false,
  className,
  type = "button",
  ...rest
}) {
  const p = __ds_scope.PHASES[phase];
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    "aria-pressed": selected,
    className: cx("mm-phase-chip", className)
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "mm-phase-chip__dot",
    style: {
      background: p.color
    },
    "aria-hidden": "true"
  }), p.label);
}
Object.assign(__ds_scope, { PhaseChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/PhaseChip.jsx", error: String((e && e.message) || e) }); }

// components/forms/PhaseChipGroup.jsx
try { (() => {
function cx(...p) {
  return p.filter(Boolean).join(" ");
}

/** Die drei PhaseChips (Schwangerschaft, Geburt, Wochenbett) als Einzelauswahl. */
function PhaseChipGroup({
  value,
  onChange,
  label = "Lebensphase",
  className
}) {
  return /*#__PURE__*/React.createElement("div", {
    role: "group",
    "aria-label": label,
    className: cx("mm-phase-chips", className)
  }, Object.keys(__ds_scope.PHASES).map(p => /*#__PURE__*/React.createElement(__ds_scope.PhaseChip, {
    key: p,
    phase: p,
    selected: value === p,
    onClick: () => onChange?.(value === p ? null : p)
  })));
}
Object.assign(__ds_scope, { PhaseChipGroup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/PhaseChipGroup.jsx", error: String((e && e.message) || e) }); }

// components/forms/TextField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useId
} = React;
function cx(...p) {
  return p.filter(Boolean).join(" ");
}

/** Einzeiliges Eingabefeld mit Beschriftung, 52 px hoch, 18 px Schrift. */
function TextField({
  label,
  hint,
  error,
  id,
  className,
  ...rest
}) {
  const auto = useId();
  const fieldId = id ?? auto;
  const hintId = `${fieldId}-hint`;
  const message = error ?? hint;
  return /*#__PURE__*/React.createElement("div", {
    className: cx("mm-field", error && "mm-field--error", className)
  }, /*#__PURE__*/React.createElement("label", {
    className: "mm-field__label",
    htmlFor: fieldId
  }, label), /*#__PURE__*/React.createElement("input", _extends({
    id: fieldId,
    className: "mm-field__input",
    "aria-invalid": error ? true : undefined,
    "aria-describedby": message ? hintId : undefined
  }, rest)), message && /*#__PURE__*/React.createElement("span", {
    id: hintId,
    className: "mm-field__hint"
  }, message));
}
Object.assign(__ds_scope, { TextField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/TextField.jsx", error: String((e && e.message) || e) }); }

// components/forms/TextSizeSwitch.jsx
try { (() => {
function cx(...p) {
  return p.filter(Boolean).join(" ");
}
const OPTIONS = [{
  size: "normal",
  px: 15,
  label: "Normale Schrift"
}, {
  size: "large",
  px: 18,
  label: "Große Schrift"
}, {
  size: "xlarge",
  px: 22,
  label: "Sehr große Schrift"
}];

/** Dreistufiger Schalter für die Textgröße der Antworten (A A A). */
function TextSizeSwitch({
  value,
  onChange,
  className
}) {
  return /*#__PURE__*/React.createElement("div", {
    role: "group",
    "aria-label": "Textgr\xF6\xDFe",
    className: cx("mm-textsize", className)
  }, OPTIONS.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.size,
    type: "button",
    className: "mm-textsize__opt",
    style: {
      fontSize: o.px
    },
    "aria-pressed": value === o.size,
    "aria-label": o.label,
    onClick: () => onChange?.(o.size)
  }, "A")));
}
Object.assign(__ds_scope, { TextSizeSwitch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/TextSizeSwitch.jsx", error: String((e && e.message) || e) }); }

// components/layout/MidMindRoot.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function cx(...p) {
  return p.filter(Boolean).join(" ");
}

/** Wurzel jeder MidMind-Oberfläche: Hintergrund, Schrift, Fokusrahmen, Nachtmodus, Textgröße. */
function MidMindRoot({
  theme = "day",
  textSize = "normal",
  className,
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cx("mm-root", className),
    "data-mm-theme": theme,
    "data-mm-text": textSize === "normal" ? undefined : textSize
  }, rest), children);
}
Object.assign(__ds_scope, { MidMindRoot });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/MidMindRoot.jsx", error: String((e && e.message) || e) }); }

// components/navigation/AppBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function cx(...p) {
  return p.filter(Boolean).join(" ");
}

/** Kopfzeile eines App-Bildschirms. 64 px hoch, Titel links, Aktionen rechts. */
function AppBar({
  title,
  leading,
  trailing,
  className,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("header", _extends({
    className: cx("mm-appbar", className)
  }, rest), leading && /*#__PURE__*/React.createElement("div", {
    className: "mm-appbar__slot"
  }, leading), /*#__PURE__*/React.createElement("div", {
    className: "mm-appbar__title"
  }, title), trailing && /*#__PURE__*/React.createElement("div", {
    className: "mm-appbar__slot"
  }, trailing));
}
Object.assign(__ds_scope, { AppBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/AppBar.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NavItem.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function cx(...p) {
  return p.filter(Boolean).join(" ");
}

/** Eintrag in der Desktop-Seitenleiste: frühere Fragen oder Wissenssammlungen. */
function NavItem({
  label,
  phase,
  icon,
  count,
  active,
  className,
  href = "#",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    className: cx("mm-navitem", className),
    "aria-current": active ? "page" : undefined
  }, rest), phase ? /*#__PURE__*/React.createElement("span", {
    className: "mm-navitem__dot",
    style: {
      background: __ds_scope.PHASES[phase].color
    },
    "aria-hidden": "true"
  }) : icon, /*#__PURE__*/React.createElement("span", {
    className: "mm-navitem__label"
  }, label), count !== undefined && /*#__PURE__*/React.createElement("span", {
    className: "mm-navitem__count"
  }, count));
}
Object.assign(__ds_scope, { NavItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NavItem.jsx", error: String((e && e.message) || e) }); }

// components/navigation/TabBar.jsx
try { (() => {
function cx(...p) {
  return p.filter(Boolean).join(" ");
}
const DEFAULT_TABS = [{
  id: "fragen",
  label: "Fragen",
  icon: "chat"
}, {
  id: "wissen",
  label: "Wissen",
  icon: "book"
}, {
  id: "notizen",
  label: "Notizen",
  icon: "note"
}, {
  id: "verlauf",
  label: "Verlauf",
  icon: "clock"
}];

/** Untere Navigationsleiste der mobilen App. Aktiver Tab mit Salbei-Pille. */
function TabBar({
  items,
  activeId,
  onChange,
  className
}) {
  return /*#__PURE__*/React.createElement("nav", {
    className: cx("mm-tabbar", className),
    "aria-label": "Hauptnavigation"
  }, items.map(it => /*#__PURE__*/React.createElement("button", {
    key: it.id,
    type: "button",
    className: "mm-tabbar__item",
    "aria-current": it.id === activeId ? "page" : undefined,
    onClick: () => onChange?.(it.id)
  }, /*#__PURE__*/React.createElement("span", {
    className: "mm-tabbar__pill"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: it.icon,
    size: 24
  })), it.label)));
}
Object.assign(__ds_scope, { DEFAULT_TABS, TabBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/TabBar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/Account.jsx
try { (() => {
(() => {
  // Anmeldung und Konto: Login, Nutzer-Menü, Formulare für Name/E-Mail und Passwort.
  // Menü, Sheet und Dialog sind UI-Kit-Bausteine (kein Gegenstück in @midmind/ui).
  const NS = () => window.MidMindDesignSystem_0ec547;
  const EMAIL_RE = /^\S+@\S+\.\S+$/;
  const DEMO_USER = {
    name: 'Hanna Kröger',
    email: 'hanna.kroeger@praxis-mondschein.de',
    role: 'admin',
    hasPassword: true,
    passkeys: [{
      id: 1,
      name: 'iPhone',
      added: '12.09.2026',
      last: 'heute'
    }]
  };
  const firstName = n => n.trim().split(/\s+/)[0];
  const initials = n => n.trim().split(/\s+/).map(p => p[0]).slice(0, 2).join('').toUpperCase();
  function Initials({
    name,
    size = 36
  }) {
    return /*#__PURE__*/React.createElement("span", {
      "aria-hidden": "true",
      style: {
        width: size,
        height: size,
        borderRadius: 999,
        background: 'var(--mm-sage)',
        color: 'var(--mm-ink)',
        display: 'grid',
        placeItems: 'center',
        fontWeight: 700,
        fontSize: Math.round(size * 0.4),
        flex: 'none'
      }
    }, initials(name));
  }
  function AvatarButton({
    user,
    onClick
  }) {
    return /*#__PURE__*/React.createElement("button", {
      type: "button",
      onClick: onClick,
      "aria-label": "Konto-Men\xFC",
      title: "Konto-Men\xFC",
      style: {
        width: 44,
        height: 44,
        borderRadius: 999,
        border: 0,
        padding: 0,
        background: 'transparent',
        display: 'grid',
        placeItems: 'center',
        cursor: 'pointer'
      }
    }, /*#__PURE__*/React.createElement(Initials, {
      name: user.name,
      size: 34
    }));
  }
  function LoginForm({
    onLogin
  }) {
    const {
      TextField,
      Button,
      Callout,
      Icon
    } = NS();
    const [email, setEmail] = React.useState(DEMO_USER.email);
    const [waiting, setWaiting] = React.useState(false);
    const [pw, setPw] = React.useState('');
    const [err, setErr] = React.useState({});
    const [reset, setReset] = React.useState(false);
    const submit = e => {
      e.preventDefault();
      const n = {};
      if (!EMAIL_RE.test(email)) n.email = 'Bitte eine gültige E-Mail-Adresse eingeben, z. B. name@praxis.de.';
      if (!pw) n.pw = 'Bitte dein Passwort eingeben.';
      setErr(n);
      if (!n.email && !n.pw) onLogin({
        ...DEMO_USER,
        email
      });
    };
    const passkey = () => {
      setErr({});
      setWaiting(true);
      setTimeout(() => {
        setWaiting(false);
        onLogin(DEMO_USER);
      }, 1400);
    };
    const forgot = () => {
      if (!EMAIL_RE.test(email)) {
        setErr({
          email: 'Trag zuerst deine E-Mail-Adresse ein.'
        });
        return;
      }
      setErr({});
      setReset(true);
    };
    return /*#__PURE__*/React.createElement("form", {
      onSubmit: submit,
      noValidate: true,
      style: {
        display: 'grid',
        gap: 'var(--mm-space-4)'
      }
    }, reset && /*#__PURE__*/React.createElement(Callout, {
      tone: "info",
      title: "Link ist unterwegs"
    }, "Wir haben dir einen Link zum Zur\xFCcksetzen an ", /*#__PURE__*/React.createElement("strong", null, email), " geschickt."), /*#__PURE__*/React.createElement(TextField, {
      label: "E-Mail-Adresse",
      type: "email",
      autoComplete: "email",
      value: email,
      error: err.email,
      onChange: e => {
        setEmail(e.target.value);
        setErr({
          ...err,
          email: undefined
        });
      }
    }), /*#__PURE__*/React.createElement(TextField, {
      label: "Passwort",
      type: "password",
      autoComplete: "current-password",
      value: pw,
      error: err.pw,
      onChange: e => {
        setPw(e.target.value);
        setErr({
          ...err,
          pw: undefined
        });
      }
    }), /*#__PURE__*/React.createElement(Button, {
      type: "submit",
      block: true,
      disabled: waiting
    }, "Anmelden"), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "sm",
      onClick: forgot,
      style: {
        justifySelf: 'center',
        border: 0
      }
    }, "Passwort vergessen?"), /*#__PURE__*/React.createElement("div", {
      "aria-hidden": "true",
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--mm-space-3)',
        color: 'var(--mm-muted)',
        fontSize: 'var(--mm-text-small)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        height: 1,
        background: 'var(--mm-line)'
      }
    }), "oder", /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        height: 1,
        background: 'var(--mm-line)'
      }
    })), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      block: true,
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: "key",
        size: 20
      }),
      onClick: passkey,
      disabled: waiting
    }, waiting ? 'Warte auf deinen Passkey …' : 'Mit Passkey anmelden'));
  }
  function BetaNote() {
    return /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        fontSize: 'var(--mm-text-small)',
        color: 'var(--mm-muted)',
        lineHeight: 1.5,
        textAlign: 'center',
        textWrap: 'pretty'
      }
    }, "Noch kein Zugang? MidMind ist in der geschlossenen Testphase. ", /*#__PURE__*/React.createElement("a", {
      href: "../website/index.html#testphase"
    }, "Einladung anfragen"));
  }
  function LoginScreen({
    layout = 'mobile',
    onLogin
  }) {
    const {
      MidMindRoot,
      Logo,
      DisplayHeading
    } = NS();
    if (layout === 'desktop') {
      return /*#__PURE__*/React.createElement(MidMindRoot, {
        style: {
          height: '100%',
          display: 'grid',
          placeItems: 'center',
          padding: 'var(--mm-space-5)',
          boxSizing: 'border-box',
          overflow: 'auto'
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          width: '100%',
          maxWidth: 440,
          display: 'grid',
          gap: 'var(--mm-space-5)'
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          display: 'grid',
          justifyItems: 'center',
          gap: 'var(--mm-space-4)'
        }
      }, /*#__PURE__*/React.createElement(Logo, {
        size: 96,
        wordmark: true,
        stacked: true
      }), /*#__PURE__*/React.createElement(DisplayHeading, {
        as: "h1",
        size: "md"
      }, "Willkommen zur\xFCck.")), /*#__PURE__*/React.createElement("div", {
        style: {
          background: 'var(--mm-card)',
          border: '1px solid var(--mm-line)',
          borderRadius: 'var(--mm-radius-l)',
          padding: 'var(--mm-space-6)'
        }
      }, /*#__PURE__*/React.createElement(LoginForm, {
        onLogin: onLogin
      })), /*#__PURE__*/React.createElement(BetaNote, null)));
    }
    return /*#__PURE__*/React.createElement(MidMindRoot, {
      style: {
        height: '100%',
        display: 'grid',
        gridTemplateRows: '1fr auto',
        overflow: 'auto'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 'var(--mm-space-7) var(--mm-space-4) var(--mm-space-5)',
        display: 'grid',
        gap: 'var(--mm-space-6)',
        alignContent: 'start'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        justifyItems: 'center',
        gap: 'var(--mm-space-4)'
      }
    }, /*#__PURE__*/React.createElement(Logo, {
      size: 88,
      wordmark: true,
      stacked: true
    }), /*#__PURE__*/React.createElement(DisplayHeading, {
      as: "h1",
      size: "md"
    }, "Willkommen zur\xFCck.")), /*#__PURE__*/React.createElement(LoginForm, {
      onLogin: onLogin
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 'var(--mm-space-4) var(--mm-space-4) var(--mm-space-6)'
      }
    }, /*#__PURE__*/React.createElement(BetaNote, null)));
  }
  const MENU_ITEMS = [{
    id: 'profile',
    label: 'Name und E-Mail ändern',
    icon: 'user'
  }, {
    id: 'password',
    label: 'Passwort ändern',
    icon: 'lock'
  }, {
    id: 'passkeys',
    label: 'Passkeys',
    icon: 'key'
  }, {
    id: 'admin',
    label: 'Benutzer verwalten',
    icon: 'user',
    adminOnly: true,
    divider: true
  }, {
    id: 'logout',
    label: 'Abmelden',
    icon: 'logout',
    divider: true
  }];
  function UserMenuList({
    user,
    onSelect
  }) {
    const {
      Icon
    } = NS();
    return /*#__PURE__*/React.createElement("div", {
      role: "menu",
      "aria-label": "Konto",
      style: {
        display: 'grid'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--mm-space-3)',
        padding: 'var(--mm-space-3) var(--mm-space-4)',
        borderBottom: '1px solid var(--mm-line)'
      }
    }, /*#__PURE__*/React.createElement(Initials, {
      name: user.name,
      size: 40
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("strong", {
      style: {
        fontSize: 16
      }
    }, user.name), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 14,
        color: 'var(--mm-muted)',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    }, user.email))), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 'var(--mm-space-2)',
        display: 'grid',
        gap: 2
      }
    }, MENU_ITEMS.filter(m => !m.adminOnly || user.role === 'admin').map(m => m.id === 'password' && !user.hasPassword ? {
      ...m,
      label: 'Passwort festlegen'
    } : m).map(it => /*#__PURE__*/React.createElement(React.Fragment, {
      key: it.id
    }, it.divider && /*#__PURE__*/React.createElement("div", {
      style: {
        height: 1,
        background: 'var(--mm-line)',
        margin: '4px 8px'
      }
    }), /*#__PURE__*/React.createElement("button", {
      type: "button",
      role: "menuitem",
      onClick: () => onSelect(it.id),
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--mm-space-3)',
        minHeight: 48,
        padding: '0 12px',
        border: 0,
        borderRadius: 12,
        background: 'transparent',
        color: 'var(--mm-ink)',
        font: '600 16px/1.3 var(--mm-font)',
        textAlign: 'left',
        cursor: 'pointer'
      },
      onMouseEnter: e => {
        e.currentTarget.style.background = 'var(--mm-sand)';
      },
      onMouseLeave: e => {
        e.currentTarget.style.background = 'transparent';
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--mm-muted)',
        display: 'inline-flex'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: it.icon,
      size: 20
    })), it.label)))));
  }
  const SCRIM = {
    position: 'absolute',
    inset: 0,
    background: 'rgba(43, 34, 32, .36)',
    zIndex: 20
  };
  function Sheet({
    onClose,
    children
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: SCRIM,
      onClick: onClose
    }, /*#__PURE__*/React.createElement("div", {
      onClick: e => e.stopPropagation(),
      style: {
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: 0,
        background: 'var(--mm-card)',
        borderRadius: 'var(--mm-radius-l) var(--mm-radius-l) 0 0',
        paddingBottom: 'var(--mm-space-5)',
        boxShadow: 'var(--mm-shadow)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 40,
        height: 5,
        borderRadius: 999,
        background: 'var(--mm-line)',
        margin: '10px auto 4px'
      }
    }), children));
  }
  function Popover({
    onClose,
    style,
    children
  }) {
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'fixed',
        inset: 0,
        zIndex: 20
      },
      onClick: onClose
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        zIndex: 21,
        background: 'var(--mm-card)',
        border: '1px solid var(--mm-line)',
        borderRadius: 'var(--mm-radius-m)',
        boxShadow: 'var(--mm-shadow)',
        ...style
      }
    }, children));
  }
  function Dialog({
    title,
    onClose,
    width = 480,
    children
  }) {
    const {
      IconButton
    } = NS();
    return /*#__PURE__*/React.createElement("div", {
      style: {
        ...SCRIM,
        display: 'grid',
        placeItems: 'center',
        padding: 'var(--mm-space-5)'
      },
      onClick: onClose
    }, /*#__PURE__*/React.createElement("div", {
      role: "dialog",
      "aria-modal": "true",
      "aria-label": title,
      onClick: e => e.stopPropagation(),
      style: {
        width: '100%',
        maxWidth: width,
        maxHeight: '100%',
        overflow: 'auto',
        boxSizing: 'border-box',
        background: 'var(--mm-card)',
        borderRadius: 'var(--mm-radius-l)',
        boxShadow: 'var(--mm-shadow)',
        padding: 'var(--mm-space-5) var(--mm-space-5) var(--mm-space-5) var(--mm-space-6)',
        display: 'grid',
        gap: 'var(--mm-space-4)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'flex-start',
        justifyContent: 'space-between',
        gap: 'var(--mm-space-3)'
      }
    }, /*#__PURE__*/React.createElement("h2", {
      style: {
        margin: 0,
        fontSize: 'var(--mm-text-h)',
        lineHeight: 1.3,
        paddingTop: 8,
        textWrap: 'balance'
      }
    }, title), /*#__PURE__*/React.createElement(IconButton, {
      icon: "close",
      label: "Schlie\xDFen",
      onClick: onClose
    })), children));
  }

  // kind: "profile" | "password"
  function AccountForm({
    kind,
    user,
    onSave,
    onCancel,
    layout = 'mobile'
  }) {
    const {
      TextField,
      Button,
      Callout
    } = NS();
    const setting = kind === 'password' && !user.hasPassword;
    const canRemove = kind === 'password' && user.hasPassword && user.passkeys.length > 0;
    const [v, setV] = React.useState(kind === 'profile' ? {
      name: user.name,
      email: user.email
    } : {
      current: '',
      next: '',
      repeat: ''
    });
    const [err, setErr] = React.useState({});
    const [done, setDone] = React.useState(null);
    const set = k => e => {
      setV({
        ...v,
        [k]: e.target.value
      });
      setErr({
        ...err,
        [k]: undefined
      });
      setDone(null);
    };
    const submit = e => {
      e.preventDefault();
      const n = {};
      if (kind === 'profile') {
        if (!v.name.trim()) n.name = 'Bitte deinen Namen eingeben.';
        if (!EMAIL_RE.test(v.email)) n.email = 'Bitte eine gültige E-Mail-Adresse eingeben, z. B. name@praxis.de.';
      } else {
        if (!setting && !v.current) n.current = 'Bitte dein aktuelles Passwort eingeben.';
        if (v.next.length < 10) n.next = 'Das neue Passwort braucht mindestens 10 Zeichen.';else if (v.repeat !== v.next) n.repeat = 'Die Passwörter stimmen nicht überein.';
      }
      setErr(n);
      if (Object.keys(n).length) return;
      if (kind === 'profile') {
        const mailChanged = v.email !== user.email;
        onSave({
          ...user,
          name: v.name.trim()
        });
        setDone(mailChanged ? {
          title: 'Name gespeichert',
          body: /*#__PURE__*/React.createElement(React.Fragment, null, "Bitte best\xE4tige deine neue Adresse \xFCber den Link, den wir an ", /*#__PURE__*/React.createElement("strong", null, v.email), " geschickt haben. Bis dahin gilt die alte.")
        } : {
          title: 'Gespeichert'
        });
      } else {
        setV({
          current: '',
          next: '',
          repeat: ''
        });
        onSave({
          ...user,
          hasPassword: true
        });
        setDone(setting ? {
          title: 'Passwort festgelegt',
          body: 'Du kannst dich jetzt zusätzlich mit E-Mail und Passwort anmelden.'
        } : {
          title: 'Passwort geändert',
          body: 'Du bleibst auf diesem Gerät angemeldet.'
        });
      }
    };
    const removePassword = () => {
      onSave({
        ...user,
        hasPassword: false
      });
      setV({
        current: '',
        next: '',
        repeat: ''
      });
      setErr({});
      setDone({
        title: 'Passwort entfernt',
        body: 'Du meldest dich ab jetzt nur noch mit deinem Passkey an.'
      });
    };
    return /*#__PURE__*/React.createElement("form", {
      onSubmit: submit,
      noValidate: true,
      style: {
        display: 'grid',
        gap: 'var(--mm-space-4)'
      }
    }, done && /*#__PURE__*/React.createElement(Callout, {
      tone: "info",
      title: done.title
    }, done.body), setting && !done && /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        fontSize: 'var(--mm-text-small)',
        color: 'var(--mm-muted)',
        lineHeight: 1.5
      }
    }, "Du meldest dich ohne Passwort an, nur mit Passkey. Ein Passwort brauchst du nur f\xFCr Ger\xE4te ohne Passkey."), kind === 'profile' ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(TextField, {
      label: "Name",
      autoComplete: "name",
      value: v.name,
      onChange: set('name'),
      error: err.name,
      hint: "So begr\xFC\xDFt dich MidMind."
    }), /*#__PURE__*/React.createElement(TextField, {
      label: "E-Mail-Adresse",
      type: "email",
      autoComplete: "email",
      value: v.email,
      onChange: set('email'),
      error: err.email,
      hint: "Mit dieser Adresse meldest du dich an."
    })) : /*#__PURE__*/React.createElement(React.Fragment, null, !setting && /*#__PURE__*/React.createElement(TextField, {
      label: "Aktuelles Passwort",
      type: "password",
      autoComplete: "current-password",
      value: v.current,
      onChange: set('current'),
      error: err.current
    }), /*#__PURE__*/React.createElement(TextField, {
      label: "Neues Passwort",
      type: "password",
      autoComplete: "new-password",
      value: v.next,
      onChange: set('next'),
      error: err.next,
      hint: "Mindestens 10 Zeichen."
    }), /*#__PURE__*/React.createElement(TextField, {
      label: "Neues Passwort wiederholen",
      type: "password",
      autoComplete: "new-password",
      value: v.repeat,
      onChange: set('repeat'),
      error: err.repeat
    })), layout === 'desktop' ? /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'flex-end',
        gap: 'var(--mm-space-3)',
        marginTop: 'var(--mm-space-2)'
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: onCancel
    }, done ? 'Schließen' : 'Abbrechen'), /*#__PURE__*/React.createElement(Button, {
      type: "submit"
    }, setting ? 'Passwort festlegen' : 'Speichern')) : /*#__PURE__*/React.createElement(Button, {
      type: "submit",
      block: true
    }, setting ? 'Passwort festlegen' : 'Speichern'), canRemove && /*#__PURE__*/React.createElement("div", {
      style: {
        borderTop: '1px solid var(--mm-line)',
        paddingTop: 'var(--mm-space-4)',
        display: 'grid',
        gap: 'var(--mm-space-3)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gap: 4
      }
    }, /*#__PURE__*/React.createElement("strong", {
      style: {
        fontSize: 16
      }
    }, "Ohne Passwort anmelden"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 'var(--mm-text-small)',
        color: 'var(--mm-muted)',
        lineHeight: 1.5
      }
    }, "Du hast ", user.passkeys.length === 1 ? 'einen Passkey' : user.passkeys.length + ' Passkeys', ". Entferne dein Passwort, dann meldest du dich nur noch per Passkey an.")), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: removePassword,
      style: layout === 'desktop' ? {
        justifySelf: 'start'
      } : undefined,
      block: layout !== 'desktop'
    }, "Passwort entfernen")));
  }
  const ACCOUNT_TITLES = {
    profile: 'Name und E-Mail',
    password: 'Passwort ändern',
    passkeys: 'Passkeys',
    admin: 'Benutzer verwalten'
  };
  function PasskeyManager({
    user,
    onSave,
    onCancel,
    layout = 'mobile'
  }) {
    const {
      Button,
      Callout,
      Icon
    } = NS();
    const keys = user.passkeys;
    const setKeys = fn => onSave({
      ...user,
      passkeys: fn(user.passkeys)
    });
    const [adding, setAdding] = React.useState(false);
    const [msg, setMsg] = React.useState(null);
    const add = () => {
      setAdding(true);
      setMsg(null);
      setTimeout(() => {
        setAdding(false);
        setKeys(k => [...k, {
          id: Date.now(),
          name: layout === 'desktop' ? 'Dieser Rechner' : 'Dieses Gerät',
          added: '27.09.2026',
          last: 'noch nie'
        }]);
        setMsg({
          title: 'Passkey hinzugefügt',
          body: 'Ab jetzt kannst du dich auf diesem Gerät ohne Passwort anmelden.'
        });
      }, 1400);
    };
    const remove = id => {
      if (!user.hasPassword && keys.length === 1) {
        setMsg({
          tone: 'warning',
          title: 'Das ist dein einziger Anmeldeweg',
          body: 'Füge zuerst einen weiteren Passkey hinzu oder lege ein Passwort fest.'
        });
        return;
      }
      setKeys(k => k.filter(x => x.id !== id));
      setMsg({
        title: 'Passkey entfernt'
      });
    };
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gap: 'var(--mm-space-4)'
      }
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        fontSize: 'var(--mm-text-small)',
        color: 'var(--mm-muted)',
        lineHeight: 1.5
      }
    }, "Mit einem Passkey meldest du dich per Face ID, Fingerabdruck oder Ger\xE4te-PIN an \u2013 ohne Passwort. ", user.hasPassword ? 'Wenn du möchtest, kannst du dein Passwort danach unter „Passwort ändern“ entfernen.' : 'Du meldest dich derzeit nur mit Passkey an.'), msg && /*#__PURE__*/React.createElement(Callout, {
      tone: msg.tone || 'info',
      title: msg.title
    }, msg.body), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gap: 'var(--mm-space-2)'
      }
    }, keys.length === 0 && /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 'var(--mm-space-4)',
        border: '2px dashed var(--mm-line)',
        borderRadius: 'var(--mm-radius-m)',
        color: 'var(--mm-muted)',
        fontSize: 'var(--mm-text-small)',
        textAlign: 'center'
      }
    }, "Noch kein Passkey eingerichtet."), keys.map(k => /*#__PURE__*/React.createElement("div", {
      key: k.id,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--mm-space-3)',
        padding: 'var(--mm-space-3) var(--mm-space-4)',
        background: 'var(--mm-paper)',
        border: '1px solid var(--mm-line)',
        borderRadius: 'var(--mm-radius-m)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--mm-muted)',
        display: 'inline-flex'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "key",
      size: 22
    })), /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'grid',
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("strong", {
      style: {
        fontSize: 16
      }
    }, k.name), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 14,
        color: 'var(--mm-muted)'
      }
    }, "Hinzugef\xFCgt ", k.added, " \xB7 zuletzt genutzt ", k.last)), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "sm",
      onClick: () => remove(k.id)
    }, "Entfernen")))), layout === 'desktop' ? /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'flex-end',
        gap: 'var(--mm-space-3)',
        marginTop: 'var(--mm-space-2)'
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: onCancel
    }, "Schlie\xDFen"), /*#__PURE__*/React.createElement(Button, {
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: "plus",
        size: 18
      }),
      onClick: add,
      disabled: adding
    }, adding ? 'Warte auf dein Gerät …' : 'Passkey hinzufügen')) : /*#__PURE__*/React.createElement(Button, {
      block: true,
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: "plus",
        size: 18
      }),
      onClick: add,
      disabled: adding
    }, adding ? 'Warte auf dein Gerät …' : 'Passkey hinzufügen'));
  }
  Object.assign(window, {
    DEMO_USER,
    firstName,
    Initials,
    AvatarButton,
    LoginScreen,
    UserMenuList,
    Sheet,
    Popover,
    Dialog,
    AccountForm,
    PasskeyManager,
    ACCOUNT_TITLES
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/Account.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/Admin.jsx
try { (() => {
(() => {
  // Benutzerverwaltung (nur Admins). Kompakte Liste, Aktionen klappen pro Zeile auf, Formular „Benutzer hinzufügen“ am Ende.
  const NS = () => window.MidMindDesignSystem_0ec547;
  const ROLES = [{
    id: 'user',
    label: 'Benutzer'
  }, {
    id: 'admin',
    label: 'Admin'
  }];
  const roleLabel = r => ROLES.find(x => x.id === r).label;
  const SEED_USERS = [{
    id: 1,
    name: 'Hanna Kröger',
    email: 'hanna.kroeger@praxis-mondschein.de',
    role: 'admin',
    last: 'heute',
    passkeys: 1,
    active: true,
    me: true
  }, {
    id: 2,
    name: 'Anna-Carolin Heller',
    email: 'annacarolinheller@gmail.com',
    role: 'user',
    last: null,
    passkeys: 0,
    active: true
  }, {
    id: 3,
    name: 'Danielle Kraatz',
    email: 'danielle.kraatz90@gmail.com',
    role: 'user',
    last: null,
    passkeys: 0,
    active: true
  }, {
    id: 4,
    name: 'Merle Albers',
    email: 'merle.albers@praxis-mondschein.de',
    role: 'user',
    last: 'gestern',
    passkeys: 2,
    active: true
  }, {
    id: 5,
    name: 'Sophie Brandt',
    email: 's.brandt@hebammen-nord.de',
    role: 'user',
    last: '03.08.2026',
    passkeys: 1,
    active: false
  }];
  const meta = u => `${u.last ? 'Zuletzt angemeldet ' + u.last : 'Noch nie angemeldet'} · ${u.passkeys === 1 ? '1 Passkey' : u.passkeys + ' Passkeys'}`;
  function RoleSelect({
    value,
    onChange,
    compact,
    disabled,
    id,
    'aria-label': ariaLabel
  }) {
    return /*#__PURE__*/React.createElement("select", {
      id: id,
      "aria-label": ariaLabel,
      className: "mm-field__input",
      value: value,
      disabled: disabled,
      onChange: e => onChange(e.target.value),
      style: compact ? {
        width: 'auto',
        minHeight: 44,
        fontSize: 16,
        paddingRight: 12,
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.5 : 1
      } : {
        cursor: 'pointer'
      }
    }, ROLES.map(r => /*#__PURE__*/React.createElement("option", {
      key: r.id,
      value: r.id
    }, r.label)));
  }
  function UserRowItem({
    u,
    open,
    onToggle,
    onChange,
    layout
  }) {
    const {
      Badge,
      Button,
      IconButton,
      Callout
    } = NS();
    const [note, setNote] = React.useState(null);
    const desktop = layout === 'desktop';
    const panelId = `user-actions-${u.id}`;
    return /*#__PURE__*/React.createElement("li", {
      style: {
        listStyle: 'none',
        borderTop: '1px solid var(--mm-line)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      onClick: onToggle,
      style: {
        display: 'grid',
        gridTemplateColumns: desktop ? '36px minmax(0,1fr) auto 44px' : '36px minmax(0,1fr) 44px',
        alignItems: 'center',
        gap: 'var(--mm-space-3)',
        padding: '10px var(--mm-space-3) 10px var(--mm-space-4)',
        cursor: 'pointer',
        background: open ? 'var(--mm-paper)' : 'transparent'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        opacity: u.active ? 1 : 0.5
      }
    }, /*#__PURE__*/React.createElement(Initials, {
      name: u.name,
      size: 36
    })), /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'grid',
        minWidth: 0,
        gap: 1
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--mm-space-2)',
        minWidth: 0,
        flexWrap: 'wrap'
      }
    }, /*#__PURE__*/React.createElement("strong", {
      style: {
        fontSize: 16,
        color: u.active ? 'var(--mm-ink)' : 'var(--mm-muted)'
      }
    }, u.name, u.me && /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: 400,
        color: 'var(--mm-muted)'
      }
    }, " (du)")), u.role === 'admin' && /*#__PURE__*/React.createElement(Badge, {
      tone: "sage",
      size: "sm"
    }, "Admin"), !u.active && /*#__PURE__*/React.createElement(Badge, {
      tone: "neutral",
      size: "sm"
    }, "Deaktiviert")), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 14,
        color: 'var(--mm-muted)',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    }, u.email), !desktop && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 14,
        color: 'var(--mm-muted)'
      }
    }, meta(u))), desktop && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 14,
        color: 'var(--mm-muted)',
        textAlign: 'right',
        whiteSpace: 'nowrap'
      }
    }, meta(u)), /*#__PURE__*/React.createElement("span", {
      onClick: e => e.stopPropagation(),
      style: {
        display: 'inline-flex',
        transform: open ? 'rotate(-90deg)' : 'rotate(90deg)'
      }
    }, /*#__PURE__*/React.createElement(IconButton, {
      icon: "chevronRight",
      label: open ? `Aktionen für ${u.name} schließen` : `Aktionen für ${u.name}`,
      "aria-expanded": open,
      "aria-controls": panelId,
      onClick: onToggle
    }))), open && /*#__PURE__*/React.createElement("div", {
      id: panelId,
      style: {
        padding: '4px var(--mm-space-4) var(--mm-space-4)',
        paddingLeft: desktop ? 'calc(var(--mm-space-4) + 36px + var(--mm-space-3))' : 'var(--mm-space-4)',
        background: 'var(--mm-paper)',
        display: 'grid',
        gap: 'var(--mm-space-3)'
      }
    }, note && /*#__PURE__*/React.createElement(Callout, {
      tone: "info",
      title: note.title
    }, note.body), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        gap: 'var(--mm-space-2)',
        flexWrap: 'wrap'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        marginRight: 'auto'
      }
    }, /*#__PURE__*/React.createElement(RoleSelect, {
      id: `role-${u.id}`,
      compact: true,
      value: u.role,
      disabled: u.me,
      onChange: r => {
        onChange({
          ...u,
          role: r
        });
        setNote({
          title: `${u.name} ist jetzt ${roleLabel(r)}`
        });
      },
      "aria-label": `Rolle von ${u.name}`
    })), !u.me && /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "sm",
      onClick: () => {
        onChange({
          ...u,
          active: !u.active
        });
        setNote(u.active ? {
          title: 'Deaktiviert',
          body: `${u.name} kann sich nicht mehr anmelden. Die Daten bleiben erhalten.`
        } : {
          title: 'Wieder aktiv',
          body: `${u.name} kann sich wieder anmelden.`
        });
      }
    }, u.active ? 'Deaktivieren' : 'Reaktivieren'), !u.me && u.active && /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "sm",
      onClick: () => setNote({
        title: 'Link ist unterwegs',
        body: /*#__PURE__*/React.createElement(React.Fragment, null, "Wir haben einen Link zum Zur\xFCcksetzen an ", /*#__PURE__*/React.createElement("strong", null, u.email), " geschickt.")
      })
    }, "Passwort zur\xFCcksetzen")), u.me && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 14,
        color: 'var(--mm-muted)',
        textAlign: 'right'
      }
    }, "Deine eigene Rolle und deinen Zugang \xE4nderst du hier nicht.")));
  }
  function AddUserForm({
    onAdd,
    layout
  }) {
    const {
      TextField,
      Button,
      Callout
    } = NS();
    const empty = {
      email: '',
      name: '',
      role: 'user'
    };
    const [v, setV] = React.useState(empty);
    const [err, setErr] = React.useState({});
    const [done, setDone] = React.useState(null);
    const set = k => e => {
      setV({
        ...v,
        [k]: e.target.value
      });
      setErr({
        ...err,
        [k]: undefined
      });
      setDone(null);
    };
    const submit = e => {
      e.preventDefault();
      const n = {};
      if (!/^\S+@\S+\.\S+$/.test(v.email.trim())) n.email = 'Bitte eine gültige E-Mail-Adresse eingeben, z. B. name@praxis.de.';
      if (!v.name.trim()) n.name = 'Bitte den Namen der Person eingeben.';
      setErr(n);
      if (Object.keys(n).length) return;
      onAdd({
        id: Date.now(),
        name: v.name.trim(),
        email: v.email.trim(),
        role: v.role,
        last: null,
        passkeys: 0,
        active: true
      });
      setDone({
        name: v.name.trim(),
        email: v.email.trim()
      });
      setV(empty);
    };
    return /*#__PURE__*/React.createElement("form", {
      onSubmit: submit,
      noValidate: true,
      style: {
        background: 'var(--mm-card)',
        border: '1px solid var(--mm-line)',
        borderRadius: 'var(--mm-radius-l)',
        padding: layout === 'desktop' ? 'var(--mm-space-6)' : 'var(--mm-space-5) var(--mm-space-4)',
        display: 'grid',
        gap: 'var(--mm-space-4)'
      }
    }, /*#__PURE__*/React.createElement("h2", {
      style: {
        margin: 0,
        fontSize: 'var(--mm-text-h)',
        lineHeight: 1.3
      }
    }, "Benutzer hinzuf\xFCgen"), done && /*#__PURE__*/React.createElement(Callout, {
      tone: "info",
      title: `${done.name} hinzugefügt`
    }, "Wir haben eine Einladung an ", /*#__PURE__*/React.createElement("strong", null, done.email), " geschickt. Dar\xFCber legt die Person ihr Passwort fest."), /*#__PURE__*/React.createElement(TextField, {
      label: "E-Mail-Adresse",
      type: "email",
      autoComplete: "off",
      value: v.email,
      onChange: set('email'),
      error: err.email,
      hint: "Damit meldet sich die Person an. Wir schicken ihr eine Einladung."
    }), /*#__PURE__*/React.createElement(TextField, {
      label: "Name",
      autoComplete: "off",
      value: v.name,
      onChange: set('name'),
      error: err.name,
      hint: "So wird die Person in MidMind begr\xFC\xDFt."
    }), /*#__PURE__*/React.createElement("div", {
      className: "mm-field"
    }, /*#__PURE__*/React.createElement("label", {
      className: "mm-field__label",
      htmlFor: "new-user-role"
    }, "Rolle"), /*#__PURE__*/React.createElement(RoleSelect, {
      id: "new-user-role",
      value: v.role,
      onChange: r => setV({
        ...v,
        role: r
      })
    })), /*#__PURE__*/React.createElement(Button, {
      type: "submit",
      block: true
    }, "Einladung senden"));
  }
  function UserAdmin({
    layout = 'mobile'
  }) {
    const {
      DisplayHeading
    } = NS();
    const [users, setUsers] = React.useState(SEED_USERS);
    const [open, setOpen] = React.useState(null);
    const desktop = layout === 'desktop';
    const inactive = users.filter(u => !u.active).length;
    const update = nu => setUsers(list => list.map(u => u.id === nu.id ? nu : u));
    return /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 720,
        margin: '0 auto',
        padding: desktop ? 'var(--mm-space-6) var(--mm-space-4) var(--mm-space-7)' : 'var(--mm-space-5) var(--mm-space-4) var(--mm-space-6)',
        display: 'grid',
        gap: 'var(--mm-space-5)'
      }
    }, desktop && /*#__PURE__*/React.createElement(DisplayHeading, {
      as: "h1",
      size: "md"
    }, "Benutzer verwalten"), /*#__PURE__*/React.createElement("section", {
      "aria-label": "Benutzer",
      style: {
        background: 'var(--mm-card)',
        border: '1px solid var(--mm-line)',
        borderRadius: 'var(--mm-radius-l)',
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 'var(--mm-space-3) var(--mm-space-4)',
        fontSize: 14,
        color: 'var(--mm-muted)'
      }
    }, users.length, " Benutzer", inactive ? ` · ${inactive} deaktiviert` : ''), /*#__PURE__*/React.createElement("ul", {
      style: {
        margin: 0,
        padding: 0
      }
    }, users.map(u => /*#__PURE__*/React.createElement(UserRowItem, {
      key: u.id,
      u: u,
      layout: layout,
      open: open === u.id,
      onToggle: () => setOpen(open === u.id ? null : u.id),
      onChange: update
    })))), /*#__PURE__*/React.createElement(AddUserForm, {
      layout: layout,
      onAdd: u => setUsers(l => [...l, u])
    }));
  }
  Object.assign(window, {
    UserAdmin
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/Admin.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/DesktopApp.jsx
try { (() => {
(() => {
  const {
    MidMindRoot,
    AppBar,
    Logo,
    IconButton,
    Badge,
    Button,
    Icon,
    NavItem,
    Composer,
    SuggestionButton,
    ChatQuestion
  } = window.MidMindDesignSystem_0ec547;
  function UserRow({
    user,
    open,
    onToggle,
    onSelect
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative'
      }
    }, /*#__PURE__*/React.createElement("button", {
      type: "button",
      onClick: onToggle,
      "aria-haspopup": "menu",
      "aria-expanded": open,
      style: {
        width: '100%',
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--mm-space-3)',
        minHeight: 56,
        padding: '6px 10px',
        border: 0,
        borderRadius: 12,
        background: open ? 'var(--mm-card)' : 'transparent',
        color: 'var(--mm-ink)',
        font: 'inherit',
        textAlign: 'left',
        cursor: 'pointer'
      }
    }, /*#__PURE__*/React.createElement(Initials, {
      name: user.name,
      size: 36
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'grid',
        minWidth: 0,
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("strong", {
      style: {
        fontSize: 15
      }
    }, user.name), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        color: 'var(--mm-muted)',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    }, user.email)), /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--mm-muted)',
        display: 'inline-flex',
        transform: 'rotate(-90deg)'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "chevronRight",
      size: 18
    }))), open && /*#__PURE__*/React.createElement(Popover, {
      onClose: onToggle,
      style: {
        left: 0,
        right: 0,
        bottom: 'calc(100% + 8px)'
      }
    }, /*#__PURE__*/React.createElement(UserMenuList, {
      user: user,
      onSelect: onSelect
    })));
  }
  function Sidebar({
    view,
    activeKey,
    onNew,
    onOpen,
    onLeitlinien,
    user,
    menu,
    onMenu,
    onSelect
  }) {
    return /*#__PURE__*/React.createElement("aside", {
      style: {
        background: 'var(--mm-sand)',
        padding: 'var(--mm-space-4) var(--mm-space-3)',
        display: 'grid',
        gridTemplateRows: 'auto auto 1fr auto',
        gap: 'var(--mm-space-4)',
        minHeight: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '4px 6px'
      }
    }, /*#__PURE__*/React.createElement(Logo, {
      size: 36,
      wordmark: true
    })), /*#__PURE__*/React.createElement(Button, {
      block: true,
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: "plus",
        size: 18
      }),
      onClick: onNew
    }, "Neue Frage"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gap: 2,
        alignContent: 'start'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: 'var(--mm-muted)',
        padding: '8px 10px 4px'
      }
    }, "Verlauf"), HISTORY.map(h => /*#__PURE__*/React.createElement(NavItem, {
      key: h.label,
      label: h.label,
      phase: h.phase,
      active: view === 'chat' && !!h.key && h.key === activeKey,
      onClick: e => {
        e.preventDefault();
        if (h.key) onOpen(h.key);
      }
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: 'var(--mm-muted)',
        padding: '16px 10px 4px'
      }
    }, "Wissen"), /*#__PURE__*/React.createElement(NavItem, {
      label: "Leitlinien",
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: "folder",
        size: 18
      }),
      count: LEITLINIEN.length,
      active: view === 'leitlinien',
      onClick: e => {
        e.preventDefault();
        onLeitlinien();
      }
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        borderTop: '1px solid var(--mm-line)',
        paddingTop: 'var(--mm-space-3)'
      }
    }, /*#__PURE__*/React.createElement(UserRow, {
      user: user,
      open: menu,
      onToggle: onMenu,
      onSelect: onSelect
    })));
  }
  function DesktopApp({
    initialUser = null,
    initialView = 'chat'
  }) {
    const [user, setUser] = React.useState(initialUser);
    const [menu, setMenu] = React.useState(false);
    const [account, setAccount] = React.useState(null);
    const [source, setSource] = React.useState(null);
    const [night, setNight] = React.useState(false);
    const [view, setView] = React.useState(initialView);
    const [turns, setTurns] = React.useState([{
      q: ANSWERS.trinkmenge.question,
      key: 'trinkmenge'
    }]);
    const scrollRef = React.useRef(null);
    const ask = (q, key) => {
      setView('chat');
      setTurns(t => [...t, {
        q,
        key: key || matchAnswer(q)
      }]);
    };
    React.useEffect(() => {
      const el = scrollRef.current;
      if (el) el.scrollTop = el.scrollHeight;
    }, [turns]);
    if (!user) return /*#__PURE__*/React.createElement(LoginScreen, {
      layout: "desktop",
      onLogin: setUser
    });
    const pick = id => {
      setMenu(false);
      if (id === 'logout') {
        setUser(null);
        setAccount(null);
      } else if (id === 'admin') setView('admin');else setAccount(id);
    };
    const last = turns.length ? ANSWERS[turns[turns.length - 1].key] : null;
    const isChat = view === 'chat';
    return /*#__PURE__*/React.createElement(MidMindRoot, {
      theme: night ? 'night' : 'day',
      style: {
        position: 'relative',
        display: 'grid',
        gridTemplateColumns: '280px 1fr',
        height: '100%',
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement(Sidebar, {
      view: view,
      activeKey: turns[0]?.key,
      onNew: () => {
        setView('chat');
        setTurns([]);
      },
      onOpen: k => {
        setView('chat');
        setTurns([{
          q: ANSWERS[k].question,
          key: k
        }]);
      },
      onLeitlinien: () => setView('leitlinien'),
      user: user,
      menu: menu,
      onMenu: () => setMenu(!menu),
      onSelect: pick
    }), view === 'admin' ? /*#__PURE__*/React.createElement("main", {
      style: {
        display: 'grid',
        gridTemplateRows: 'auto 1fr',
        minHeight: 0
      }
    }, /*#__PURE__*/React.createElement(AppBar, {
      title: "Verwaltung",
      trailing: /*#__PURE__*/React.createElement(IconButton, {
        icon: night ? 'sun' : 'moon',
        label: night ? 'Tagmodus' : 'Nachtmodus',
        onClick: () => setNight(!night)
      })
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        overflow: 'auto',
        minHeight: 0
      }
    }, /*#__PURE__*/React.createElement(UserAdmin, {
      layout: "desktop"
    }))) : /*#__PURE__*/React.createElement("main", {
      style: {
        display: 'grid',
        gridTemplateRows: 'auto 1fr auto',
        minHeight: 0
      }
    }, /*#__PURE__*/React.createElement(AppBar, {
      title: isChat ? last ? last.title : 'Neue Frage' : 'Leitlinien',
      trailing: /*#__PURE__*/React.createElement(React.Fragment, null, isChat && last && /*#__PURE__*/React.createElement(Badge, {
        phase: last.phase,
        size: "sm"
      }), /*#__PURE__*/React.createElement(IconButton, {
        icon: night ? 'sun' : 'moon',
        label: night ? 'Tagmodus' : 'Nachtmodus',
        onClick: () => setNight(!night)
      }))
    }), /*#__PURE__*/React.createElement("div", {
      ref: scrollRef,
      style: {
        overflow: 'auto',
        minHeight: 0
      }
    }, isChat ? /*#__PURE__*/React.createElement("div", {
      onClick: e => {
        const l = sourceFromClick(e);
        if (l) setSource(l);
      },
      style: {
        maxWidth: 720,
        margin: '0 auto',
        padding: 'var(--mm-space-5) var(--mm-space-4)',
        display: 'grid',
        gap: 'var(--mm-space-4)'
      }
    }, turns.length === 0 && /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gap: 'var(--mm-space-2)'
      }
    }, SUGGESTIONS.map(s => /*#__PURE__*/React.createElement(SuggestionButton, {
      key: s.key,
      onClick: () => ask(ANSWERS[s.key].question, s.key)
    }, s.text))), turns.map((t, i) => /*#__PURE__*/React.createElement(React.Fragment, {
      key: i
    }, /*#__PURE__*/React.createElement(ChatQuestion, null, t.q), ANSWERS[t.key].render()))) : /*#__PURE__*/React.createElement(LeitlinienList, null)), /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 720,
        width: '100%',
        margin: '0 auto',
        padding: 'var(--mm-space-3) var(--mm-space-4) var(--mm-space-4)'
      }
    }, /*#__PURE__*/React.createElement(Composer, {
      placeholder: isChat && turns.length ? 'Nachfragen …' : 'Frage stellen …',
      dictation: !(isChat && turns.length),
      searchIcon: !(isChat && turns.length),
      onSubmit: q => ask(q),
      disclaimer: DISCLAIMER
    }))), source && /*#__PURE__*/React.createElement(SourceOverlay, {
      label: source,
      layout: "desktop",
      onClose: () => setSource(null)
    }), account && /*#__PURE__*/React.createElement(Dialog, {
      title: account === 'password' && !user.hasPassword ? 'Passwort festlegen' : ACCOUNT_TITLES[account],
      onClose: () => setAccount(null)
    }, account === 'passkeys' ? /*#__PURE__*/React.createElement(PasskeyManager, {
      user: user,
      onSave: setUser,
      layout: "desktop",
      onCancel: () => setAccount(null)
    }) : /*#__PURE__*/React.createElement(AccountForm, {
      key: account,
      kind: account,
      user: user,
      onSave: setUser,
      onCancel: () => setAccount(null),
      layout: "desktop"
    })));
  }
  window.DesktopApp = DesktopApp;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/DesktopApp.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/Literature.jsx
try { (() => {
(() => {
  // Klick auf einen Quellen-Chip oder eine hochgestellte Quellennummer öffnet den zugehörigen Textauszug.
  // Per Event-Delegation, damit AnswerCard unverändert bleibt.
  function sourceFromClick(e) {
    const chip = e.target.closest('.mm-source');
    const ref = e.target.closest('.mm-ref');
    if (!chip && !ref) return null;
    e.preventDefault();
    let el = chip;
    if (ref) {
      const n = parseInt(ref.textContent, 10);
      const answer = ref.closest('.mm-answer');
      el = answer ? answer.querySelectorAll('.mm-source')[n - 1] : null;
    }
    if (!el) return null;
    const label = (el.getAttribute('aria-label') || '').replace(/^Quelle \d+:\s*/, '');
    return LITERATURE[label] ? label : null;
  }
  function Excerpt({
    src
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        background: 'var(--mm-sand)',
        borderRadius: 'var(--mm-radius-m)',
        padding: 'var(--mm-space-4) var(--mm-space-5)',
        fontSize: 'var(--mm-text-body)',
        lineHeight: 'var(--mm-leading)',
        textWrap: 'pretty'
      }
    }, src.before, ' ', /*#__PURE__*/React.createElement("mark", {
      style: {
        background: 'var(--mm-apricot)',
        color: 'var(--mm-on-apricot)',
        borderRadius: 4,
        padding: '1px 3px',
        boxDecorationBreak: 'clone',
        WebkitBoxDecorationBreak: 'clone'
      }
    }, src.highlight), ' ', src.after);
  }
  function SourceBody({
    label,
    layout
  }) {
    const {
      Badge,
      Button,
      Icon
    } = window.MidMindDesignSystem_0ec547;
    const src = LITERATURE[label];
    const [copied, setCopied] = React.useState(false);
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gap: 'var(--mm-space-4)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--mm-space-2)',
        flexWrap: 'wrap',
        fontSize: 'var(--mm-text-small)',
        color: 'var(--mm-muted)'
      }
    }, src.level && /*#__PURE__*/React.createElement(Badge, {
      tone: "ok",
      size: "sm"
    }, src.level), /*#__PURE__*/React.createElement("span", null, src.publisher), /*#__PURE__*/React.createElement("span", {
      "aria-hidden": "true"
    }, "\xB7"), /*#__PURE__*/React.createElement("span", null, src.section), /*#__PURE__*/React.createElement("span", {
      "aria-hidden": "true"
    }, "\xB7"), /*#__PURE__*/React.createElement("span", null, src.page)), /*#__PURE__*/React.createElement(Excerpt, {
      src: src
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        color: 'var(--mm-muted)'
      }
    }, "Beispielauszug \u2013 im Produkt steht hier der Originaltext."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 'var(--mm-space-3)',
        flexWrap: 'wrap',
        justifyContent: layout === 'desktop' ? 'flex-end' : 'stretch'
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "sm",
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: copied ? 'check' : 'copy',
        size: 18
      }),
      onClick: () => setCopied(true)
    }, copied ? 'Kopiert' : 'Zitat kopieren'), src.pdf && /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "sm",
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: "book",
        size: 18
      })
    }, "Ganze Leitlinie \xF6ffnen")));
  }
  function SourceOverlay({
    label,
    layout = 'mobile',
    onClose
  }) {
    const {
      IconButton
    } = window.MidMindDesignSystem_0ec547;
    if (!label) return null;
    const src = LITERATURE[label];
    if (layout === 'desktop') {
      return /*#__PURE__*/React.createElement(Dialog, {
        title: src.title,
        width: 640,
        onClose: onClose
      }, /*#__PURE__*/React.createElement(SourceBody, {
        label: label,
        layout: "desktop"
      }));
    }
    return /*#__PURE__*/React.createElement(Sheet, {
      onClose: onClose
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 'var(--mm-space-2) var(--mm-space-4) 0',
        display: 'grid',
        gap: 'var(--mm-space-3)',
        maxHeight: '72vh',
        overflow: 'auto'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'flex-start',
        gap: 'var(--mm-space-3)'
      }
    }, /*#__PURE__*/React.createElement("h2", {
      style: {
        margin: 0,
        flex: 1,
        fontSize: 'var(--mm-text-h)',
        lineHeight: 1.3,
        paddingTop: 8
      }
    }, src.title), /*#__PURE__*/React.createElement(IconButton, {
      icon: "close",
      label: "Schlie\xDFen",
      onClick: onClose
    })), /*#__PURE__*/React.createElement(SourceBody, {
      label: label,
      layout: "mobile"
    })));
  }
  Object.assign(window, {
    sourceFromClick,
    SourceOverlay
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/Literature.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/MobileApp.jsx
try { (() => {
(() => {
  function MobileApp() {
    const {
      MidMindRoot,
      AppBar,
      IconButton,
      Badge,
      Composer,
      TabBar
    } = window.MidMindDesignSystem_0ec547;
    const [user, setUser] = React.useState(null);
    const [night, setNight] = React.useState(false);
    const [textSize, setTextSize] = React.useState('normal');
    const [showText, setShowText] = React.useState(false);
    const [tab, setTab] = React.useState('fragen');
    const [phase, setPhase] = React.useState(null);
    const [turns, setTurns] = React.useState([]);
    const [menu, setMenu] = React.useState(false);
    const [account, setAccount] = React.useState(null); // 'profile' | 'password' | 'passkeys'
    const [source, setSource] = React.useState(null);
    const scrollRef = React.useRef(null);
    React.useEffect(() => {
      const el = scrollRef.current;
      if (el) el.scrollTop = el.scrollHeight;
    }, [turns]);
    if (!user) return /*#__PURE__*/React.createElement(LoginScreen, {
      layout: "mobile",
      onLogin: u => {
        setUser(u);
        setTab('fragen');
        setTurns([]);
      }
    });
    const ask = (q, key) => {
      setTab('fragen');
      setTurns(t => [...t, {
        q,
        key: key || matchAnswer(q)
      }]);
    };
    const open = k => {
      setTab('fragen');
      setTurns([{
        q: ANSWERS[k].question,
        key: k
      }]);
    };
    const onTab = id => {
      if (id === 'fragen' && tab === 'fragen') setTurns([]);
      setTab(id);
    };
    const pick = id => {
      setMenu(false);
      if (id === 'logout') {
        setUser(null);
        setAccount(null);
      } else setAccount(id);
    };
    const inChat = tab === 'fragen' && turns.length > 0;
    const current = inChat ? ANSWERS[turns[turns.length - 1].key] : null;
    const home = tab === 'fragen' && !inChat;
    const avatar = /*#__PURE__*/React.createElement(AvatarButton, {
      user: user,
      onClick: () => setMenu(true)
    });
    const nightBtn = /*#__PURE__*/React.createElement(IconButton, {
      icon: night ? 'sun' : 'moon',
      label: night ? 'Tagmodus' : 'Nachtmodus',
      onClick: () => setNight(!night)
    });
    let bar,
      body,
      composer = true;
    if (account) {
      bar = /*#__PURE__*/React.createElement(AppBar, {
        title: account === 'password' && !user.hasPassword ? 'Passwort festlegen' : ACCOUNT_TITLES[account],
        leading: /*#__PURE__*/React.createElement(IconButton, {
          icon: "chevronLeft",
          label: "Zur\xFCck",
          onClick: () => setAccount(null)
        })
      });
      body = account === 'admin' ? /*#__PURE__*/React.createElement("div", {
        style: {
          overflow: 'auto',
          minHeight: 0
        }
      }, /*#__PURE__*/React.createElement(UserAdmin, null)) : /*#__PURE__*/React.createElement("div", {
        style: {
          padding: 'var(--mm-space-5) var(--mm-space-4)',
          overflow: 'auto',
          minHeight: 0
        }
      }, account === 'passkeys' ? /*#__PURE__*/React.createElement(PasskeyManager, {
        user: user,
        onSave: setUser
      }) : /*#__PURE__*/React.createElement(AccountForm, {
        key: account,
        kind: account,
        user: user,
        onSave: setUser
      }));
      composer = false;
    } else if (inChat) {
      bar = /*#__PURE__*/React.createElement(AppBar, {
        title: current.title,
        leading: /*#__PURE__*/React.createElement(IconButton, {
          icon: "chevronLeft",
          label: "Neue Frage",
          onClick: () => setTurns([])
        }),
        trailing: /*#__PURE__*/React.createElement(Badge, {
          phase: current.phase,
          size: "sm"
        })
      });
      body = /*#__PURE__*/React.createElement(Conversation, {
        turns: turns,
        scrollRef: scrollRef,
        onClick: e => {
          const l = sourceFromClick(e);
          if (l) setSource(l);
        }
      });
    } else if (home) {
      bar = /*#__PURE__*/React.createElement(HomeBar, {
        night: night,
        onNight: () => setNight(!night),
        onText: () => setShowText(!showText),
        account: avatar
      });
      body = /*#__PURE__*/React.createElement(StartScreen, {
        phase: phase,
        onPhase: setPhase,
        onAsk: ask,
        name: firstName(user.name)
      });
    } else if (tab === 'verlauf') {
      bar = /*#__PURE__*/React.createElement(AppBar, {
        title: "Verlauf",
        trailing: /*#__PURE__*/React.createElement(React.Fragment, null, nightBtn, avatar)
      });
      body = /*#__PURE__*/React.createElement(HistoryList, {
        activeKey: turns[0]?.key,
        onOpen: open
      });
    } else {
      bar = /*#__PURE__*/React.createElement(AppBar, {
        title: "Leitlinien",
        trailing: /*#__PURE__*/React.createElement(React.Fragment, null, nightBtn, avatar)
      });
      body = /*#__PURE__*/React.createElement(LeitlinienList, {
        compact: true
      });
    }
    return /*#__PURE__*/React.createElement(MidMindRoot, {
      theme: night ? 'night' : 'day',
      textSize: textSize,
      style: {
        position: 'relative',
        display: 'grid',
        gridTemplateRows: 'auto auto 1fr auto auto',
        height: '100%',
        overflow: 'hidden'
      }
    }, bar, showText && home && !account ? /*#__PURE__*/React.createElement(TextSizePanel, {
      value: textSize,
      onChange: setTextSize
    }) : /*#__PURE__*/React.createElement("div", null), body, composer ? /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 'var(--mm-space-3) var(--mm-space-4)'
      }
    }, inChat ? /*#__PURE__*/React.createElement(Composer, {
      placeholder: "Nachfragen \u2026",
      onSubmit: q => ask(q),
      disclaimer: DISCLAIMER
    }) : /*#__PURE__*/React.createElement(Composer, {
      placeholder: "Frage stellen \u2026",
      searchIcon: true,
      dictation: true,
      onSubmit: q => {
        setTurns([]);
        ask(q);
      },
      disclaimer: home ? undefined : DISCLAIMER
    })) : /*#__PURE__*/React.createElement("div", null), account ? /*#__PURE__*/React.createElement("div", null) : /*#__PURE__*/React.createElement(TabBar, {
      items: APP_TABS,
      activeId: tab,
      onChange: onTab
    }), source && /*#__PURE__*/React.createElement(SourceOverlay, {
      label: source,
      onClose: () => setSource(null)
    }), menu && /*#__PURE__*/React.createElement(Sheet, {
      onClose: () => setMenu(false)
    }, /*#__PURE__*/React.createElement(UserMenuList, {
      user: user,
      onSelect: pick
    })));
  }
  window.MobileApp = MobileApp;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/MobileApp.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/Screens.jsx
try { (() => {
(() => {
  const {
    AppBar,
    Logo,
    IconButton,
    Badge,
    Button,
    Icon,
    NavItem,
    DisplayHeading,
    PhaseChipGroup,
    SuggestionButton,
    Composer,
    ChatQuestion,
    TextSizeSwitch
  } = window.MidMindDesignSystem_0ec547;
  const DISCLAIMER = 'MidMind ist eine KI und macht Fehler.';
  function HomeBar({
    night,
    onNight,
    onText,
    account
  }) {
    return /*#__PURE__*/React.createElement(AppBar, {
      title: "MidMind",
      leading: /*#__PURE__*/React.createElement(Logo, {
        size: 30
      }),
      trailing: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(IconButton, {
        icon: "text",
        label: "Textgr\xF6\xDFe",
        onClick: onText
      }), /*#__PURE__*/React.createElement(IconButton, {
        icon: night ? 'sun' : 'moon',
        label: night ? 'Tagmodus' : 'Nachtmodus',
        onClick: onNight
      }), account)
    });
  }
  function TextSizePanel({
    value,
    onChange
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 'var(--mm-space-3) var(--mm-space-4)',
        borderBottom: '1px solid var(--mm-line)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: 'var(--mm-space-3)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: 600,
        fontSize: 'var(--mm-text-small)'
      }
    }, "Textgr\xF6\xDFe"), /*#__PURE__*/React.createElement(TextSizeSwitch, {
      value: value,
      onChange: onChange
    }));
  }
  function StartScreen({
    phase,
    onPhase,
    onAsk,
    name = 'Hanna'
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 'var(--mm-space-5) var(--mm-space-4)',
        display: 'grid',
        gap: 'var(--mm-space-5)',
        alignContent: 'start',
        overflow: 'auto'
      }
    }, /*#__PURE__*/React.createElement(DisplayHeading, {
      as: "h1",
      size: "md"
    }, "Guten Abend, ", name, "."), /*#__PURE__*/React.createElement(PhaseChipGroup, {
      value: phase,
      onChange: onPhase
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gap: 'var(--mm-space-2)'
      }
    }, SUGGESTIONS.map(s => /*#__PURE__*/React.createElement(SuggestionButton, {
      key: s.key,
      onClick: () => onAsk(ANSWERS[s.key].question, s.key)
    }, s.text))));
  }
  function Conversation({
    turns,
    scrollRef,
    onClick
  }) {
    return /*#__PURE__*/React.createElement("div", {
      ref: scrollRef,
      onClick: onClick,
      style: {
        padding: 'var(--mm-space-4)',
        display: 'grid',
        gap: 'var(--mm-space-4)',
        alignContent: 'start',
        overflow: 'auto',
        minHeight: 0
      }
    }, turns.map((t, i) => /*#__PURE__*/React.createElement(React.Fragment, {
      key: i
    }, /*#__PURE__*/React.createElement(ChatQuestion, null, t.q), ANSWERS[t.key].render())));
  }
  function LeitlinienList({
    compact
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: compact ? 'var(--mm-space-4)' : 'var(--mm-space-5) var(--mm-space-4)',
        maxWidth: 720,
        width: '100%',
        boxSizing: 'border-box',
        margin: '0 auto',
        display: 'grid',
        gap: 'var(--mm-space-3)',
        alignContent: 'start',
        overflow: 'auto',
        minHeight: 0
      }
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        color: 'var(--mm-muted)',
        fontSize: 'var(--mm-text-small)'
      }
    }, "Die S3-Leitlinien, auf die sich MidMind st\xFCtzt, zum Nachlesen als PDF."), LEITLINIEN.map(l => /*#__PURE__*/React.createElement("div", {
      key: l.id,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--mm-space-3)',
        padding: 'var(--mm-space-3) var(--mm-space-4)',
        background: 'var(--mm-card)',
        border: '1px solid var(--mm-line)',
        borderRadius: 'var(--mm-radius-m)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--mm-muted)',
        display: 'inline-flex'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "book",
      size: 22
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0,
        display: 'grid',
        gap: 2
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: 700,
        fontSize: 16,
        lineHeight: 1.35
      }
    }, l.title), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 14,
        color: 'var(--mm-muted)'
      }
    }, compact ? `${l.id} · ${l.level}` : l.id)), compact ? /*#__PURE__*/React.createElement(IconButton, {
      icon: "chevronRight",
      label: "PDF \xF6ffnen"
    }) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Badge, {
      tone: "ok",
      size: "sm"
    }, l.level), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "sm"
    }, "PDF \xF6ffnen")))));
  }
  function HistoryList({
    activeKey,
    onOpen
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 'var(--mm-space-3)',
        display: 'grid',
        gap: 2,
        alignContent: 'start',
        overflow: 'auto',
        minHeight: 0
      }
    }, HISTORY.map(h => /*#__PURE__*/React.createElement(NavItem, {
      key: h.label,
      label: h.label,
      phase: h.phase,
      active: !!h.key && h.key === activeKey,
      onClick: e => {
        e.preventDefault();
        if (h.key) onOpen(h.key);
      }
    })));
  }
  Object.assign(window, {
    HomeBar,
    TextSizePanel,
    StartScreen,
    Conversation,
    LeitlinienList,
    HistoryList,
    DISCLAIMER
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/Screens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/Welcome.jsx
try { (() => {
(() => {
  // Einladungs-Seite: einmaliger Link aus der Einladungs-Mail. Schritt 1 Passwort festlegen, Schritt 2 Passkey (optional), dann in die App.
  const NS = () => window.MidMindDesignSystem_0ec547;
  const INVITE = {
    name: 'Anna-Carolin Heller',
    email: 'annacarolinheller@gmail.com',
    invitedBy: 'Hanna Kröger'
  };
  function StepLabel({
    n
  }) {
    return /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 'var(--mm-text-small)',
        fontWeight: 600,
        color: 'var(--mm-muted)'
      }
    }, "Schritt ", n, " von 2");
  }
  function PasswordStep({
    invite,
    onDone
  }) {
    const {
      TextField,
      Button
    } = NS();
    const [v, setV] = React.useState({
      next: invite.demoPassword || '',
      repeat: invite.demoPassword || ''
    });
    const [err, setErr] = React.useState({});
    const set = k => e => {
      setV({
        ...v,
        [k]: e.target.value
      });
      setErr({
        ...err,
        [k]: undefined
      });
    };
    const submit = e => {
      e.preventDefault();
      const n = {};
      if (v.next.length < 10) n.next = 'Dein Passwort braucht mindestens 10 Zeichen.';else if (v.repeat !== v.next) n.repeat = 'Die Passwörter stimmen nicht überein.';
      setErr(n);
      if (!Object.keys(n).length) onDone();
    };
    return /*#__PURE__*/React.createElement("form", {
      onSubmit: submit,
      noValidate: true,
      style: {
        display: 'grid',
        gap: 'var(--mm-space-4)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gap: 4
      }
    }, /*#__PURE__*/React.createElement(StepLabel, {
      n: 1
    }), /*#__PURE__*/React.createElement("h2", {
      style: {
        margin: 0,
        fontSize: 'var(--mm-text-h)',
        lineHeight: 1.3
      }
    }, "Passwort festlegen")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gap: 2
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 'var(--mm-text-small)',
        fontWeight: 600
      }
    }, "Du meldest dich an mit"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 16,
        overflowWrap: 'anywhere'
      }
    }, invite.email)), /*#__PURE__*/React.createElement("input", {
      type: "email",
      autoComplete: "username",
      value: invite.email,
      readOnly: true,
      hidden: true
    }), /*#__PURE__*/React.createElement(TextField, {
      label: "Passwort",
      type: "password",
      autoComplete: "new-password",
      value: v.next,
      onChange: set('next'),
      error: err.next,
      hint: "Mindestens 10 Zeichen."
    }), /*#__PURE__*/React.createElement(TextField, {
      label: "Passwort wiederholen",
      type: "password",
      autoComplete: "new-password",
      value: v.repeat,
      onChange: set('repeat'),
      error: err.repeat
    }), /*#__PURE__*/React.createElement(Button, {
      type: "submit",
      block: true
    }, "Weiter"));
  }
  function PasskeyStep({
    layout,
    onDone
  }) {
    const {
      Button,
      Icon
    } = NS();
    const [waiting, setWaiting] = React.useState(false);
    const add = () => {
      setWaiting(true);
      setTimeout(() => onDone({
        id: Date.now(),
        name: layout === 'desktop' ? 'Dieser Rechner' : 'Dieses Gerät',
        added: '01.10.2026',
        last: 'heute'
      }), 1400);
    };
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gap: 'var(--mm-space-4)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gap: 4
      }
    }, /*#__PURE__*/React.createElement(StepLabel, {
      n: 2
    }), /*#__PURE__*/React.createElement("h2", {
      style: {
        margin: 0,
        fontSize: 'var(--mm-text-h)',
        lineHeight: 1.3
      }
    }, "Passkey hinzuf\xFCgen")), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        fontSize: 16,
        lineHeight: 1.5,
        textWrap: 'pretty'
      }
    }, "Mit einem Passkey meldest du dich auf diesem Ger\xE4t per Face ID, Fingerabdruck oder Ger\xE4te-PIN an \u2013 ohne Passwort. Dein Passwort bleibt f\xFCr andere Ger\xE4te."), /*#__PURE__*/React.createElement(Button, {
      block: true,
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: "key",
        size: 20
      }),
      onClick: add,
      disabled: waiting
    }, waiting ? 'Warte auf dein Gerät …' : 'Passkey hinzufügen'), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      block: true,
      onClick: () => onDone(null),
      disabled: waiting
    }, "Sp\xE4ter"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 14,
        color: 'var(--mm-muted)',
        textAlign: 'center'
      }
    }, "Du kannst Passkeys jederzeit im Konto-Men\xFC unter \u201EPasskeys\u201C hinzuf\xFCgen."));
  }
  function DoneStep({
    passkey,
    onEnter
  }) {
    const {
      Button,
      Callout
    } = NS();
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gap: 'var(--mm-space-4)'
      }
    }, /*#__PURE__*/React.createElement("h2", {
      style: {
        margin: 0,
        fontSize: 'var(--mm-text-h)',
        lineHeight: 1.3
      }
    }, "Alles bereit"), /*#__PURE__*/React.createElement(Callout, {
      tone: "info",
      title: passkey ? 'Passwort und Passkey eingerichtet' : 'Passwort festgelegt'
    }, passkey ? 'Auf diesem Gerät meldest du dich ab jetzt mit deinem Passkey an.' : 'Du meldest dich ab jetzt mit deiner E-Mail-Adresse und deinem Passwort an.'), /*#__PURE__*/React.createElement(Button, {
      block: true,
      onClick: onEnter
    }, "Zu MidMind"));
  }
  function ExpiredCard() {
    const {
      Callout
    } = NS();
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gap: 'var(--mm-space-4)'
      }
    }, /*#__PURE__*/React.createElement(Callout, {
      tone: "warning",
      title: "Dieser Link gilt nicht mehr"
    }, "Einladungslinks funktionieren nur einmal und nur 7 Tage lang."), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        fontSize: 16,
        lineHeight: 1.5,
        textWrap: 'pretty'
      }
    }, "Bitte die Person, die dich eingeladen hat, um eine neue Einladung. Hast du dein Passwort schon festgelegt? Dann ", /*#__PURE__*/React.createElement("a", {
      href: "desktop.html"
    }, "melde dich hier an"), "."));
  }
  function WelcomeScreen({
    invite = INVITE,
    layout = 'mobile',
    expired = false,
    onEnter
  }) {
    const {
      MidMindRoot,
      Logo,
      DisplayHeading
    } = NS();
    const [step, setStep] = React.useState('password');
    const [passkey, setPasskey] = React.useState(null);
    const desktop = layout === 'desktop';
    const enter = () => onEnter && onEnter({
      name: invite.name,
      email: invite.email,
      role: 'user',
      hasPassword: true,
      passkeys: passkey ? [passkey] : []
    });
    const body = expired ? /*#__PURE__*/React.createElement(ExpiredCard, null) : step === 'password' ? /*#__PURE__*/React.createElement(PasswordStep, {
      invite: invite,
      onDone: () => setStep('passkey')
    }) : step === 'passkey' ? /*#__PURE__*/React.createElement(PasskeyStep, {
      layout: layout,
      onDone: pk => {
        setPasskey(pk);
        setStep('done');
      }
    }) : /*#__PURE__*/React.createElement(DoneStep, {
      passkey: passkey,
      onEnter: enter
    });
    return /*#__PURE__*/React.createElement(MidMindRoot, {
      style: {
        height: '100%',
        overflow: 'auto',
        display: 'grid',
        placeItems: desktop ? 'center' : 'start stretch',
        padding: desktop ? 'var(--mm-space-5)' : 'var(--mm-space-7) var(--mm-space-4) var(--mm-space-6)',
        boxSizing: 'border-box'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: '100%',
        maxWidth: 440,
        margin: '0 auto',
        display: 'grid',
        gap: 'var(--mm-space-5)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        justifyItems: 'center',
        gap: 'var(--mm-space-3)',
        textAlign: 'center'
      }
    }, /*#__PURE__*/React.createElement(Logo, {
      size: desktop ? 64 : 72,
      wordmark: true,
      stacked: true
    }), /*#__PURE__*/React.createElement(DisplayHeading, {
      as: "h1",
      size: "md"
    }, expired ? 'Link abgelaufen.' : `Willkommen, ${firstName(invite.name)}.`), !expired && step === 'password' && /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        fontSize: 16,
        lineHeight: 1.5,
        color: 'var(--mm-muted)',
        textWrap: 'pretty'
      }
    }, invite.invitedBy, " hat dich zu MidMind eingeladen. Richte kurz deinen Zugang ein, dann kann es losgehen.")), /*#__PURE__*/React.createElement("div", {
      style: desktop ? {
        background: 'var(--mm-card)',
        border: '1px solid var(--mm-line)',
        borderRadius: 'var(--mm-radius-l)',
        padding: 'var(--mm-space-6)'
      } : undefined
    }, body)));
  }
  Object.assign(window, {
    WelcomeScreen,
    INVITE
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/Welcome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/data.jsx
try { (() => {
(() => {
  // Canned answers for the click-through. Content taken from the @midmind/ui component stories.
  const {
    AnswerCard,
    Value,
    SourceRef,
    Callout,
    Button,
    Icon
  } = window.MidMindDesignSystem_0ec547;
  const answerActions = () => /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "copy",
      size: 18
    })
  }, "Kopieren"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "chat",
      size: 18
    })
  }, "Als Kurznachricht kopieren"));
  const ANSWERS = {
    trinkmenge: {
      title: 'Trinkmenge 9. Lebenstag',
      phase: 'wochenbett',
      question: 'Wieviel Milch sollte ein 9 Tage alter Säugling trinken?',
      render: () => /*#__PURE__*/React.createElement(AnswerCard, {
        summary: /*#__PURE__*/React.createElement(React.Fragment, null, "Etwa ", /*#__PURE__*/React.createElement(Value, null, "1/6 des K\xF6rpergewichts"), " pro Tag, verteilt auf ", /*#__PURE__*/React.createElement(Value, null, "6\u201310 Mahlzeiten"), "."),
        facts: [{
          label: 'pro Tag',
          value: '≈ 600 ml'
        }, {
          label: 'pro Mahlzeit',
          value: '60–100 ml'
        }, {
          label: 'Mahlzeiten',
          value: '6–10'
        }],
        factsCaption: "Beispiel: 3.600 g",
        sources: [{
          label: 'AWMF 024-005'
        }, {
          label: 'DHV Stillempfehlung'
        }],
        actions: answerActions()
      }, /*#__PURE__*/React.createElement("p", null, "Ab dem 8. Lebenstag gilt als Tagestrinkmenge etwa ein Sechstel des K\xF6rpergewichts.", /*#__PURE__*/React.createElement(SourceRef, {
        index: 1
      }), " Gestillte Kinder trinken nach Bedarf, die Menge dient der Orientierung.", /*#__PURE__*/React.createElement(SourceRef, {
        index: 2
      })))
    },
    praeeklampsie: {
      title: 'Blutdruck 160/110 mmHg',
      phase: 'schwangerschaft',
      question: 'Blutdruck 160/110 mmHg und Kopfschmerzen in der 36. SSW – was tun?',
      render: () => /*#__PURE__*/React.createElement(AnswerCard, {
        alert: /*#__PURE__*/React.createElement(Callout, {
          tone: "critical",
          title: "Notfall: sofort \xE4rztlich abkl\xE4ren"
        }, "Verdacht auf schwere Pr\xE4eklampsie. Klinik bzw. Krei\xDFsaal informieren."),
        summary: /*#__PURE__*/React.createElement(React.Fragment, null, "Ab ", /*#__PURE__*/React.createElement(Value, null, "160/110 mmHg"), " mit Symptomen: station\xE4re Einweisung, Blutdruck alle ", /*#__PURE__*/React.createElement(Value, null, "15 min"), "."),
        facts: [{
          label: 'Hypertonie',
          value: 'ab 140/90 mmHg'
        }, {
          label: 'schwere Hypertonie',
          value: 'ab 160/110 mmHg'
        }],
        factsCaption: "Blutdruck in der Schwangerschaft",
        sources: [{
          label: 'AWMF 015-018'
        }],
        actions: answerActions()
      }, /*#__PURE__*/React.createElement("p", null, "Kopfschmerzen und Sehst\xF6rungen gelten als Warnzeichen einer drohenden Eklampsie. Linksseitenlage, ruhige Umgebung.", /*#__PURE__*/React.createElement(SourceRef, {
        index: 1
      })))
    },
    gewicht: {
      title: 'Gewichtsverlust Neugeborenes',
      phase: 'wochenbett',
      question: 'Ab wann ist der Gewichtsverlust eines Neugeborenen kontrollbedürftig?',
      render: () => /*#__PURE__*/React.createElement(AnswerCard, {
        summary: /*#__PURE__*/React.createElement(React.Fragment, null, "Ab ", /*#__PURE__*/React.createElement(Value, null, "7 %"), " Gewichtsverlust Stillen beobachten, ab ", /*#__PURE__*/React.createElement(Value, null, "10 %"), " \xE4rztlich abkl\xE4ren."),
        note: /*#__PURE__*/React.createElement(Callout, {
          tone: "warning",
          title: "Hinweis"
        }, "Bei Fr\xFChgeborenen gelten engere Grenzen."),
        sources: [{
          label: 'AWMF 024-005'
        }],
        actions: answerActions()
      }, /*#__PURE__*/React.createElement("p", null, "Der physiologische Tiefpunkt liegt meist am 3. bis 4. Lebenstag. Das Geburtsgewicht sollte bis zum 10. bis 14. Tag wieder erreicht sein.", /*#__PURE__*/React.createElement(SourceRef, {
        index: 1
      })))
    }
  };
  const SUGGESTIONS = [{
    text: 'Trinkmenge Neugeborenes nach Lebenstag',
    key: 'trinkmenge'
  }, {
    text: 'Gewichtsverlust: ab wann kontrollbedürftig?',
    key: 'gewicht'
  }, {
    text: 'Blutdruck 160/110 mmHg in der Schwangerschaft',
    key: 'praeeklampsie'
  }];
  function matchAnswer(q) {
    const s = q.toLowerCase();
    if (/blutdruck|präeklampsie|mmhg|kopfschmerz/.test(s)) return 'praeeklampsie';
    if (/gewicht|abnahme|verlust/.test(s)) return 'gewicht';
    return 'trinkmenge';
  }
  const HISTORY = [{
    label: 'Trinkmenge 9. Lebenstag',
    phase: 'wochenbett',
    key: 'trinkmenge'
  }, {
    label: 'Anti-D-Prophylaxe Zeitpunkt',
    phase: 'schwangerschaft'
  }, {
    label: 'Dammriss Grad III Nachsorge',
    phase: 'geburt'
  }, {
    label: 'Gewichtsverlust Neugeborenes',
    phase: 'wochenbett',
    key: 'gewicht'
  }];

  // Beispielliste – durch die tatsächlich enthaltenen S3-Leitlinien (PDF) ersetzen.
  const LEITLINIEN = [{
    title: 'Vaginale Geburt am Termin',
    id: 'AWMF 015-083',
    level: 'S3'
  }, {
    title: 'Die Sectio caesarea',
    id: 'AWMF 015-084',
    level: 'S3'
  }, {
    title: 'Gestationsdiabetes mellitus – Diagnostik, Therapie und Nachsorge',
    id: 'AWMF 057-008',
    level: 'S3'
  }];

  // Gleiche Navigation in Mobil- und Desktop-App: Fragen · Verlauf · Leitlinien.
  const APP_TABS = [{
    id: 'fragen',
    label: 'Fragen',
    icon: 'chat'
  }, {
    id: 'verlauf',
    label: 'Verlauf',
    icon: 'clock'
  }, {
    id: 'leitlinien',
    label: 'Leitlinien',
    icon: 'folder'
  }];

  // Textauszüge hinter den Quellen-Chips. Beispieltexte für das Mockup – echte Auszüge kommen aus der Literaturdatenbank.
  const LITERATURE = {
    'AWMF 024-005': {
      level: 'S2k',
      publisher: 'AWMF-Register 024-005',
      pdf: true,
      title: 'Betreuung von gesunden reifen Neugeborenen in der Geburtsklinik',
      section: 'Ernährung des Neugeborenen',
      page: 'S. 14',
      before: 'Die Trinkmenge steigt in den ersten Lebenstagen schrittweise an und orientiert sich am Körpergewicht des Kindes.',
      highlight: 'Ab dem 8. Lebenstag beträgt die Tagestrinkmenge etwa ein Sechstel des Körpergewichts, verteilt auf 6 bis 10 Mahlzeiten.',
      after: 'Abweichungen sind bei gesunden, gut gedeihenden Kindern häufig und für sich allein kein Grund zur Zufütterung.'
    },
    'DHV Stillempfehlung': {
      publisher: 'Deutscher Hebammenverband',
      pdf: false,
      title: 'Stillempfehlungen für Hebammen',
      section: 'Stillen nach Bedarf',
      page: 'S. 6',
      before: 'Gesunde, reif geborene Kinder regulieren ihre Nahrungsaufnahme selbst.',
      highlight: 'Gestillte Kinder trinken nach Bedarf; Richtwerte zur Trinkmenge dienen der Orientierung und nicht als Vorgabe.',
      after: 'Entscheidend sind Gewichtsverlauf, Ausscheidungen und das Verhalten des Kindes an der Brust.'
    },
    'AWMF 015-018': {
      level: 'S2k',
      publisher: 'AWMF-Register 015-018',
      pdf: true,
      title: 'Hypertensive Erkrankungen in der Schwangerschaft: Diagnostik und Therapie',
      section: 'Schwere Hypertonie und drohende Eklampsie',
      page: 'S. 32',
      before: 'Eine schwere Hypertonie liegt ab einem Blutdruck von 160/110 mmHg vor.',
      highlight: 'Treten zusätzlich Kopfschmerzen, Sehstörungen oder Oberbauchschmerzen auf, ist eine sofortige stationäre Aufnahme angezeigt.',
      after: 'Bis zur Übergabe sollte der Blutdruck engmaschig kontrolliert und die Schwangere in Linksseitenlage gebracht werden.'
    }
  };
  Object.assign(window, {
    ANSWERS,
    SUGGESTIONS,
    HISTORY,
    LEITLINIEN,
    APP_TABS,
    LITERATURE,
    matchAnswer
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/data.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.SuggestionButton = __ds_scope.SuggestionButton;

__ds_ns.AnswerCard = __ds_scope.AnswerCard;

__ds_ns.ChatQuestion = __ds_scope.ChatQuestion;

__ds_ns.FactsTable = __ds_scope.FactsTable;

__ds_ns.SourceChip = __ds_scope.SourceChip;

__ds_ns.SourceRef = __ds_scope.SourceRef;

__ds_ns.Value = __ds_scope.Value;

__ds_ns.DisplayHeading = __ds_scope.DisplayHeading;

__ds_ns.ICON_NAMES = __ds_scope.ICON_NAMES;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.PHASES = __ds_scope.PHASES;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Callout = __ds_scope.Callout;

__ds_ns.Composer = __ds_scope.Composer;

__ds_ns.PhaseChip = __ds_scope.PhaseChip;

__ds_ns.PhaseChipGroup = __ds_scope.PhaseChipGroup;

__ds_ns.TextField = __ds_scope.TextField;

__ds_ns.TextSizeSwitch = __ds_scope.TextSizeSwitch;

__ds_ns.MidMindRoot = __ds_scope.MidMindRoot;

__ds_ns.AppBar = __ds_scope.AppBar;

__ds_ns.NavItem = __ds_scope.NavItem;

__ds_ns.DEFAULT_TABS = __ds_scope.DEFAULT_TABS;

__ds_ns.TabBar = __ds_scope.TabBar;

})();
