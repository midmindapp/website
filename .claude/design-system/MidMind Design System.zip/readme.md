# MidMind Design System

MidMind is a German AI assistant for midwives (Hebammen). Midwives ask clinical questions (feeding volumes, blood-pressure thresholds, postpartum care) and get a short, sourced answer. People read it under stress: at night on home visits, in the labour ward, with one hand free, tired. Every decision here serves one principle: **Ruhig unter Druck** (calm under pressure).

**Products / surfaces** (as far as the source defines them):
- **Mobile app**: AppBar, conversation (question bubble + AnswerCard), Composer, bottom TabBar (Fragen · Wissen · Notizen · Verlauf).
- **Desktop app**: sand-coloured sidebar with NavItems (history with phase dots, knowledge collections with counts) next to the answer column.
- **Website**: only hinted at by the source (DisplayHeading in Young Serif, "Testphase anfragen", test-phase sign-up TextFields). No full website design exists yet.

## Sources
- **MidMind Design System (Claude Code)**: claude.ai design project `ca7ac3d6-550d-4326-8586-787ca9472dce` (https://claude.ai/design/p/ca7ac3d6-550d-4326-8586-787ca9472dce). It is a synced build of the React package **@midmind/ui@0.1.0** (23 components, tokens.css + component CSS, stories, guideline "Grundsätze"). All component code, CSS values, copy and stories here are ported 1:1 from that bundle. The upstream repo itself was not available.
- Fonts: Google Fonts (Atkinson Hyperlegible Next, Atkinson Hyperlegible Mono, Young Serif). These are the exact families upstream loads, now self-hosted in `fonts/`.

## Using it
```html
<link rel="stylesheet" href="styles.css">
<script src="_ds_bundle.js"></script> <!-- after React 18 -->
```
```jsx
const { MidMindRoot, AppBar, Logo, IconButton, AnswerCard, Value, Composer, TabBar, DEFAULT_TABS } = window.MidMindDesignSystem_0ec547;
<MidMindRoot theme="day" textSize="normal">  {/* theme: day | night | system */}
  <AppBar title="MidMind" leading={<Logo size={30} />} trailing={<IconButton icon="moon" label="Nachtmodus" />} />
  …
</MidMindRoot>
```
Wrap every screen in **one** `MidMindRoot`. It sets the linen background, font, focus rings, night mode and text size. Components style themselves with `mm-*` classes (from `components/components.css`). Don't restyle them. For layout glue, use inline styles with `var(--mm-*)` tokens, **never hex values**, or night mode breaks.

---

## CONTENT FUNDAMENTALS
- **Language:** German only. Informal **"du"** throughout ("Wir schicken dir den Zugang zur Testphase.", "Aus deinen Notizen"). MidMind speaks as "wir" only on product/website copy.
- **Tone:** calm, clinical, direct. No enthusiasm, no marketing fluff in the app. Short sentences. The reader has seconds.
- **Answer first.** Every answer opens with a 1–2 sentence **Kurzantwort** that holds the key numbers: "Etwa 1/6 des Körpergewichts pro Tag, verteilt auf 6–10 Mahlzeiten." Explanation, sources and actions follow.
- **Values are always highlighted** with `<Value>`: doses, amounts, times, thresholds ("160/110 mmHg", "15 min", "60–100 ml"). German number formatting: "3.600 g", "3,6", en-dash ranges "6–10", "≈ 600 ml".
- **Emergencies** start with a titled critical Callout: "Notfall: sofort ärztlich abklären", "Sofort ärztlich abklären". Never colour alone. There is always a title and an icon.
- **Buttons say what happens:** "Frage stellen", "Kopieren", "In Notizen", "Neue Frage", "Testphase anfragen", "Abbrechen". Progress states use an ellipsis with a space: "Wird gesendet …", "Frage stellen …", "Nachfragen …".
- **Errors say what is wrong and how to fix it:** "Bitte das Gewicht in Gramm eingeben, z. B. 3600."
- **Labels are never placeholder-only.** TextField always has a visible label.
- **Casing:** sentence case everywhere. No uppercase labels.
- **Sources** show book title › chapter (with chapter number if the book has one): "Wochenbettbetreuung › Funktionelle Blutungen", "Hebammenkunde › 53.1.7 Lochien (Wochenfluss)". Use `SourceChip book chapter`; `label` only for sources without chapters ("AWMF 024-005").
- **Disclaimer:** every chat screen ends with "MidMind ist eine KI und macht Fehler." under the Composer.
- **Emoji:** never. Icons come from the MidMind icon set.
- Greetings (start screen, website only) are warm and personal: "Guten Abend, Hanna.", set in Young Serif.

## VISUAL FOUNDATIONS
- **Palette vibe:** warm paper and walnut, like a well-used midwife's notebook. Surfaces are **Leinen** `--mm-paper` #F8F3EF (page), **Sand** `--mm-sand` #EFE6DE (second surface, question bubbles, sidebar), **Karte** `--mm-card` #FFFCF9 (inputs, active nav), **Linie** `--mm-line` #E2D6CB. Text is **Walnuss** `--mm-ink` #2B2220 (14:1) and `--mm-muted` #5C504A (7:1). The single action colour is **Moos** `--mm-moss` #3F5A45.
- **Pastels are surfaces, never text:** Salbei `--mm-sage` (Wochenbett, Kurzantwort box, active tab pill), Aprikose `--mm-apricot` (Schwangerschaft, highlighted values), Malve `--mm-malve` (Geburt, source numbers). The life-phase mapping is fixed everywhere (Badge, PhaseChip dot, NavItem dot).
- **Signal colours:** crit (brick) / warn (ochre) / ok (green), each with a `-bg` tint. Always paired with an icon and a word.
- **Night mode** (`data-mm-theme="night"`): warm dark browns (#1C1815 page), cream text, moss turns light sage (#A9C4A4), focus turns apricot. Never cold greys or pure black.
- **Type:** Atkinson Hyperlegible Next for everything (400/600/700). It was designed for legibility, which suits tired eyes. Young Serif for website headings and greetings only, never inside answers. Atkinson Hyperlegible Mono for codes. Answer body is **18 px minimum**, line-height 1.6, measure 68ch. Text size is user-switchable: normal 18 · large 20 · xlarge 22.
- **Spacing:** 4 · 8 · 12 · 16 · 24 · 32 · 48 (`--mm-space-1…7`). Screens use 16 px side padding with 16 px gaps between conversation blocks.
- **Tap targets:** at least 44 px, standard `--mm-tap` 48 px. Composer 58, AppBar 64, SuggestionButton/Tab 56, TextField 52. These sizes make taps safe with gloves on or while standing.
- **Corner radii:** soft and generous. s 10, m 14 (cards, callouts, suggestions, inputs), l 22, pill 999 (buttons, badges, chips, source chips, Composer at 28). Question bubble 18/18/6/18 (tail bottom-right). Value highlight 7, NavItem 12.
- **Cards:** there are no heavy cards. Answers are laid out on the page; the only filled block is the **sage Kurzantwort bubble** (radius 18/18/18/6 with a tail bottom-left, 16×18 padding). Callouts are tinted fills; critical ones add a 2 px 45 %-crit border.
- **Borders:** 1 px `--mm-line` for dividers (AppBar bottom, TabBar top, FactsTable rows, SourceChip). 2 px `--mm-line` for interactive outlines (ghost button, chips, fields, Composer, TextSizeSwitch). Selected PhaseChip: 2 px ink border on card.
- **Shadows:** a single soft warm shadow, `--mm-shadow` (0 1px 2px + 0 6px 18px, brown at 6–7 %). It is used only on the active NavItem. Everything else is flat.
- **Focus:** 3 px solid `--mm-focus` outline, 3 px offset, radius 6. Fields get a border colour change plus a 3 px 25 % glow.
- **Hover:** primary buttons `filter: brightness(1.08)`. Ghost and SourceChip border goes to `--mm-muted`. IconButton gets a sand fill. NavItem gets a card fill. SuggestionButton mixes 20 % line into sand. There is no scale or shrink on press.
- **Disabled:** opacity .5, not-allowed cursor.
- **Animation:** essentially none. No transitions are defined, and `prefers-reduced-motion` kills all transitions and animations inside `.mm-root`. Keep any motion to quick, subtle fades.
- **Backgrounds and imagery:** flat colour only. No gradients, textures, photos or illustrations in the source. Don't add blur or transparency layers.
- **Layout:** mobile uses a fixed AppBar on top and a fixed TabBar at the bottom (with 14 px bottom padding for the home indicator), with the conversation scrolling between them. Desktop uses a 260–280 px sand sidebar and an answer column of about 720 px.
- **Numbers:** tabular figures in Value, FactsTable and NavItem counts. Values never break between number and unit.

## ICONOGRAPHY
- **Own icon set**, defined in `components/brand/Icon.jsx`: 25 line icons on a 24 px grid, 2.1 px stroke, round caps and joins, `currentColor`. Names: info, alert, send, copy, book, moon, sun, folder, text, search, mic, chevronRight, chevronLeft, chat, note, clock, plus, check, menu, close, user, lock, mail, key, logout. Standalone SVG copies are in `assets/icons/*.svg`.
- Default size 22. Callouts use 24, TabBar 24, button icons 18, SuggestionButton chevron 18. Icons are decorative (aria-hidden) unless they have a `label`.
- IconButtons are always circular (44/48 px) and always have a `label`.
- No icon font, no PNG icons, **no emoji**, and no unicode glyphs used as icons (the only typographic signs are "≈", "→" in docs, and "…").
- If an icon is missing, match the style (2 px stroke, rounded, 24 grid; Lucide is the closest match) and flag it. Don't mix in filled icons.
- **Logo:** `components/brand/Logo.jsx` shows a half-brain made of networked knowledge (left) and a pregnant woman in profile (right): one bowed head, hair falling down her back, and an arm under the belly. It is vectorised from the original image file (`assets/logo/midmind-lockup-original.png`, 740×740). The React Logo component uses one mark at all sizes; the variant prop is ignored. The mark takes the text colour (ink or moss). The component's wordmark is "MidMind" set in Atkinson Bold; the traced original wordmark is in `midmind-wordmark.svg`. SVG exports are in `assets/logo/`: `midmind-mark(-moss|-linen).svg`, `midmind-lockup.svg`, `midmind-wordmark.svg`. App icon: small linen mark on moss, radius about 25 %.

---

## Index
- `styles.css`: entry point (imports only) → `tokens/fonts.css`, `tokens/colors.css`, `tokens/typography.css`, `tokens/spacing.css`, `components/components.css`
- `fonts/`: self-hosted woff2 files (Atkinson Hyperlegible Next, Mono, Young Serif; latin + latin-ext)
- `assets/logo/`, `assets/icons/`: brand mark and icon SVGs
- `guidelines/`: foundation specimen cards (Colors, Type, Spacing, Brand) plus `grundsaetze.md` (the 8 principles, German)
- `components/<group>/`: `<Name>.jsx` + `.d.ts` + `.prompt.md`, one `*.card.html` per group
- `ui_kits/app/`: `index.html` (mobile click-through), `desktop.html`, see README
- `thumbnail.html`, `SKILL.md`

## Components (23, all from @midmind/ui)
- **layout:** MidMindRoot
- **brand:** Logo, Icon (+ `ICON_NAMES`), DisplayHeading
- **actions:** Button, IconButton, SuggestionButton
- **feedback:** Badge (+ `PHASES`), Callout
- **answer:** AnswerCard, ChatQuestion, Value, FactsTable, SourceChip, SourceRef
- **forms:** Composer, TextField, PhaseChip, PhaseChipGroup, TextSizeSwitch
- **navigation:** AppBar, TabBar (+ `DEFAULT_TABS`), NavItem

Rules of use: at most one `Button variant="primary"` per view. Emergencies are `<Callout tone="critical" title="…">` inside `AnswerCard alert`. Life phases go through `phase="schwangerschaft" | "geburt" | "wochenbett"`.

### Intentional additions
- Semantic alias tokens (`--mm-surface-*`, `--mm-text`, `--mm-action`, `--mm-phase-*`, …) in `tokens/colors.css`. They point at the upstream tokens and re-resolve on every theme scope.
- Icons `user`, `lock`, `mail`, `key`, `logout` – drawn in the same 2.1 px style for login and the account menu (not in @midmind/ui 0.1.0).
- Standalone SVG files for the logo and icons, exported from the component source for use outside React.
